package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner scan = new Scanner(System.in);
	ArrayList<Pet> arrPet = new ArrayList<Pet>();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("1. Add new pet");
			System.out.println("2. View pets");
			System.out.println("3. Delete a pet");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = scan.nextInt(); scan.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				delete();
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		if (arrPet.isEmpty()) {
			return;
		}
		
		int index = 1;
		do {
			System.out.print("No berapa yang ingin dihapus: ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= arrPet.size()));
		
		arrPet.remove(index - 1);
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrPet.isEmpty()) {
			System.out.println("no pets in the list");
			return;
		}
		String rapi = "| %-5s | %-10s | %-10s | %-10s | %-10s | %-10s |\n";
		System.out.printf(rapi, "No.", "Pet Name", "Pet Age", "Trained", "FurLenght", "Care Cost");
		
		int i = 1;
		for (Pet p : arrPet) {
			String rapiIsi = "| %-5s | %-10s | %-10s | %-10s | %-10s | %-10.2f |\n";
			System.out.printf(rapiIsi, i++, p.getName(), p.getAge(),
					(p instanceof Dog) ? ((Dog)p).getIsTrained() : "",
					(p instanceof Cat) ? ((Cat)p).getFurLength() : "",
					p.getCareCost()
					);
		}
		
	}

	private void add() {
		// TODO Auto-generated method stub
		double gpa = 0;
		do {
			System.out.print("Input gpa [0.0 - 4.0]: ");
			gpa = scan.nextDouble(); scan.nextLine();
		} while (!(gpa >= 0) || !(gpa <= 4));
		
		String type;
		do {
			System.out.print("Type of the pet [ Dog | Cat ]: ");
			type = scan.nextLine();
		} while (!type.equals("Dog") && !type.equals("Cat"));
		
		String name;
		do {
			System.out.print("Pet name [ Between 3 and 30 characters ] (inclusive): ");
			name = scan.nextLine();
		} while (!(name.length()>=3) || !(name.length()<=30));
		
		int age;
		do {
			System.out.print("Pet's age [ Above 0 ]: ");
			age = scan.nextInt(); scan.nextLine();
		} while (!(age > 0));
		
		if (type.equals("Dog")) {
			String isTrained;
			do {
				System.out.print("Trained or Untrained: ");
				isTrained = scan.nextLine();
			} while (!isTrained.equals("Trained") && !isTrained.equals("Untrained"));
			
			Dog dog = new Dog(name, age, isTrained);
			arrPet.add(dog);
		} else if (type.equals("Cat")) {
			int furLength = 0;
			do {
				System.out.print("Input the furLength [ Most 20 ]: ");
				furLength = scan.nextInt(); scan.nextLine();
			} while (!(furLength >= 1) || !(furLength <= 20));
			
			Cat cat = new Cat(name, age, furLength);
			arrPet.add(cat);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
