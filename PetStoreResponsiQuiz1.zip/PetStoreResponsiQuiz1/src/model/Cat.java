package model;

public class Cat extends Pet {
	
	private int furLength;

	public Cat(String name, int age, int furLength) {
		super(name, age);
		this.furLength = furLength;
		this.careCost = calculateCareCost();
	}

	public int getFurLength() {
		return furLength;
	}

	public void setFurLength(int furLength) {
		this.furLength = furLength;
	}
	
	public double calculateCareCost() {
		return 10 * furLength;
	}

}
