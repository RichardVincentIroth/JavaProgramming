package model;

public class Dog extends Pet {
	
	private String isTrained;

	public Dog(String name, int age, String isTrained) {
		super(name, age);
		this.isTrained = isTrained;
		this.careCost = calculateCareCost();
	}

	public String getIsTrained() {
		return isTrained;
	}

	public void setIsTrained(String isTrained) {
		this.isTrained = isTrained;
	}
	
	public double calculateCareCost() {
		if (isTrained.equals("Trained")) {
			return 100;
		} else {
			return 200;
		}
	}

}
