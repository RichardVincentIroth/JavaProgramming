package model;

public class PurpleArtifact extends Artifact {
	
	private String bonusStatus;

	public PurpleArtifact(String name, String type, int baseAttack, String bonusStatus) {
		super(name, type, baseAttack);
		this.bonusStatus = bonusStatus;
	}

	public String getBonusStatus() {
		return bonusStatus;
	}

	public void setBonusStatus(String bonusStatus) {
		this.bonusStatus = bonusStatus;
	}
	
	public double calculateDamage() {
		return getBaseAttack() * 100;
	}

}
