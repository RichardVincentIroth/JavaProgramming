package model;

public class GoldenArtifact extends Artifact {
	
	private double multiplier;

	public GoldenArtifact(String name, String type, int baseAttack, double multiplier) {
		super(name, type, baseAttack);
		this.multiplier = multiplier;
	}

	public double getMultiplier() {
		return multiplier;
	}

	public void setMultiplier(double multiplier) {
		this.multiplier = multiplier;
	}
	
	public double calculateDamage() {
		return (getBaseAttack() * getMultiplier()) * 100;
	}

}
