package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Locale;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Artifact> arrArtifact = new ArrayList<Artifact>();
	Random rand = new Random();

	public Main() {
		// TODO Auto-generated constructor stub
		sc.useLocale(Locale.ENGLISH);
		int milih = 0;
		do {
			System.out.println("Key Domain");
			System.out.println("==========");
			System.out.println("1. Insert artifacts");
			System.out.println("2. View obtainable artifacts");
			System.out.println("3. Grind for artifacts");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				if (!arrArtifact.isEmpty()) {
					System.out.println("===================================================================================");
					System.out.println("");
					System.out.print("Press enter to continue ...");
					sc.nextLine();
				}
				break;
			case 3:
				grind();
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		int choice = 0;
		do {
			System.out.println("Which artifacts you want to add?");
			System.out.println("1. Purple Artifact");
			System.out.println("2. Golden Artifact");
			System.out.print(">> ");
			choice = sc.nextInt(); sc.nextLine();
			
			switch (choice) {
			case 1:
				addPurple();
				break;
			case 2:
				addGolden();
				break;

			default:
				break;
			}
		} while (!(choice == 1) && !(choice == 2));
		
		
		
	}

	private void addPurple() {
		// TODO Auto-generated method stub
		System.out.println("Add new artifacts!");
		String name;
		do {
			System.out.print("Input name [5..25 characters] : ");
			name = sc.nextLine();
		} while (!(name.length()>=5) || !(name.length()<=25));
		
		String type;
		do {
			System.out.print("Input type [Flower | Plume | Sands | Goblet | Circlet] [case sensitive] : ");
			type = sc.nextLine();
		} while (!type.equals("Flower") && !type.equals("Plume") && !type.equals("Sands") && !type.equals("Goblet") && !type.equals("Circlet"));
		
		int baseAttack;
		boolean valid = true;
		do {
			System.out.print("Input base attack [Flower/Plume = 90-100 | Sands/Goblet/Circlet = 101-110] [case sensitive] : ");
			baseAttack = sc.nextInt(); sc.nextLine();
			
			if (type.equals("Flower") || type.equals("Plume")) {
				if (baseAttack >= 90 && baseAttack <= 100) {
					valid = false;
				}
			}
			if (type.equals("Sands") || type.equals("Goblet") || type.equals("Circlet")) {
				if (baseAttack >= 101 && baseAttack <= 110) {
					valid = false;
				}
			}
		} while (valid);
		
		String bonusStatus;
		do {
			System.out.print("Input bonus status [Anemo | Pyro | Hydro | Electro | Cryo][case sensitive] : ");
			bonusStatus = sc.nextLine();
		} while (!bonusStatus.equals("Anemo") && !bonusStatus.equals("Pyro") && !bonusStatus.equals("Hydro") && !bonusStatus.equals("Electro") && !bonusStatus.equals("Cyro"));
		
		PurpleArtifact purpleartifact = new PurpleArtifact(name, type, baseAttack, bonusStatus);
		arrArtifact.add(purpleartifact);
		
		System.out.println("");
		System.out.print("Press enter to continue ...");
		sc.nextLine();
		
	}

	private void addGolden() {
		// TODO Auto-generated method stub
		System.out.println("Add new artifacts!");
		String name;
		do {
			System.out.print("Input name [5..25 characters] : ");
			name = sc.nextLine();
		} while (!(name.length()>=5) || !(name.length()<=25));
		
		String type;
		do {
			System.out.print("Input type [Flower | Plume | Sands | Goblet | Circlet] [case sensitive] : ");
			type = sc.nextLine();
		} while (!type.equals("Flower") && !type.equals("Plume") && !type.equals("Sands") && !type.equals("Goblet") && !type.equals("Circlet"));
		
		int baseAttack;
		boolean valid = true;
		do {
			System.out.print("Input base attack [Flower/Plume = 90-100 | Sands/Goblet/Circlet = 101-110] [case sensitive] : ");
			baseAttack = sc.nextInt(); sc.nextLine();
			
			if (type.equals("Flower") || type.equals("Plume")) {
				if (baseAttack >= 90 && baseAttack <= 100) {
					valid = false;
				}
			}
			if (type.equals("Sands") || type.equals("Goblet") || type.equals("Circlet")) {
				if (baseAttack >= 101 && baseAttack <= 110) {
					valid = false;
				}
			}
		} while (valid);
		
		double multiplier = 0;
		do {
			System.out.print("Input multiplier [1.5x - 2.0x] : ");
			multiplier = sc.nextDouble(); sc.nextLine();
		} while (!(multiplier >= 1.5) || !(multiplier <= 2.0));
		
		GoldenArtifact goldenartifact = new GoldenArtifact(name, type, baseAttack, multiplier);
		arrArtifact.add(goldenartifact);
		
		System.out.println("");
		System.out.print("Press enter to continue ...");
		sc.nextLine();
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrArtifact.isEmpty()) {
			System.out.println("No obtainable artifacts!");
			System.out.print("Press enter to continue ...");
			sc.nextLine();
			return;
		}
		String rapi = "| %-15s | %-15s | %-15s | %-15s | %-15s |\n";
		System.out.println("Obained Artifacts");
		System.out.println("===================================================================================");
		System.out.printf(rapi, "Name", "Type", "Base Atk", "Bonus Stat", "Multiplier");
		System.out.println("+---------------------------------------------------------------------------------+");
		for (Artifact a : arrArtifact) {
			System.out.printf(rapi, a.getName(), a.getType(), a.getBaseAttack(),
					(a instanceof PurpleArtifact) ? ((PurpleArtifact)a).getBonusStatus() : "-",
					(a instanceof GoldenArtifact) ? ((GoldenArtifact)a).getMultiplier() : "-"
					);
		}
		
	}

	private void grind() {
		// TODO Auto-generated method stub
		view();
		if (arrArtifact.isEmpty()) {
			return;
		}
		System.out.println("===================================================================================");
		
		System.out.println("List Character:");
		System.out.println("Diluc - Xiao - Keqing");
		String character;
		do {
			System.out.print("Input chosen character [case insensitive] : ");
			character = sc.nextLine();
			if (!(character.equalsIgnoreCase("Diluc")) && !(character.equalsIgnoreCase("Xiao")) && !(character.equalsIgnoreCase("Keqing"))) {
				System.out.println("Character invalid!");
			}
		} while (!(character.equalsIgnoreCase("Diluc")) && !(character.equalsIgnoreCase("Xiao")) && !(character.equalsIgnoreCase("Keqing")));
		
		int index = rand.nextInt(arrArtifact.size());
		System.out.println(index);
		
		Artifact art = arrArtifact.get(index);
		
		if (art instanceof PurpleArtifact) {
			System.out.println(character + " come back and got you a new artifact!");
			System.out.println("Name : " + art.getName());
			System.out.println("Type : " + art.getType());
			System.out.println("Base atk : " + art.getBaseAttack());
			System.out.printf("%s %.0f\n", "Damage : ", art.calculateDamage());
			System.out.println("Bonus Stat : " + ((PurpleArtifact)art).getBonusStatus());
			arrArtifact.remove(index);
		} else if (art instanceof GoldenArtifact) {
			System.out.println(character + " come back and got you a new artifact!");
			System.out.println("Name : " + art.getName());
			System.out.println("Type : " + art.getType());
			System.out.println("Base atk : " + art.getBaseAttack());
			System.out.printf("%s %.0f\n", "Damage : ", art.calculateDamage());
			arrArtifact.remove(index);
		}
		
		System.out.println("");
		System.out.print("Press enter to continue ...");
		sc.nextLine();
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
