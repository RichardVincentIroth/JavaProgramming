package model;

public class HomeAppliances extends Item {
	
	private double powerUsage;

	public HomeAppliances(String id, String category, String itemName, String brandName, double price, double powerUsage) {
		super(id, category, itemName, brandName, price);
		this.powerUsage = powerUsage;
	}

	public double getPowerUsage() {
		return powerUsage;
	}

	public void setPowerUsage(double powerUsage) {
		this.powerUsage = powerUsage;
	}
	
	

}
