package model;

public abstract class Item {
	
	protected String id, category, itemName, brandName;
	protected double price;
	
	public Item(String id, String category, String itemName, String brandName, double price) {
		super();
		this.id = id;
		this.category = category;
		this.itemName = itemName;
		this.brandName = brandName;
		this.price = price;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
