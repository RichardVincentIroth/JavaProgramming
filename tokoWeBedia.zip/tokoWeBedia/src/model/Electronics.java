package model;

public class Electronics extends Item {
	
	private String warranty;

	public Electronics(String id, String category, String itemName, String brandName, double price, String warranty) {
		super(id, category, itemName, brandName, price);
		this.warranty = warranty;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	
	

}
