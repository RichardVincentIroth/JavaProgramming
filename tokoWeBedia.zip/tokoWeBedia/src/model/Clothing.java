package model;

public class Clothing extends Item {
	
	private String size;

	public Clothing(String id, String category, String itemName, String brandName, double price, String size) {
		super(id, category, itemName, brandName, price);
		this.size = size;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	

}
