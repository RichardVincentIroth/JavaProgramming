package tokoWeBedia;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner scan = new Scanner(System.in);
	ArrayList<Item> arrItem = new ArrayList<Item>();
	Random rand = new Random();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("1. Add Items");
			System.out.println("2. View Items");
			System.out.println("3. Update Items");
			System.out.println("4. Delete Items");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				milih = scan.nextInt();
			} catch (Exception e) {
				milih = -1;
			} scan.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		if (arrItem.isEmpty()) {
			System.out.println("Gak ada");
			return;
		}
		view();
		
		do {
			System.out.print("Ketik Item ID (cth. EL507): ");
			String id = scan.nextLine();
			
			for (Item i : arrItem) {
				if (i.getId().equals(id)) {
					arrItem.remove(i);
					return;
				}
			}

		} while (true);
		
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrItem.isEmpty()) {
			return;
		}
		
		String index;
		do {
			System.out.print("Pilih ID yang mau diedit: ");
			index = scan.nextLine();
			
			int counter = 0;
			
			for (Item i : arrItem) {
				if (i.getId().equals(index)) {
					String category;
					do {
						System.out.print("Item Category [Electronics | Clothing | Home Appliances]: ");
						category = scan.nextLine();
					} while (!category.equals("Electronics") && !category.equals("Clothing") && !category.equals("Home Appliances"));
					
					String itemName;
					do {
						System.out.print("Item name [Between 3 - 30 character]: ");
						itemName = scan.nextLine();
					} while (!(itemName.length()>3) || !(itemName.length()<30));
					
					String brandName;
					int flag;
					do {
						flag = 0;
						System.out.print("Brand name [Alphabets and no space]: ");
						brandName = scan.nextLine();
						for (char c : brandName.toCharArray()) {
							if (!Character.isAlphabetic(c) && c != ' ') {
								flag = 1;
							}
						}
					} while (flag == 1 || !(brandName.split(" ").length<2) || brandName.contains(" "));
					
					double price;
					do {
						System.out.print("Price: ");
						price = scan.nextInt(); scan.nextLine();
					} while (!(price >= 0));
					
					
					
					if (category.equals("Electronics")) {
						String warranty;
						do {
							System.out.print("Warranty period [e.g., 12 months]: ");
							warranty = scan.nextLine();
						} while (!warranty.matches("[1-9][1-2] months") && !warranty.matches("[1-9] months"));
						
						Electronics newElectronics = new Electronics(i.getId(), category, itemName, brandName, price, warranty);
						arrItem.set(counter, newElectronics);
						
					} else if (category.equals("Clothing")) {
						String size;
						do {
							System.out.print("Size [Small | Medium | Large]: : ");
							size = scan.nextLine();
						} while (!size.equals("Small") && !size.equals("Medium") && !size.equals("Large"));
						
						Clothing newClothing = new Clothing(i.getId(), category, itemName, brandName, price, size);
						arrItem.set(counter, newClothing);
						
					} else if (category.equals("Home Appliances")) {
						double powerUsage;
						do {
							System.out.print("Power usage: ");
							powerUsage = scan.nextDouble(); scan.nextLine();
						} while (!(powerUsage >= 0));
						
						HomeAppliances newHomeAppliances = new HomeAppliances(i.getId(), category, itemName, brandName, price, powerUsage);
						arrItem.set(counter, newHomeAppliances);
						
					}
					
					return;
				}
				counter++;
			}
			
		} while (true);
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrItem.isEmpty()) {
			System.out.println("No items available");
			return;
		}
		String rapi = "| %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s |\n";
		String rapiIsi = "| %-15s | %-15s | %-15s | %-15s | %-15.0f | %-15s | %-15s | %-15s |\n";
		System.out.printf(rapi, "ID", "Category", "Item Name", "Brand Name", "Price", "Warranty", "Size", "Power Usage");
		for (Item i : arrItem) {
			System.out.printf(rapiIsi, i.getId(), i.getCategory(), i.getItemName(), i.getBrandName(), i.getPrice(),
					(i instanceof Electronics) ? ((Electronics)i).getWarranty() : " ",
					(i instanceof Clothing) ? ((Clothing)i).getSize() : " ",
					(i instanceof HomeAppliances) ? ((HomeAppliances)i).getPowerUsage() : " "
					);
		}
		
	}

	private void add() {
		// TODO Auto-generated method stub
		String category;
		do {
			System.out.print("Item Category [Electronics | Clothing | Home Appliances]: ");
			category = scan.nextLine();
		} while (!category.equals("Electronics") && !category.equals("Clothing") && !category.equals("Home Appliances"));
		
		String itemName;
		do {
			System.out.print("Item name [Between 3 - 30 character]: ");
			itemName = scan.nextLine();
		} while (!(itemName.length()>3) || !(itemName.length()<30));
		
		String brandName;
		int flag;
		do {
			flag = 0;
			System.out.print("Brand name [Alphabets and no space]: ");
			brandName = scan.nextLine();
			for (char c : brandName.toCharArray()) {
				if (!Character.isAlphabetic(c) && c != ' ') {
					flag = 1;
				}
			}
		} while (flag == 1 || !(brandName.split(" ").length<2) || brandName.contains(" "));
		
		double price;
		do {
			System.out.print("Price: ");
			price = scan.nextDouble(); scan.nextLine();
		} while (!(price >= 0));
		
		char c1 = Character.toUpperCase(itemName.charAt(rand.nextInt(itemName.length())));
		char c2;
		do {
			c2 = Character.toUpperCase(itemName.charAt(rand.nextInt(itemName.length())));			
		} while (c1 == c2);
		
		
		
		int r = rand.nextInt(1000);
		String id = String.format("%c%c%03d", c1, c2, r);
		
		if (category.equals("Electronics")) {
			String warranty;
			do {
				System.out.print("Warranty period [e.g., 12 months]: ");
				warranty = scan.nextLine();
			} while (!warranty.matches("[1-9][1-2] months") && !warranty.matches("[1-9] months"));
			
//			String id = String.format("EL%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
			Electronics electronics = new Electronics(id, category, itemName, brandName, price, warranty);
			arrItem.add(electronics);
			
		} else if (category.equals("Clothing")) {
			String size;
			do {
				System.out.print("Size [Small | Medium | Large]: : ");
				size = scan.nextLine();
			} while (!size.equals("Small") && !size.equals("Medium") && !size.equals("Large"));
			
//			String id = String.format("CL%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
			Clothing clothing = new Clothing(id, category, itemName, brandName, price, size);
			arrItem.add(clothing);
			
		} else if (category.equals("Home Appliances")) {
			double powerUsage;
			do {
				System.out.print("Power usage: ");
				powerUsage = scan.nextDouble(); scan.nextLine();
			} while (!(powerUsage >= 0));
			
//			String id = String.format("HA%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
			HomeAppliances homeAppliances = new HomeAppliances(id, category, itemName, brandName, price, powerUsage);
			arrItem.add(homeAppliances);
			
		}
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
