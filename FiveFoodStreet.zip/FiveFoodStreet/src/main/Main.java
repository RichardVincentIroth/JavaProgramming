package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Food> arrFood = new ArrayList<Food>();
	Random rand = new Random();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("Five Food Street");
			System.out.println("================");
			System.out.println("1. Insert New Menu");
			System.out.println("2. View All Menu");
			System.out.println("3. Sell Menu Item");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				sell();
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Input menu name [8-20]: ");
			name = sc.nextLine();
		} while (!(name.length()>=8) || !(name.length()<=20));
		
		String dish;
		do {
			System.out.print("Input main dish [Rice | Noodle][Case Insensitive]: ");
			dish = sc.nextLine();
		} while (!dish.equalsIgnoreCase("Rice") && !dish.equalsIgnoreCase("Noodle"));
		
		String type;
		do {
			System.out.print("Input menu type [Vege | Non-Vege][Case Sensitive]: ");
			type = sc.nextLine();
		} while (!type.equals("Vege") && !type.equals("Non-Vege"));
		
		int price = 0;
		do {
			System.out.print("Input base price [5000 - 25000][Multiple of 1000]: ");
			price = sc.nextInt(); sc.nextLine();
		} while (!(price >= 5000) || !(price <= 25000) || !(price % 1000 == 0));
		
		if (type.equals("Vege")) {
			String vegetable;
			do {
				System.out.print("Input Vegetable [Potato | Tomato][Case Insensitive]: ");
				vegetable = sc.nextLine();
			} while (!vegetable.equalsIgnoreCase("Potato") && !vegetable.equalsIgnoreCase("Tomato"));
			
			String id = String.format("VV%03d", rand.nextInt(1000));
			Vege vege = new Vege(id, name, dish, type, price, vegetable);
			arrFood.add(vege);
			System.out.println("Vege food added successfully");
			
		} else if (type.equals("Non-Vege")) {
			String addOns;
			do {
				System.out.print("Input addOns [Meatballs | Fishballs | Fried Potato][Case Insensitive]: ");
				addOns = sc.nextLine();
			} while (!addOns.equalsIgnoreCase("Meatballs") && !addOns.equalsIgnoreCase("Fishballs") && !addOns.equalsIgnoreCase("Fried Potato"));
			
			String id = String.format("NV%03d", rand.nextInt(1000));
			NonVege nonVege = new NonVege(id, name, dish, type, price, addOns);
			arrFood.add(nonVege);
			System.out.println("Non vege food added successfully");
			
		}
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrFood.isEmpty()) {
			System.out.println("No menu available");
			return;
		}
		String rapi = "| %-5s | %-10s | %-15s | %-10s | %-10s |\n";
		System.out.println("======================================");
		System.out.printf(rapi, "No", "ID", "Name", "Price", "Type");
		System.out.println("======================================");
		int index = 1;
		for (Food f : arrFood) {
			System.out.printf(rapi, index, f.getId(), f.getName(), f.calculatePrice(), f.getType());
			index++;
		}
		System.out.println("======================================");
		
		
	}

	private void sell() {
		// TODO Auto-generated method stub
		view();
		if (arrFood.isEmpty()) {
			return;
		}
		int index = 0;
		do {
			System.out.print("Input number [1 - 2]: ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1) || !(index <= arrFood.size()));
		
		int quantity = 0;
		do {
			System.out.print("Input quantity [More than 1]: ");
			quantity = sc.nextInt(); sc.nextLine();
		} while (!(quantity >= 1));
		
		Food indFood = arrFood.get(index - 1);
		
		double grandTotal = 0;
		grandTotal = indFood.calculatePrice() * quantity;
		
		System.out.println("ID : " + indFood.getId());
		System.out.println("Menu name : " + indFood.getName());
		System.out.println("Main dish : " + indFood.getDish());
		System.out.println("Price : " + indFood.calculatePrice());
		System.out.println("Grand total : " + grandTotal);
		
		arrFood.remove(index - 1);
		
		System.out.println("");
		System.out.println("Food  sold");
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
