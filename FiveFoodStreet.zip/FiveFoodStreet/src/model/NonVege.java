package model;

public class NonVege extends Food {
	
	private String addOns;

	public NonVege(String id, String name, String dish, String type, int price, String addOns) {
		super(id, name, dish, type, price);
		this.addOns = addOns;
	}

	public String getAddOns() {
		return addOns;
	}

	public void setAddOns(String addOns) {
		this.addOns = addOns;
	}
	
	public double calculatePrice() {
		int addPrice = 0;
		switch (getDish()) {
		case "Rice":
			addPrice = 5000;
			break;
		case "Noodle":
			addPrice = 3000;
			break;
		}
		
		int addPriceAddOns = 0;
		switch (getAddOns()) {
		case "Meatballs":
			addPriceAddOns = 4000;
			break;
		case "Fishballs":
			addPriceAddOns = 3000;
			break;
		case "Fried Potato":
			addPriceAddOns = 5000;
			break;
		}		
		
		return getPrice() + addPriceAddOns + addPrice;
	}

}
