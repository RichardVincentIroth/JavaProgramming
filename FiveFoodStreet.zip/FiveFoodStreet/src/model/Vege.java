package model;

public class Vege extends Food {
	
	private String vegetable;

	public Vege(String id, String name, String dish, String type, int price, String vegetable) {
		super(id, name, dish, type, price);
		this.vegetable = vegetable;
	}

	public String getVegetable() {
		return vegetable;
	}

	public void setVegetable(String vegetable) {
		this.vegetable = vegetable;
	}
	
	public double calculatePrice() {
		int addPrice = 0;
		switch (getDish()) {
		case "Rice":
			addPrice = 5000;
			break;
		case "Noodle":
			addPrice = 3000;
			break;
		}
		
		int addPriceVegetable = 0;
		switch (getVegetable()) {
		case "Potato":
			addPriceVegetable = 2000;
			break;
		case "Tomato":
			addPriceVegetable = 1000;
			break;
		}
		
		return getPrice() + (getName().length() * addPriceVegetable) + addPrice;
	}

}
