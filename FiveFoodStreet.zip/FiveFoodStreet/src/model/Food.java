package model;

public abstract class Food {
	
	private String id, name, dish, type;
	private int price;
	
	public Food(String id, String name, String dish, String type, int price) {
		super();
		this.id = id;
		this.name = name;
		this.dish = dish;
		this.type = type;
		this.price = price;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDish() {
		return dish;
	}

	public void setDish(String dish) {
		this.dish = dish;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public abstract double calculatePrice();

}
