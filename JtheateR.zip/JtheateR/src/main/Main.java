package main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Member> arrMember = new ArrayList<Member>();
	Random rand = new Random();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("JtheaeR");
			System.out.println("=======");
			System.out.println("1. Add new member");
			System.out.println("2. View all member");
			System.out.println("3. Watch a movie");
			System.out.println("0. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				System.out.print("Press enter to continue...");
				sc.nextLine();
				break;
			case 3:
				watch();
				break;
			case 0:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 0);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Input your name [ 5 - 12 characters ]: ");
			name = sc.nextLine();
		} while (!(name.length()>=5) || !(name.length()<=12));
		
		String gender;
		do {
			System.out.print("Input your gender [Male / Female] (Case Sensitive): ");
			gender = sc.nextLine();
		} while (!gender.equals("Male") && !gender.equals("Female"));
		
		String phoneNumber;
		int flag;
		do {
			flag = 0;
			System.out.print("Input your phone number [must be 12 characters and numeric]: ");
			phoneNumber = sc.nextLine();
			for (char c : phoneNumber.toCharArray()) {
				if (Character.isAlphabetic(c) && c != ' ') {
					flag = 1;
				}
			}
		} while (flag == 1 || !(phoneNumber.length()==12));
		
		String status;
		do {
			System.out.print("Input your status [VIP / Regular](Case Sensitive): ");
			status = sc.nextLine();
		} while (!status.equals("VIP") && !status.equals("Regular"));
		
		int points = 0;
		
		if (status.equals("VIP")) {
			String email;
			do {
				System.out.print("Input your email [Must ends with \"@gmail.com\": ");
				email = sc.nextLine();
			} while (!email.endsWith("@gmail.com"));
			
			String id = String.format("V%05d", rand.nextInt(100000));
			String idLounge = String.format("Lounge %03d", rand.nextInt(1000));
			
			Vip vip = new Vip(id, name, gender, phoneNumber, status, email, idLounge, points);
			arrMember.add(vip);
			
		} else if (status.equals("Regular")) {
			String id = String.format("R%05d", rand.nextInt(100000));
			
			Regular regular = new Regular(id, name, gender, phoneNumber, status, points); 
			arrMember.add(regular);
			
		}
		
		System.out.println("A new member has been added");
		System.out.print("Press enter to continue..");
		sc.nextLine();
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrMember.isEmpty()) {
			System.out.println("Currently, there are no member...");
			System.out.print("Press enter to continue..");
			sc.nextLine();
			return;
		}
		String rapi = "| %-5s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s |\n";
		System.out.println("===============================================================================================");
		System.out.printf(rapi, "No", "Name", "Gender", "Phone Number", "Status", "ID", "Points", "Email", "Lounge", "Queue");
		System.out.println("===============================================================================================");
		int index = 1;
		for (Member m : arrMember) {
			System.out.printf(rapi, index, m.getName(), m.getGender(), m.getPhoneNumber(), m.getStatus(), m.getId(), m.getPoints(),
					(m instanceof Vip) ? ((Vip)m).getEmail() : "-",
					(m instanceof Vip) ? ((Vip)m).getIdLounge() : "-",
					(index == 1) ? 0 : index
					);
			index++;
		}
		System.out.println("===============================================================================================");
		
	}

	private void watch() {
		// TODO Auto-generated method stub
		view();
		
		String index;
		do {
			System.out.print("Input your ID: ");
			index = sc.nextLine();
			
			for (Member m : arrMember) {
				if (m.getId().equals(index)) {
					System.out.println("Thank you for watching...");
					m.calculatePoints();
					return;
				}
			}
		} while (true);
		
	}

	
/*	private void watch() {
		// TODO Auto-generated method stub
		view();
		
		String index;
		do {
			System.out.print("Input your ID: ");
			index = sc.nextLine();
			
			for (Member m : arrMember) {
				if (m.getId().equals(index)) {
					String movie;
					do {
						System.out.print("What movie [Exclusive | Non Exclusive]: ");
						movie = sc.nextLine();
					} while (!movie.equals("Exclusive") && !movie.equals("Non Exclusive"));
					
					m.setMovie(movie);
					m.calculatePoints();
					
					return;
				}
			}
		} while (true);
		
	}
*/	
	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Hope you have a good time here, thank you..");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
