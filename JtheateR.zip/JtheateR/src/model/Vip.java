package model;

public class Vip extends Member {
	
	private String email, idLounge;

	public Vip(String id, String name, String gender, String phoneNumber, String status, String email, String idLounge, int points) {
		super(id, name, gender, phoneNumber, status, points);
		this.email = email;
		this.idLounge = idLounge;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdLounge() {
		return idLounge;
	}

	public void setIdLounge(String idLounge) {
		this.idLounge = idLounge;
	}
	
	public void calculatePoints() {
		/*int moviePlus = 0;
		switch (getMovie()) {
		case "Exclusive":
			moviePlus = 100;
			break;
		case "Non Exclusive":
			moviePlus = 0;
			break;
			
		}*/
		setPoints(getPoints() + (getName().length() * 2));

	}

}
