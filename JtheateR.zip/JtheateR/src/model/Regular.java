package model;

public class Regular extends Member {

	public Regular(String id, String name, String gender, String phoneNumber, String status, int points) {
		super(id, name, gender, phoneNumber, status, points);
	}
	
	public void calculatePoints() {
		/*int moviePlus = 0;
		switch (this.getMovie()) {
		case "Exclusive":
			moviePlus = 100;
			break;
		case "Non Exclusive":
			moviePlus = 0;
			break;
		}*/
		setPoints(getPoints() + getName().length());
	}

}
