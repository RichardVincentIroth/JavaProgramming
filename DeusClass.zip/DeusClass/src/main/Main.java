package main;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<People> arrPeople = new ArrayList<People>();

	public Main() {
		sc.useLocale(Locale.US);
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("1. Add People");
			System.out.println("2. View People");
			System.out.println("3. Remove People");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				remove();
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
	}

	private void add() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Input name [3 - 15 characters]: ");
			name = sc.nextLine();
		} while (!(name.length()>=3) || !(name.length()<=15));
		
		int age = 0;
		do {
			System.out.print("Input age [min 16]: ");
			age = sc.nextInt(); sc.nextLine();
		} while (!(age >= 16));
		
		String role;
		do {
			System.out.print("Input role ['Student', 'Lecturer']: ");
			role = sc.nextLine();
		} while (!role.equals("Lecturer") && !role.equals("Student"));
		
		if (role.equals("Lecturer")) {
			double salary = 0;
			do {
				System.out.print("Input Salary [min 4000000]: ");
				salary = sc.nextDouble(); sc.nextLine();
			} while (!(salary >= 4000000));
			
			Lecturer lecturer = new Lecturer(name, age, role, salary);
			arrPeople.add(lecturer);
			
		} else if (role.equals("Student")) {
			double gpa = 0;
			do {
				System.out.print("Input gpa [0.0 - 4.0]: ");
				gpa = sc.nextDouble(); sc.nextLine();
			} while (!(gpa >= 0) || !(gpa <= 4));
			
			Student student = new Student(name, age, role, gpa);
			arrPeople.add(student);
			
		}
		
		System.out.println(role + " added successfully");
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrPeople.isEmpty()) {
			System.out.println("There are no peoples in classroom!");
			return;
		}
		int index = 1;
		for (People p : arrPeople) {
			System.out.println(index + ". Hello, my name is " + p.getName());
			System.out.println("I am " + p.getAge() + " year\"s\" old");
			System.out.println("I am a " + p.getRole());
			
			if (p instanceof Lecturer) {
				System.out.println("My salary is " + ((Lecturer)p).getSalary());
			} else if (p instanceof Student) {
				System.out.println("My gpa is " + ((Student)p).getGpa() + " from 4.0");
			}
			
			if (index < arrPeople.size()) {
				System.out.println();
			}
			
			index++;
			
		}
		
	}

	private void remove() {
		// TODO Auto-generated method stub
		view();
		if (arrPeople.isEmpty()) {
			return;
		}
		int index = 1;
		do {
			System.out.print("Input peoples index to delete [1 - " + arrPeople.size() + "]: ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1) || !(index <= arrPeople.size()));
		
		arrPeople.remove(index - 1);
		System.out.println("People deleted successfully !!");
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
