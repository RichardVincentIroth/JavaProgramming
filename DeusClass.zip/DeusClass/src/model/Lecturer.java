package model;

public class Lecturer extends People {
	
	private double salary;

	public Lecturer(String name, int age, String role, double salary) {
		super(name, role, age);
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
