package model;

public class Student extends People {
	
	private double gpa;

	public Student(String name, int age, String role, double gpa) {
		super(name, role, age);
		this.gpa = gpa;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	

}
