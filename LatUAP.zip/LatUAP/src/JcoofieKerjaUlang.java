import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class JcoofieKerjaUlang {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<String> arrTopping = new ArrayList<String>();
	ArrayList<Integer> arrPrice = new ArrayList<Integer>();

	public JcoofieKerjaUlang() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("1. Bake Cookie");
			System.out.println("2. View Cookie");
			System.out.println("3. Research Cookie");
			System.out.println("4. Sell Cookie");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrName.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				research();
				break;
			case 4:
				sell();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void sell() {
		// TODO Auto-generated method stub
		view();
		if (arrName.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.println("Which cookie do you want to sell? [1 - " + arrName.size() + " ] : ");
			System.out.print(">> ");
			index = scan.nextInt(); scan.nextLine(); 
		} while (!(index >= 1) || !(index <= arrName.size()));
		System.out.println("==============================");
		System.out.println("| Jco.oFie Cookie and Cokkee |");
		System.out.println("==============================");
		System.out.println("|                            |");
		System.out.println(" Your order:                 |");
		System.out.println("| Cookie: " + arrName.get(index - 1) + "|");
		System.out.println(" Subtotal: " + arrPrice.get(index - 1) + "|");
		System.out.println("|                            |");
		System.out.println("| Thank you                  |");
		System.out.println("|                            |");
		System.out.println("==============================");
		
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void research() {
		// TODO Auto-generated method stub
		view();
		if (arrName.size() == 0) {
			return;
		}
		String awal;
		do {
			System.out.println("Which cookie to Research?");
			System.out.print(">> ");
			awal = scan.nextLine();
			if (!arrName.contains(awal)) {
				System.out.println("Cookie not found!");
			}
		} while (!arrName.contains(awal));
		for (int i = 0; i < arrName.size(); i++) {
			if (arrName.get(i).equals(awal)) {
				int x = rand.nextInt(10) + 1;
				if (x <= 4) {
					arrPrice.set(i, (int) (arrPrice.get(i) * 1.2));
					System.out.println("The research was successful!");
					System.out.println("Cookie price is increased by 20%!");
				} else {
					arrPrice.set(i, (int) (arrPrice.get(i) * 0.5));
					System.out.println("The research was successful!");
					System.out.println("Cookie price is cut by half!");
				}
			} 
		}
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrName.size() == 0) {
			System.out.println("There is no data");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("==========================================");
		String rapi = "| %-5s | %-20s | %-20s | %-20s |\n";
		System.out.printf(rapi, "No", "Cookie Name", "Topping", "Price");
		System.out.println("==========================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, i + 1, arrName.get(i), arrTopping.get(i), "IDR" + arrPrice.get(i));
		}
		System.out.println("==========================================");
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String inputName;
		do {
			System.out.println("Cookie Name [5 - 20 character]: ");
			inputName = scan.nextLine();
			if (!(inputName.length() >= 5) || !(inputName.length() <= 20)) {
				System.out.println("Cookie name must be between 5 and 20 characters!");
			}
		} while (!(inputName.length() >= 5) || !(inputName.length() <= 20));
		
		String inputTopping;
		int toppingPrice = 0;
		do {
			System.out.println("Input topping [Plain | Choco Chips | Almond][case sensitive]: ");
			inputTopping = scan.nextLine();
			if (!inputTopping.equals("Plain") && !inputTopping.equals("Choco Chips") && !inputTopping.equals("Almond")) {
				System.out.println("Topping must be either 'Plain', 'Choco Chips', or 'Almond'!");
			}
		} while (!inputTopping.equals("Plain") && !inputTopping.equals("Choco Chips") && !inputTopping.equals("Almond"));
		if (inputTopping.equals("Plain")) {
			toppingPrice = 5000;
		} else if (inputTopping.equals("Choco Chips")) {
			toppingPrice = 7000;
		} else if (inputTopping.equals("Almond")) {
			toppingPrice = 10000;
		}
		
		int basePrice = 0;
		do {
			System.out.println("Base Price [10000 - 20000]: ");
			basePrice = scan.nextInt(); scan.nextLine();
			if (!(basePrice >= 10000) || !(basePrice <= 20000)) {
				System.out.println("Base price must be between 10000 and 20000!");
			}
		} while (!(basePrice >= 10000) || !(basePrice <= 20000));
		
		double price = 0;
		price = basePrice + toppingPrice;
		int harga = (int) price;
		
		arrName.add(inputName);
		arrTopping.add(inputTopping);
		arrPrice.add(harga);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JcoofieKerjaUlang();
		

	}

}
