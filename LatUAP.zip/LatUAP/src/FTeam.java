import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class FTeam {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrGameName = new ArrayList<String>();
	ArrayList<String> arrGenre = new ArrayList<String>();
	ArrayList<Integer> arrPrice = new ArrayList<Integer>();
	ArrayList<String> arrDeveloper = new ArrayList<String>();
	ArrayList<String> arrPublisher = new ArrayList<String>();

	public FTeam() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("FTeam");
			System.out.println("===============");
			System.out.println("1. Release a game");
			System.out.println("2. View all games");
			System.out.println("3. Update Game");
			System.out.println("4. Delete Game");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
				
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank You :)");
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		int index = 0;
		do {
			System.out.print("Input FokemonT Number [ 1 - 3 ] : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= 3));
		
		arrID.remove(index - 1);
		arrGameName.remove(index - 1);
		arrGenre.remove(index - 1);
		arrPrice.remove(index - 1);
		arrDeveloper.remove(index - 1);
		arrPublisher.remove(index - 1);
		
		System.out.println("Successfully Deleted FokemonT");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
		
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		String index;
		do {
			System.out.print("Input Game ID [ e.g. FTof421 ] : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		
		for (int i = 0; i < arrID.size(); i++) {
			if (arrID.get(i).equals(index)) {
				int flag, countNum, countHex;
				String alpa;
				do {
					flag = 0;
					countNum = 0;
					countHex = 0;
					System.out.print("Input Game Name [ Must be alphanumberic and Unique ] : ");
					alpa = scan.nextLine();
					for (char c : alpa.toCharArray()) {
						if (!Character.isLetterOrDigit(c) && c != ' ') {
							flag = 1;
						}
						if (Character.isDigit(c)) {
							countNum++;
						}
						if (Character.isLetter(c)) {
							countHex++;
						}
					}
				} while (flag == 1 || countNum == 0 || countHex == 0 || arrGameName.contains(alpa));
				
				arrGameName.set(i, alpa);
				System.out.println("Successfully Updated game!");
				System.out.print("Press Enter To Continue...");
				scan.nextLine();
				break;
			}
		}
		
		
	}

	private void view() {
		// TODO Auto-generated method stub
		sortIDDes();
		if (arrID.size() == 0) {
			System.out.println("no games have been released yet!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("======================================================================");
		String rapi = "| %-12s | %-12s | %-8s | %-8s | %-12s | %-12s |\n";
		System.out.printf(rapi, "Game ID", "Game Name", "Genre", "Price", "Developer", "Publisher");
		System.out.println("======================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrGameName.get(i), arrGenre.get(i), arrPrice.get(i), arrDeveloper.get(i), arrPublisher.get(i));
		}
		System.out.println("======================================================================");
		
		int milih = 0;
		System.out.println("1. Sort Descending by Price : ");
		System.out.println("2. Back");
		System.out.print(">> ");
		milih = scan.nextInt(); scan.nextLine();
		switch (milih) {
		case 1:
			sortIDDes();
			view();
			break;
		case 2:
			break;
		default:
			break;
		}
	}

	private void sortIDDes() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				if (arrPrice.get(j) < arrPrice.get(j+1)) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempGame = arrGameName.get(j);
					arrGameName.set(j, arrGameName.get(j+1));
					arrGameName.set(j+1, tempGame);
					
					String tempGenre = arrGenre.get(j);
					arrGenre.set(j, arrGenre.get(j+1));
					arrGenre.set(j+1, tempGenre);
					
					int tempPrice = arrPrice.get(j);
					arrPrice.set(j, arrPrice.get(j+1));
					arrPrice.set(j+1, tempPrice);
					
					String tempDeveloper = arrDeveloper.get(j);
					arrDeveloper.set(j, arrDeveloper.get(j+1));
					arrDeveloper.set(j+1, tempDeveloper);
					
					String tempPublisher = arrPublisher.get(j);
					arrPublisher.set(j, arrPublisher.get(j+1));
					arrPublisher.set(j+1, tempPublisher);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		int flag, countNum, countHex;
		String alpa;
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.print("Input Game Name [ Must be alphanumberic and Unique ] : ");
			alpa = scan.nextLine();
			for (char c : alpa.toCharArray()) {
				if (!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if (Character.isDigit(c)) {
					countNum++;
				}
				if (Character.isLetter(c)) {
					countHex++;
				}
			}
		} while (flag == 1 || countNum == 0 || countHex == 0 || arrGameName.contains(alpa));
		
		int inputPrice = 0;
		do {
			System.out.print("Input Game Price [ Must be more than 10000 ] : ");
			inputPrice = scan.nextInt(); scan.nextLine();
		} while (!(inputPrice > 10000));
		
		String inputGenre;
		do {
			System.out.print("Input Genre [ MMORPG | RPG | FPS ] (Case Sensitive) : ");
			inputGenre = scan.nextLine();
		} while (!inputGenre.equals("MMORPG") && !inputGenre.equals("RPG") && !inputGenre.equals("FPS"));
		
		int velg;
		String betik;
		do {
			velg = 0;
			System.out.print("Input Developer Name [ Must be alphabetic and more than 5 characters ] : ");
			betik = scan.nextLine();
			for (char ch : betik.toCharArray()) {
				if (!Character.isAlphabetic(ch)) {
					velg = 1;
				}
			}
		} while (velg == 1 || !(betik.length()>5));
		
		String inputPublisher;
		do {
			System.out.print("Input publisher Name [ Must be more than 3 characters ] : ");
			inputPublisher = scan.nextLine();
		} while (!(inputPublisher.length()>3));
		
		String yesno;
		do {
			System.out.print("Are u sure want to buy this game [ Y | N ] ( Case Sensitive ) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			Random rand = new Random();
			char c1 = alpa.charAt(rand.nextInt(alpa.length()));
			char c2 = alpa.charAt(rand.nextInt(alpa.length()));
			String id = String.format("FT%c%c%d%d%d", c1, c2, (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));		
			
			arrID.add(id);
			arrGameName.add(alpa);
			arrGenre.add(inputGenre);
			arrPrice.add(inputPrice);
			arrDeveloper.add(betik);
			arrPublisher.add(inputPublisher);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FTeam();

	}

}
