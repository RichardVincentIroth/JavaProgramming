import java.util.ArrayList;
import java.util.Scanner;

public class PatientDataKerjaUlang {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<Integer> arrAge = new ArrayList<Integer>();
	ArrayList<String> arrAddress = new ArrayList<String>();
	
	ArrayList<String> cloneName = new ArrayList<String>(arrName);
	ArrayList<Integer> cloneAge = new ArrayList<Integer>(arrAge);
	ArrayList<String> cloneAddress = new ArrayList<String>(arrAddress);

	public PatientDataKerjaUlang() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Patient Data");
			System.out.println("++++++++++++");
			System.out.println("1. Input new Data");
			System.out.println("2. View Patient's Data");
			System.out.println("3. Exit");
			System.out.print("Choose : ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrName.size() == 0) {
			System.out.println("There is no data");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("========================================");
		String rapi = "%-5s | %-12s | %-5s | %-12s \n";
		System.out.printf(rapi, "No.", "Name", "Age", "Address");
		System.out.println("========================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, i + 1, arrName.get(i), arrAge.get(i), arrAddress.get(i));
		}
		System.out.println("========================================");
		
		int choose = 0;
		System.out.println("1. Sort data by Name Ascending");
		System.out.println("2. Sort data by Age Ascending");
		System.out.println("3. Back");
		System.out.print("Choose : ");
		try {
			choose = scan.nextInt();
		} catch (Exception e) {
			choose = -1;
		} scan.nextLine();
		switch (choose) {
		case 1:
			sortNameAsc();
			break;
		case 2:
			sortAgeAsc();
			break;
		case 3:
			return;

		default:
			break;
		}
		
		
		System.out.println("========================================");
		System.out.printf(rapi, "No.", "Name", "Age", "Address");
		System.out.println("========================================");
		for (int i = 0; i < cloneName.size(); i++) {
			System.out.printf(rapi, i + 1, cloneName.get(i), cloneAge.get(i), cloneAddress.get(i));
		}
		System.out.println("========================================");

	}

	private void sortAgeAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrAge.size(); i++) {
			for (int j = 0; j < arrAge.size() - 1; j++) {
				if (arrAge.get(j) > arrAge.get(j+1)) {
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempName = arrName.get(j);
					arrName.set(j, arrName.get(j+1));
					arrName.set(j+1, tempName);
					
					String tempAddress =  arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		System.out.println("========================================");
		String rapi = "%-5s | %-12s | %-5s | %-12s \n";
		System.out.printf(rapi, "No.", "Name", "Age", "Address");
		System.out.println("========================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, i + 1, arrName.get(i), arrAge.get(i), arrAddress.get(i));
		}
		System.out.println("========================================");
		
	}

	private void sortNameAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrName.size(); i++) {
			for (int j = 0; j < arrName.size() - 1; j++) {
				String kiri = arrName.get(j);
				String kanan = arrName.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempName = arrName.get(j);
					arrName.set(j, arrName.get(j+1));
					arrName.set(j+1, tempName);
					
					String tempAddress =  arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		System.out.println("========================================");
		String rapi = "%-5s | %-12s | %-5s | %-12s \n";
		System.out.printf(rapi, "No.", "Name", "Age", "Address");
		System.out.println("========================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, i + 1, arrName.get(i), arrAge.get(i), arrAddress.get(i));
		}
		System.out.println("========================================");
		
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String inputName;
		do {
			System.out.println("Input name : ");
			inputName = scan.nextLine();
		} while (!(inputName.length() >= 3) || !(inputName.length() <= 200));
		
		int inputAge = 0;
		do {
			System.out.println("Input age : ");
			try {
				inputAge = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Input must be numeric!");
				System.out.println(" ");
			} scan.nextLine();
		} while (!(inputAge >= 10) || !(inputAge <= 100));
		
		String inputAddress;
		do {
			System.out.println("Input address : ");
			inputAddress = scan.nextLine();
		} while (!(inputAddress.length() >= 5) || !(inputAddress.length() <= 30));
		
		System.out.println("Data has been successfully inserted!");
		
		arrName.add(inputName);
		arrAge.add(inputAge);
		arrAddress.add(inputAddress);
		
		cloneName = new ArrayList<String>(arrName);
		cloneAge = new ArrayList<Integer>(arrAge);
		cloneAddress = new ArrayList<String>(arrAddress);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PatientDataKerjaUlang();

	}

}
