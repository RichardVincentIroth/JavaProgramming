import java.util.ArrayList;
import java.util.Scanner;

public class PatientData {
	ArrayList<String> arrNama = new ArrayList<String>();
	ArrayList<Integer> arrAge = new ArrayList<Integer>();
	ArrayList<String> arrAddress = new ArrayList<String>();

	public PatientData() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("                Patient's Data");
			System.out.println("                ++++++++++++++");
			System.out.println("1. Input new Data");
			System.out.println("2. View Patient's Data");
			System.out.println("3. Exit");
			System.out.print("Choose : ");
			
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		if (arrNama.size() == 0) {
			System.out.println("There is no data here");
			System.out.println("Press enter to continue...");
			scan.nextLine();
			return;
		}
		System.out.println("============================================");
		String rapi = "%-8s | %-12s | %-8s | %-20s \n";
		System.out.printf(rapi, "No.", "Name", "Age", "Address");
		for (int i = 0; i < arrNama.size(); i++) {
			System.out.printf(rapi, i+1, arrNama.get(i), arrAge.get(i), arrAddress.get(i));
		}
		
		int milih = 0;
		System.out.println("1. Sort data by Name Ascending");
		System.out.println("2. Sort data by Name Descending");
		System.out.println("3. Sort data by Age Ascending");
		System.out.println("4. Sort data by Age Descending");
		System.out.println("5. Back");
		System.out.print(">> ");
		try {
			milih = scan.nextInt();
		} catch (Exception e) {
			milih = -1;
		} scan.nextLine();
		switch (milih) {
		case 1:
			sortNameAsc();
			view();
			break;
		case 2:
			sortNameDes();
			view();
			break;
		case 3:
			sortAgeAsc();
			view();
			break;
		case 4:
			sortAgeDes();
			view();
			break;
		case 5:
			return;

		default:
			break;
		}
		
	}

	private void sortAgeDes() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrNama.size(); i++) {
			for (int j = 0; j < arrNama.size() - 1; j++) {
				if (arrAge.get(j) < arrAge.get(j+1)) {
					String tempNama = arrNama.get(j);
					arrNama.set(j, arrNama.get(j+1));
					arrNama.set(j+1, tempNama);
					
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempAddress = arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		
	}

	private void sortAgeAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrNama.size(); i++) {
			for (int j = 0; j < arrNama.size() - 1; j++) {
				if (arrAge.get(j) > arrAge.get(j+1)) {
					String tempNama = arrNama.get(j);
					arrNama.set(j, arrNama.get(j+1));
					arrNama.set(j+1, tempNama);
					
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempAddress = arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		
	}

	private void sortNameDes() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrNama.size(); i++) {
			for (int j = 0; j < arrNama.size() - 1; j++) {
				String kiri = arrNama.get(j);
				String kanan = arrNama.get(j+1);
				if (kiri.compareTo(kanan) < 0) {
					String tempNama = arrNama.get(j);
					arrNama.set(j, arrNama.get(j+1));
					arrNama.set(j+1, tempNama);
					
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempAddress = arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		
	}

	private void sortNameAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrNama.size(); i++) {
			for (int j = 0; j < arrNama.size() - 1; j++) {
				String kiri = arrNama.get(j);
				String kanan = arrNama.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempNama = arrNama.get(j);
					arrNama.set(j, arrNama.get(j+1));
					arrNama.set(j+1, tempNama);
					
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempAddress = arrAddress.get(j);
					arrAddress.set(j, arrAddress.get(j+1));
					arrAddress.set(j+1, tempAddress);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String inputName;
		do {
			System.out.print("Input name [3..20]: ");
			inputName = scan.nextLine();
		} while (!(inputName.length()>=3) && !(inputName.length()>=20));
		
		int inputAge = 0;
		do {
			System.out.print("Input age [10..100]: ");
			try {
				inputAge = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Input must be numeric !");
			} scan.nextLine();
		} while (!(inputAge >= 10) || !(inputAge <= 100));
		
		String inputAddress;
		do {
			System.out.print("input address [5..30]: ");
			inputAddress = scan.nextLine();
		} while (!(inputAddress.length()>=5) || !(inputAddress.length()<=30));
		
		System.out.println("Data has been successfully inserted!");
		
		arrNama.add(inputName);
		arrAge.add(inputAge);
		arrAddress.add(inputAddress);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PatientData();

	}

}
