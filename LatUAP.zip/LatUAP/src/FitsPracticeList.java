import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class FitsPracticeList {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrPractice = new ArrayList<String>();
	ArrayList<Integer> arrSession = new ArrayList<Integer>();
	ArrayList<String> arrTopic = new ArrayList<String>();
	ArrayList<String> arrDifficulty = new ArrayList<String>();
	ArrayList<Double> arrViews = new ArrayList<Double>();

	public FitsPracticeList() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("FiTs Practice List");
			System.out.println("==================");
			System.out.println("1. Add new practice");
			System.out.println("2. View all practice");
			System.out.println("3. Update practice");
			System.out.println("4. Delete practice");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Congratulations, you succeeded in doing all the practice question that I made");
		System.out.println("I really aprreciate your hard work and good luck to all of you for the next semester");
		System.out.println("Good Byeeee :) - XX22-1");
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		String index;
		do {
			System.out.print("input Practice ID [ e.g. 001-FT-1 ] : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		
		arrID.remove(index);
		arrPractice.remove(index);
		arrSession.remove(index);
		arrTopic.remove(index);
		arrDifficulty.remove(index);
		arrViews.remove(index);
		
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		String index;
		do {
			System.out.print("input Practice ID [ e.g. 001-FT-1 ] : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		for (int i = 0; i < arrID.size(); i++) {
			if (arrID.get(i).equals(index)) {
				int inputSession = 0;
				do {
					System.out.print("Input Session Number [ Must be between 1 - 32 ] (Inclusive) : ");
					inputSession = scan.nextInt(); scan.nextLine();
				} while (!(inputSession >= 1) || !(inputSession <= 32));
				
				String inputDifficulty;
				int difficultyPoint = 0;
				do {
					System.out.print("Input Difficulty Level [ Easy | Medium | Hard ] (Case Sensitive) : ");
					inputDifficulty = scan.nextLine();
				} while (!inputDifficulty.equals("Easy") && !inputDifficulty.equals("Medium") && !inputDifficulty.equals("Hard"));
				if (inputDifficulty.equals("Easy")) {
					difficultyPoint = 1000;
				} else if (inputDifficulty.equals("Medium")) {
					difficultyPoint = 1500;
				} else if (inputDifficulty.equals("Hard")) {
					difficultyPoint = 2000;
				}
				
				Random rand = new Random();
				int oke = rand.nextInt(9001) + 1000;
				double view = 0;
				view = (arrPractice.get(i).length() * difficultyPoint);
				
				String id = String.format("%s%d", arrID.get(i).substring(0, 7), inputSession);
				if (arrID.contains(id)) {
					do {
						id = String.format("%d%d%d-FT-%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10), inputSession);
					} while (arrID.contains(id));
				}
				
				arrID.set(i, id);
				arrSession.set(i, inputSession);
				arrDifficulty.set(i, inputDifficulty);
				arrViews.set(i, view);
				
				System.out.println("Successfully Updated practice!");
			}
		}
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
		
	}
	
	private void view() {
		// TODO Auto-generated method stub
		sortSessionAsc();
		if (arrID.size() == 0) {
			System.out.println("There is no practice data!");
			System.out.println("Press Enter To Continue...");
			scan.hasNextLine();
			return;
		}
		System.out.println("======================================================================");
		String rapi = "| %-12s | %-25s | %-8s | %-20s | %-20s | %-8s |\n";
		System.out.printf(rapi, "Practice ID", "Practice Name", "Session", "Topic", "Difficulty Level", "Views");
		System.out.println("======================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			String rapi2 = "| %-12s | %-25s | %-8s | %-20s | %-20s | %-8.0f |\n";
			System.out.printf(rapi2, arrID.get(i), arrPractice.get(i), arrSession.get(i), arrTopic.get(i), arrDifficulty.get(i), arrViews.get(i));
		}
		System.out.println("======================================================================");
		
	}

	private void sortSessionAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				if (arrSession.get(j) > arrSession.get(j+1) || (arrSession.get(j).equals(arrSession.get(j+1)) && arrViews.get(j) < arrViews.get(j+1))) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempName = arrPractice.get(j);
					arrPractice.set(j, arrPractice.get(j+1));
					arrPractice.set(j+1, tempName);
					
					int tempSession = arrSession.get(j);
					arrSession.set(j, arrSession.get(j+1));
					arrSession.set(j+1, tempSession);
					
					String tempTopic = arrTopic.get(j);
					arrTopic.set(j, arrTopic.get(j+1));
					arrTopic.set(j+1, tempTopic);
					
					String tempDifficulty = arrDifficulty.get(j);
					arrDifficulty.set(j, arrDifficulty.get(j+1));
					arrDifficulty.set(j+1, tempDifficulty);
					
					double tempViews = arrViews.get(j);
					arrViews.set(j, arrViews.get(j+1));
					arrViews.set(j+1, tempViews);
				}
			}
		}
		
	}
	
	private void sortTopicAsc() {
		// misal kalau mau pakai String
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				if (arrTopic.get(j).compareTo( arrTopic.get(j+1)) > 0 || (arrTopic.get(j).equals(arrTopic.get(j+1)) && arrViews.get(j) < arrViews.get(j+1))) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempName = arrPractice.get(j);
					arrPractice.set(j, arrPractice.get(j+1));
					arrPractice.set(j+1, tempName);
					
					int tempSession = arrSession.get(j);
					arrSession.set(j, arrSession.get(j+1));
					arrSession.set(j+1, tempSession);
					
					String tempTopic = arrTopic.get(j);
					arrTopic.set(j, arrTopic.get(j+1));
					arrTopic.set(j+1, tempTopic);
					
					String tempDifficulty = arrDifficulty.get(j);
					arrDifficulty.set(j, arrDifficulty.get(j+1));
					arrDifficulty.set(j+1, tempDifficulty);
					
					double tempViews = arrViews.get(j);
					arrViews.set(j, arrViews.get(j+1));
					arrViews.set(j+1, tempViews);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String inputPractice;
		do {
			System.out.print("Input Practice Name [ Must be unique and more than 5 characters ] : ");
			inputPractice = scan.nextLine();
		} while (!(inputPractice.length()>5) || arrPractice.contains(inputPractice));
		
		int inputSession = 0;
		do {
			System.out.print("Input Session Number [ Must be between 1 - 32 ] (Inclusive) : ");
			inputSession = scan.nextInt(); scan.nextLine();
		} while (!(inputSession >= 1) || !(inputSession <= 32));
		
		String inputTopic;
		do {
			System.out.print("Input topic [ Must be atleast contain 2 words ] : ");
			inputTopic = scan.nextLine();
		} while (!(inputTopic.split(" ").length>=2));
		
		String inputDifficulty;
		int difficultyPoint = 0;
		do {
			System.out.print("Input Difficulty Level [ Easy | Medium | Hard ] (Case Sensitive) : ");
			inputDifficulty = scan.nextLine();
		} while (!inputDifficulty.equals("Easy") && !inputDifficulty.equals("Medium") && !inputDifficulty.equals("Hard"));
		if (inputDifficulty.equals("Easy")) {
			difficultyPoint = 1000;
		} else if (inputDifficulty.equals("Medium")) {
			difficultyPoint = 1500;
		} else if (inputDifficulty.equals("Hard")) {
			difficultyPoint = 2000;
		}
		
//		String ok = String.format("%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		Random rand = new Random();
		int oke = rand.nextInt(9001) + 1000;
		double view = 0;
		view = (inputPractice.length() * difficultyPoint);
		int x = (int) view;
		
		System.out.println("==================================================================");
		System.out.println("|                     Practice Information                       |");
		System.out.println("==================================================================");
		String id = String.format("%d%d%d-FT-%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10), inputSession);
		System.out.printf("| %-15s : %-25s |\n", "Practice ID", id);
		System.out.printf("| %-15s : %-25s |\n", "Practice Name", inputPractice);
		System.out.printf("| %-15s : %-25s |\n", "Session", inputSession);
		System.out.printf("| %-15s : %-25s |\n", "Topic", inputTopic);
		System.out.printf("| %-15s : %-25s |\n", "Difficulty Level", inputDifficulty);
		System.out.printf("| %-15s : %-25s |\n", "Difficulty Point", difficultyPoint);
		System.out.printf("| %-15s : %-25s |\n", "View", x);
		System.out.println("==================================================================");
		
		String yesno;
		do {
			System.out.print("Input Confirmation [ Y | N ] (Case Sensitive) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			arrID.add(id);
			arrPractice.add(inputPractice);
			arrSession.add(inputSession);
			arrTopic.add(inputTopic);
			arrDifficulty.add(inputDifficulty);
			arrViews.add(view);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FitsPracticeList();

	}

}
