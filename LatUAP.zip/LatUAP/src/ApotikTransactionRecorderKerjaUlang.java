import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ApotikTransactionRecorderKerjaUlang {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCustomer = new ArrayList<String>();
	ArrayList<String> arrPhone = new ArrayList<String>();
	ArrayList<String> arrMedicine = new ArrayList<String>();
	ArrayList<String> arrOrder = new ArrayList<String>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<Integer> arrTotalPrice = new ArrayList<Integer>();

	public ApotikTransactionRecorderKerjaUlang() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Apotik Transaction Recorder");
			System.out.println("===========================");
			System.out.println("1. Order Medicine");
			System.out.println("2. View Order History");
			System.out.println("3. Update Order History");
			System.out.println("4. Delete Order History");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank You :)");
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.println("input Order History Number : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= 3));
		
		arrID.remove(index - 1);
		arrCustomer.remove(index - 1);
		arrPhone.remove(index - 1);
		arrMedicine.remove(index - 1);
		arrOrder.remove(index - 1);
		arrQuantity.remove(index - 1);
		arrTotalPrice.remove(index - 1);
		
		System.out.println("Successfully Deleted Order History!");
		
	}

	private void update() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.println("input Order History Number : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= 3));
		
		String order;
		do {
			System.out.println("Input Order Address : ");
			order = scan.nextLine();
		} while (!order.contains("Street") && !order.contains("RT") && !order.contains("RW"));
		
		arrOrder.set(index - 1, order);
		System.out.println("Successfully Updated Order History!");
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no order medicine history!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("============================================================================");
		String rapi = "| %-5s | %-20s | %-20s | %-20s | %-15s | %-20s | %-10s | %-10s |\n";
		System.out.printf(rapi, "No", "Transaction ID", "Customer Name", "Phone Number", "Medicine", "Order Address", "Quantity", "Total Price");
		System.out.println("============================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, i + 1, arrID.get(i), arrCustomer.get(i), arrPhone.get(i), arrMedicine.get(i), arrOrder.get(i), arrQuantity.get(i), arrTotalPrice.get(i));
		}
		System.out.println("============================================================================");
		
	}

	private void order() {
		// TODO Auto-generated method stub
		int flag, countNum, countHex;
		String cusName;
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.println("Customer Name : ");
			cusName = scan.nextLine();
			for (char c : cusName.toCharArray()) {
				if (!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if (Character.isDigit(c)) {
					countNum++;
				}
				if (Character.isLetter(c)) {
					countHex++;
				}
			}
		} while (flag == 1 || countNum == 0 || countHex == 0 || !(cusName.length()>5));
		
		int velg;
		String phone;
		do {
			velg = 0;
			System.out.println("Input Phone Number : ");
			phone = scan.nextLine();
			for (char ch : phone.toCharArray()) {
				if (!Character.isDigit(ch) && ch != ' ') {
					velg = 1;
				}
			}
		} while (velg == 1 || !phone.startsWith("0"));
		
		String order;
		do {
			System.out.println("Input Order Address : ");
			order = scan.nextLine();
		} while (!order.contains("Street") && !order.contains("RT") && !order.contains("RW"));
		order = order.replace("RT", "").replace("RW", "").replace("Street", "");
		
		String medicine;
		int medicinePrice = 0;
		do {
			System.out.println("Input Medicine : ");
			medicine = scan.nextLine();
		} while (!medicine.equals("Panadole") && !medicine.equals("Vitaciman") && !medicine.equals("Combin"));
		if (medicine.equals("Panadole")) {
			medicinePrice = 10000;
		} else if (medicine.equals("Panadole")) {
			medicinePrice = 15000;
		} else if (medicine.equals("Panadole")) {
			medicinePrice = 20000;
		}
 		
		int quantity = 0;
		do {
			System.out.println("Input Quantity : ");
			quantity = scan.nextInt(); scan.nextLine();
		} while (!(quantity > 0));
		
		double totalPrice = 0;
		totalPrice = medicinePrice * quantity;
		int price = (int) totalPrice;
		
		System.out.println("Total Price : " + price);
		int money = 0;
		do {
			System.out.println("Input Money : ");
			money = scan.nextInt(); scan.nextLine();
		} while (!(money >= price));
		
		double change = 0;
		change = money - totalPrice;
		System.out.println("Change : " + change);
		char c1 = cusName.charAt(rand.nextInt(cusName.length()));
		char c2 = cusName.charAt(rand.nextInt(cusName.length()));
		int a1 = rand.nextInt(1000);
		String id = String.format("PI%c%c%03d", c1, c2, a1);
		
		arrID.add(id);
		arrCustomer.add(cusName);
		arrPhone.add(phone);
		arrMedicine.add(medicine);
		arrOrder.add(order);
		arrQuantity.add(quantity);
		arrTotalPrice.add(price);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ApotikTransactionRecorderKerjaUlang();

	}

}
