import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class FokemonT {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<String> arrType = new ArrayList<String>();
	ArrayList<Integer> arrHp = new ArrayList<Integer>();
	ArrayList<Integer> arrAttack = new ArrayList<Integer>();
	ArrayList<String> arrAbilities = new ArrayList<String>();

	public FokemonT() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("FokemonT");
			System.out.println("========");
			System.out.println("1. Insert a FokemonT");
			System.out.println("2. View Pokedex");
			System.out.println("3. Update FokemonT");
			System.out.println("4. Delete FokemonT");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank you :)");
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.print("Input FokemonT Number [ 1 - " + arrID.size() + " ] : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= arrID.size()));
		
		arrID.remove(index - 1);
		arrName.remove(index - 1);
		arrType.remove(index - 1);
		arrHp.remove(index - 1);
		arrAttack.remove(index - 1);
		arrAbilities.remove(index - 1);
		
		System.out.println("successfully Deleted FokemonT");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.print("Input FokemonT Number [ 1 - " + arrID.size() + " ] : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= arrID.size()));
		
		String gantiFokemon;
		do {
			System.out.print("Input FokemonT Type [ Fire | Grass | Water ] (Case Sensitive) : ");
			gantiFokemon = scan.nextLine();
		} while (!gantiFokemon.equals("Fire") && !gantiFokemon.equals("Grass") && !gantiFokemon.equals("Water"));
		
		arrType.set(index - 1, gantiFokemon);
		
		System.out.println("Successfully Update FokemonT!");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no FokemonT!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("============================================");
		String rapi = "| %-5s | %-12s | %-15s | %-15s | %-8s | %-8s | %-15s |\n";
		System.out.printf(rapi, "No", "FokemonT ID", "FokemonT Name", "FokemonT Type", "Hp", "Attack", "Abilities");
		System.out.println("============================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, i + 1, arrID.get(i), arrName.get(i), arrType.get(i), arrHp.get(i), arrAttack.get(i), arrAbilities.get(i));
		}
		System.out.println("============================================");
		
	}

	private void order() {
		// TODO Auto-generated method stub
		int velg;
		String fokemonName;
		do {
			velg = 0;
			System.out.print("Input FokemonT Name [ Must be alphabetic and Unique ] : ");
			fokemonName = scan.nextLine();
			for (char ch : fokemonName.toCharArray()) {
				if (!Character.isAlphabetic(ch)) {
					velg = 1;
				}
			}
		} while (velg == 1 || arrName.contains(fokemonName));
		
		String fokemonType;
		do {
			System.out.print("Input FokemonT Type [ Fire | Grass | Water ] (Case Sensitive) : ");
			fokemonType = scan.nextLine();
		} while (!fokemonType.equals("Fire") && !fokemonType.equals("Grass") && !fokemonType.equals("Water"));
		
		int fokemonHp = 0;
		do {
			System.out.print("Input FokemonT HP [ Must be between 100 - 1000 ] (Inclusive) : ");
			fokemonHp = scan.nextInt(); scan.nextLine();
		} while (!(fokemonHp >= 100) || !(fokemonHp <= 1000));
		
		int fokemonAttack = 0;
		do {
			System.out.print("Input FokemonT Attack [ Must be between 100 - 200 ] (Exclusive) : ");
			fokemonAttack = scan.nextInt(); scan.nextLine();
		} while (!(fokemonAttack > 100) || !(fokemonAttack < 200));
		
		String fokemonAbilities;
		do {
			System.out.print("Input FokemonT Abilities [ Must contain atleast 2 words ] : ");
			fokemonAbilities = scan.nextLine();
		} while (fokemonAbilities.split(" ").length<2);
		
		Random rand = new Random();
		char c1 = fokemonName.charAt(rand.nextInt(fokemonName.length()));
		char c2 = fokemonName.charAt(rand.nextInt(fokemonName.length()));
		String id = String.format("PI%c%c%d%d%d", c1, c2, (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		
		fokemonName = fokemonName.replace("www", "");
		
		arrID.add(id);
		arrName.add(fokemonName);
		arrType.add(fokemonType);
		arrHp.add(fokemonHp);
		arrAttack.add(fokemonAttack);
		arrAbilities.add(fokemonAbilities);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FokemonT();

	}

}
