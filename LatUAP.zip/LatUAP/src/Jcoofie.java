import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Jcoofie {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrCookieName = new ArrayList<String>();
	ArrayList<String> arrtopping = new ArrayList<String>();
	ArrayList<Double> arrPrice = new ArrayList<Double>();

	public Jcoofie() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Jcoofie");
			System.out.println("1. Bake Cookie");
			System.out.println("2. View Cookie");
			System.out.println("3. Research Cookie");
			System.out.println("4. Sell Cookie");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrCookieName.isEmpty()) {
					System.out.println("Press Enter To Continue");
					scan.nextLine();
				}
				break;
			case 3:
				research();
				break;
			case 4:
				sell();
				break;
			case 5:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void sell() {
		// TODO Auto-generated method stub
		if (arrCookieName.size() == 0) {
			return;
		}
		int sell = 0;
		System.out.println("Which cookie do you want to sell? [1-3]");
		System.out.print(">> ");
		sell = scan.nextInt(); scan.nextLine();
		System.out.println("+==============================+");
		System.out.println("|  Jco.oFie Cookie and Coffee  |");
		System.out.println("+==============================+");
		System.out.println("|                              |");
		System.out.println("| Your order:                  |");
		System.out.println("| Cookie: " + arrCookieName.get(sell - 1)+"|");
		System.out.println("| Subtotal: IDR " + arrPrice.get(sell - 1)+"|");
		System.out.println("|                              |");
		System.out.println("| Thank you for your pusrchase!|");
		System.out.println("|                              |");
		System.out.println("+==============================+");
	}

	private void research() {
		// TODO Auto-generated method stub
		view();
		if (arrCookieName.size() == 0) {
			return;
		}
		String cookie;
		System.out.println("Which cookie to research?");
		System.out.print(">> ");
		cookie = scan.nextLine();
//		boolean found = false;
		for (int i = 0; i < arrCookieName.size(); i++) {
			if (cookie.equals(arrCookieName.get(i))) {
//				found = true;
				Random rand = new Random();
				int r1 = 1 + rand.nextInt(10);
				if (r1 <=4) {
					arrPrice.set(i, arrPrice.get(i) * 1.2);
					System.out.println("The research was successful!");
					System.out.println("Cookie price is increased by 20%!");
				} else {
					arrPrice.set(i, arrPrice.get(i) * 0.5);
					System.out.println("The research was unsuccessful:(");
					System.out.println("Cookie pricee is cut by half!");
				}
				break;
			} else {
				System.out.println("Cookie not found!");
			}
		}
		
//		if (!found) {
//			System.out.println("Cookie not found!");
//		}
		
		
	}

	private void view() {
		// TODO Auto-generated method stub
		sortAsc();
		if (arrCookieName.size() == 0) {
			System.out.println("There are no available cookies to sell...");
			System.out.println("Let's start baking!");
			System.out.print("Press Enter To Continue");
			scan.nextLine();
			return;
		}
		String rapi1 = "+%-8s+%-20s+%-15s+%-15s+\n";
		System.out.printf(rapi1, "==========", "======================", "=================", "=================");
		String rapi2 = "| %-8s | %-20s | %-15s | %-15s |\n";
		System.out.printf(rapi2, "No", "Cookie Name", "topping", "Price");
		System.out.printf(rapi1, "==========", "======================", "=================", "=================");
		for (int i = 0; i < arrCookieName.size(); i++) {
			System.out.printf(rapi2, i+1, arrCookieName.get(i), arrtopping.get(i),  "IDR " +  arrPrice.get(i));
		}
		System.out.printf(rapi1, "==========", "======================", "=================", "=================");
	}

	private void sortAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrCookieName.size(); i++) {
			for (int j = 0; j < arrCookieName.size() - 1; j++) {
				String kiri = arrCookieName.get(j);
				String kanan = arrCookieName.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempCookie = arrCookieName.get(j);
					arrCookieName.set(j, arrCookieName.get(j+1));
					arrCookieName.set(j+1, tempCookie);
					
					String temptopping = arrtopping.get(j);
					arrtopping.set(j, arrtopping.get(j+1));
					arrtopping.set(j+1, temptopping);
					
					double tempPrice = arrPrice.get(j);
					arrPrice.set(j, arrPrice.get(j+1));
					arrPrice.set(j+1, tempPrice);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String cookieName;
		do {
			System.out.print("Cookie Name [5 - 20 character]: ");
			cookieName = scan.nextLine();
			if (!(cookieName.length()>5) || !(cookieName.length()<20)) {
				System.out.println("Cookie name must be between 5 and 20 characters!");
			}
		} while (!(cookieName.length()>5) || !(cookieName.length()<20));
		
		String topping;
		int toppingPrice = 0;
		do {
			System.out.print("Choose topping [Plain | Choco Chips | Almond][case sensitive]: ");
			topping = scan.nextLine();
			if (!topping.equals("Plain") && !topping.equals("Choco Chips") && !topping.equals("Almond")) {
				System.out.println("Topping must be either 'Plain', 'Choco Chips', or 'Almond'!");
			}
		} while (!topping.equals("Plain") && !topping.equals("Choco Chips") && !topping.equals("Almond"));
		if (topping.equals("Plain")) {
			toppingPrice = 5000;
		} else if (topping.equals("Choco Chips")) {
			toppingPrice = 7000;
		} else if (topping.equals("Almond")) {
			toppingPrice = 10000;
		}
		
		int basePrice = 0;
		do {
			System.out.print("Base Price [10000 - 20000]: ");
			basePrice = scan.nextInt(); scan.nextLine();
			if (!(basePrice > 10000) || !(basePrice < 20000)) {
				System.out.println("Base price must be between 10000 and 20000!");
			}
		} while (!(basePrice > 10000) || !(basePrice < 20000));
		
		System.out.println("New cookie added for sale!");
		
		double cookiePrice = 0;
		cookiePrice = basePrice + toppingPrice;
		
		arrCookieName.add(cookieName);
		arrtopping.add(topping);
		arrPrice.add(cookiePrice);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Jcoofie();

	}

}
