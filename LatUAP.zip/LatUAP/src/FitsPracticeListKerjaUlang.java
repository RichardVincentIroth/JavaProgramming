import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class FitsPracticeListKerjaUlang {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<Integer> arrSession = new ArrayList<Integer>();
	ArrayList<String> arrTopic = new ArrayList<String>();
	ArrayList<String> arrDifficulty = new ArrayList<String>();
	ArrayList<Integer> arrViews = new ArrayList<Integer>();

	public FitsPracticeListKerjaUlang() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("FiTs Practice List");
			System.out.println("==================");
			System.out.println("1. Add new practice");
			System.out.println("2. View all practice");
			System.out.println("3. Update practice");
			System.out.println("4. Delete practice");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrName.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrName.size() == 0) {
			return;
		}
		String index;
		do {
			System.out.println("Input Practice ID : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		
		for (int i = 0; i < arrName.size(); i++) {
			if (arrID.get(i).equals(index)) {
				int inputSession = 0;
				do {
					System.out.println("Input Session Number : ");
					inputSession = scan.nextInt(); scan.nextLine();
				} while (!(inputSession >= 1) || !(inputSession <= 12));
				
				String inputDifficulty;
				int difficultyPoint = 0;
				do {
					System.out.println("Input Difficulty : ");
					inputDifficulty = scan.nextLine();
				} while (!inputDifficulty.equals("Easy") && !inputDifficulty.equals("Medium") && !inputDifficulty.equals("Hard"));
				if (inputDifficulty.equals("Easy")) {
					difficultyPoint = 1000;
				} else if (inputDifficulty.equals("Medium")) {
					difficultyPoint = 1500;
				} else if (inputDifficulty.equals("Easy")) {
					difficultyPoint = 2000;
				}
				
				int x = rand.nextInt(9001) + 1000;
				double views = 0;
				views = (arrName.get(i).length() * difficultyPoint) + x;
				String id = String.format("%s-FT-%d", arrID.get(i).substring(0, 7), inputSession);
				if (arrID.contains(id)) {
					do {
						id = String.format("%d%d%d-FT-%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10), inputSession);
					} while (arrID.contains(id));
				}
				
				arrID.set(i, id);
				arrSession.set(i, inputSession);
				arrDifficulty.set(i, inputDifficulty);
				arrViews.set(i, (int) views);
			}
		}
		
	}

	private void view() {
		// TODO Auto-generated method stub
		sortAneh();
		if (arrName.size() == 0) {
			System.out.println("There is no practice data!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("================================================================");
		String rapi = "| %-12s | %-25s | %-8s | %-15s | %-15s | %-8s |\n";
		System.out.printf(rapi, "Practice ID", "Practice Name", "Session", "Topic", "Difficulty Level", "Views");
		System.out.println("================================================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrName.get(i), arrSession.get(i), arrTopic.get(i), arrDifficulty.get(i), arrViews.get(i));
		}
		System.out.println("================================================================");
		
	}

	private void sortAneh() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrName.size(); i++) {
			for (int j = 0; j < arrName.size() - 1; j++) {	
				if (arrSession.get(j) > arrSession.get(j+1) || (arrSession.get(j).equals(arrSession.get(j+1)) && arrViews.get(j) < arrViews.get(j+1))) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempName = arrName.get(j);
					arrName.set(j, arrName.get(j+1));
					arrName.set(j+1, tempName);
					
					int tempSession = arrSession.get(j);
					arrSession.set(j, arrSession.get(j+1));
					arrSession.set(j+1, tempSession);
					
					String tempTopic = arrTopic.get(j);
					arrTopic.set(j, arrTopic.get(j+1));
					arrTopic.set(j+1, tempTopic);
					
					String tempDifficulty = arrDifficulty.get(j);
					arrDifficulty.set(j, arrDifficulty.get(j+1));
					arrDifficulty.set(j+1, tempDifficulty);
					
					int tempViews = arrViews.get(j);
					arrViews.set(j, arrViews.get(j+1));
					arrViews.set(j+1, tempViews);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String inputPractice;
		do {
			System.out.println("Input Practice Name : ");
			inputPractice = scan.nextLine();
		} while (!(inputPractice.length()>5) || arrName.contains(inputPractice));
		
		int inputSession = 0;
		do {
			System.out.println("Input Session Number : ");
			inputSession = scan.nextInt(); scan.nextLine();
		} while (!(inputSession >= 1) || !(inputSession <= 12));
		
		String inputTopic;
		do {
			System.out.println("Input topic : ");
			inputTopic = scan.nextLine();
		} while (inputTopic.split(" ").length<2);
		
		String inputDifficulty;
		int difficultyPoint = 0;
		do {
			System.out.println("Input Difficulty : ");
			inputDifficulty = scan.nextLine();
		} while (!inputDifficulty.equals("Easy") && !inputDifficulty.equals("Medium") && !inputDifficulty.equals("Hard"));
		if (inputDifficulty.equals("Easy")) {
			difficultyPoint = 1000;
		} else if (inputDifficulty.equals("Medium")) {
			difficultyPoint = 1500;
		} else if (inputDifficulty.equals("Easy")) {
			difficultyPoint = 2000;
		}
		
		int x = rand.nextInt(9001) + 1000;
		int y = rand.nextInt(1000);
		double views = 0;
		views = (inputPractice.length() * difficultyPoint) + x;
		int levin = (int) views;
		
		String id = String.format("%03d-FT-%d", y, inputSession);
		System.out.println("==========================================================");
		System.out.println("|                      Practice Information              |");
		System.out.println("==========================================================");
		System.out.printf("| %-15s : %-20s |\n", "Practice ID", id);
		System.out.printf("| %-15s : %-20s |\n", "Practice Name", id);
		System.out.printf("| %-15s : %-20s |\n", "Session", id);
		System.out.printf("| %-15s : %-20s |\n", "Topic", id);
		System.out.printf("| %-15s : %-20s |\n", "Difficulty Level", id);
		System.out.printf("| %-15s : %-20s |\n", "Difficulty Point", id);
		System.out.printf("| %-15s : %-20s |\n", "Views", id);
		System.out.println("==========================================================");
		
		String yesno;
		do {
			System.out.println("Input Confirmation [ Y | N ] (Case Sensitive) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			arrID.add(id);
			arrName.add(inputPractice);
			arrSession.add(inputSession);
			arrTopic.add(inputTopic);
			arrDifficulty.add(inputDifficulty);
			arrViews.add(levin);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FitsPracticeListKerjaUlang();

	}

}
