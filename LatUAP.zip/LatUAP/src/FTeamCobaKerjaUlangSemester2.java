
public class FTeamCobaKerjaUlangSemester2 {

	public FTeamCobaKerjaUlangSemester2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
