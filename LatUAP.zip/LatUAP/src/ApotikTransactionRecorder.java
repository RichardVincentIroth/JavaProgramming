import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ApotikTransactionRecorder {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCustomer = new ArrayList<String>();
	ArrayList<String> arrPhone = new ArrayList<String>();
	ArrayList<String> arrMedicine = new ArrayList<String>();
	ArrayList<String> arrOrder = new ArrayList<String>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<Integer> arrTotalPrice = new ArrayList<Integer>();
	
	ArrayList<String> cloneID = new ArrayList<String>(arrID);
	ArrayList<String> cloneCustomer = new ArrayList<String>(arrCustomer);
	ArrayList<String> clonePhone = new ArrayList<String>(arrPhone);
	ArrayList<String> cloneMedicine = new ArrayList<String>(arrMedicine);
	ArrayList<String> cloneOrder = new ArrayList<String>(arrOrder);
	ArrayList<Integer> cloneQuantity = new ArrayList<Integer>(arrQuantity);
	ArrayList<Integer> cloneTotalPrice = new ArrayList<Integer>(arrTotalPrice);

	public ApotikTransactionRecorder() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Apotik Transaction Recorder");
			System.out.println("===========================");
			System.out.println("1. Order Medicine");
			System.out.println("2. View Order History");
			System.out.println("3. Update Order History");
			System.out.println("4. Delete Order History");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
				
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.print("Input Order History Number [ 1 - " + arrID.size() + " ] : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= arrID.size()));
		
		arrID.remove(index - 1);
		arrCustomer.remove(index - 1);
		arrPhone.remove(index - 1);
		arrMedicine.remove(index - 1);
		arrOrder.remove(index - 1);
		arrQuantity.remove(index - 1);
		arrTotalPrice.remove(index - 1);
		
		System.out.println("Successfully Deleted Order History!");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		int index = 0;
		do {
			System.out.print("Input Order History Number [ 1 - 3 ] : ");
			index = scan.nextInt(); scan.nextLine();
		} while (!(index >= 1) || !(index <= 3));
		
		String inputBaru;
		do {
			System.out.print("Input Order Address [ Must contain 'Street', 'RT', 'RW' ] (Case Sensitive) : ");
			inputBaru = scan.nextLine();
		} while (!inputBaru.contains("Street") && !inputBaru.contains("RT") && !inputBaru.contains("RW"));
		
		arrOrder.set(index - 1, inputBaru);
		
		System.out.println("Succesfully Update Order History!");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no order medicine history!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		cloneID = new ArrayList<String>(arrID);
		cloneCustomer = new ArrayList<String>(arrCustomer);
		clonePhone = new ArrayList<String>(arrPhone);
		cloneMedicine = new ArrayList<String>(arrMedicine);
		cloneOrder = new ArrayList<String>(arrOrder);
		cloneQuantity = new ArrayList<Integer>(arrQuantity);
		cloneTotalPrice = new ArrayList<Integer>(arrTotalPrice);
		System.out.println("============================================================================");
		String rapi = "| %-5s | %-20s | %-20s | %-20s | %-15s | %-20s | %-10s | %-10s |\n";
		System.out.printf(rapi, "No", "Transaction ID", "Customer Name", "Phone Number", "Medicine", "Order Address", "Quantity", "Total Price");
		System.out.println("============================================================================");
		for (int i = 0; i < cloneID.size(); i++) {
			System.out.printf(rapi, i + 1, cloneID.get(i), cloneCustomer.get(i), clonePhone.get(i), cloneMedicine.get(i), cloneOrder.get(i), cloneQuantity.get(i), cloneTotalPrice.get(i));
		}
		System.out.println("============================================================================");
		
		String ok;
		System.out.println("Sort by ID Ascending : ");
		ok = scan.nextLine();
		sortIDAsc();
		
		System.out.println("============================================================================");
		System.out.printf(rapi, "No", "Transaction ID", "Customer Name", "Phone Number", "Medicine", "Order Address", "Quantity", "Total Price");
		System.out.println("============================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, i + 1, arrID.get(i), arrCustomer.get(i), arrPhone.get(i), arrMedicine.get(i), arrOrder.get(i), arrQuantity.get(i), arrTotalPrice.get(i));
		}
		System.out.println("============================================================================");
	}

	private void sortIDAsc() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				String kiri = arrCustomer.get(j);
				String kanan = arrCustomer.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempCus = arrCustomer.get(j);
					arrCustomer.set(j, arrCustomer.get(j+1));
					arrCustomer.set(j+1, tempCus);
					
					String tempPhone = arrPhone.get(j);
					arrPhone.set(j, arrPhone.get(j+1));
					arrPhone.set(j+1, tempPhone);
					
					String tempMedicine = arrMedicine.get(j);
					arrMedicine.set(j, arrMedicine.get(j+1));
					arrMedicine.set(j+1, tempMedicine);
					
					String tempOrder = arrOrder.get(j);
					arrOrder.set(j, arrOrder.get(j+1));
					arrOrder.set(j+1, tempOrder);
					
					int tempQuantity = arrQuantity.get(j);
					arrQuantity.set(j, arrQuantity.get(j+1));
					arrQuantity.set(j+1, tempQuantity);
					
					int tempTotalPrice = arrTotalPrice.get(j);
					arrTotalPrice.set(j, arrTotalPrice.get(j+1));
					arrTotalPrice.set(j+1, tempTotalPrice);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		int flag, countNum, countHex;
		String alpa;
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.print("Input customer name [ Must be alphanumberic and more than 5 characters : ");
			alpa = scan.nextLine();
			for (char c : alpa.toCharArray()) {
				if (!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if (Character.isDigit(c)) {
					countNum++;
				}
				if (Character.isLetter(c)) {
					countHex++;
				}
			}
		} while (flag == 1 || countNum == 0 || countHex == 0 || !(alpa.length() > 5));
		
		int velg;
		String beric;
		do {
			velg = 0;
			System.out.print("Input Phone Number [ Must be numberic and starts with 0 ] : ");
			beric = scan.nextLine();
			for (char ch : beric.toCharArray()) {
				if (!Character.isDigit(ch) && ch != ' ') {
					velg = 1;
				}
				
			}
		} while (velg == 1 || !beric.startsWith("0"));
		
		String inputOrderAddress;
		do {
			System.out.print("Input Order Address [ Must contain 'Street', 'RT', 'RW' ] (Case Sensitive) : ");
			inputOrderAddress = scan.nextLine();
		} while (!inputOrderAddress.contains("Street") && !inputOrderAddress.contains("RT") && !inputOrderAddress.contains("RW"));
		
		String inputMedicine;
		int medicinePrice = 0;
		do {
			System.out.print("Input Medicine [ Panadole | Vitaciman | Combin ] (Case Sensitive) : ");
			inputMedicine = scan.nextLine();
		} while (!inputMedicine.equals("Panadole") && !inputMedicine.equals("Vitaciman") && !inputMedicine.equals("Combin"));
		if (inputMedicine.equals("Panadole")) {
			medicinePrice = 10000;
		} else if (inputMedicine.equals("Vitaciman")) {
			medicinePrice = 15000;
		} else if (inputMedicine.equals("Combin")) {
			medicinePrice = 20000;
		}
		
		int inputQuantity = 0;
		do {
			System.out.print("Input Quantity [ Must be more than 0 ] : ");
			inputQuantity = scan.nextInt(); scan.nextLine();
		} while (!(inputQuantity > 0));
		
		String yesno;
		do {
			System.out.print("Are u sure want to order this medine [ Y | N ] (Case Sensitive) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			int totalPrice = 0;
			totalPrice = medicinePrice * inputQuantity;
			System.out.println("Total Price : " + totalPrice);
			
			int inputMoney = 0;
			do {
				System.out.print("Input Money [ >= Total Price ] : ");
				inputMoney = scan.nextInt(); scan.nextLine();
			} while (!(inputMoney >= totalPrice));
			
			double change = 0;
			change = inputMoney - totalPrice;
			System.out.println("Change : " + change);
			
			Random rand = new Random();
			String ayam = alpa;
			char c1 = alpa.charAt(rand.nextInt(alpa.length()));
			char c2 = alpa.charAt(rand.nextInt(alpa.length()));
			String id = String.format("PI%c%c%d%d%d", c1, c2, (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
			
			arrID.add(id);
			arrCustomer.add(alpa);
			arrPhone.add(beric);
			arrMedicine.add(inputMedicine);
			arrOrder.add(inputOrderAddress);
			arrQuantity.add(inputQuantity);
			arrTotalPrice.add(totalPrice);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ApotikTransactionRecorder();

	}

}
