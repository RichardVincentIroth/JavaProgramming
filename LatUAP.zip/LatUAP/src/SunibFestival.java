import java.util.ArrayList;
import java.util.Scanner;

public class SunibFestival {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrGroup = new ArrayList<String>();
	ArrayList<String> arrIdea = new ArrayList<String>();
	ArrayList<String> arrLocation = new ArrayList<String>();
	ArrayList<String> arrFeedback = new ArrayList<String>();

	public SunibFestival() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Sunib Festival");
			System.out.println("==============");
			System.out.println("1. Register for the exhibition");
			System.out.println("2. View all exhibits");
			System.out.println("3. Update exhibits");
			System.out.println("4. Delete exhibits");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				if (!arrID.isEmpty()) {
					System.out.print("Press Enter To Continue...");
					scan.nextLine();
				}
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		String index;
		do {
			System.out.print("Input Table ID [ e.g. TB421 ] : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		
		arrID.remove(index);
		arrGroup.remove(index);
		arrIdea.remove(index);
		arrLocation.remove(index);
		arrFeedback.remove(index);
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrID.size() == 0) {
			return;
		}
		String index;
		do {
			System.out.print("Input Table ID [ e.g. TB421 ] : ");
			index = scan.nextLine();
		} while (!arrID.contains(index));
		
		for (int i = 0; i < arrID.size(); i++) {
			if (arrID.get(i).equals(index)) {
				String inputLocation;
				do {
					System.out.print("Input Location [ Must be ends with 'lt.1', 'lt.2', or lt.3 ] : ");
					inputLocation = scan.nextLine();
				} while (!inputLocation.endsWith("lt.1") && !inputLocation.endsWith("lt.2") && !inputLocation.endsWith("lt.3"));
				
				arrIdea.set(i, inputLocation);
				System.out.println("Successfully Updated Exhibit!");
			}
		}
		
	}

	private void view() {
		// TODO Auto-generated method stub
		sortIDDes();
		if (arrID.size() == 0) {
			System.out.println("There is no exhibition yet!");
			System.out.print("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("==================================");
		String rapi = "| %-8s | %-15s | %-20s | %-12s | %-20s |\n";
		System.out.printf(rapi, "Table ID", "Group Name", "Idea", "Location", "Feedback Link");
		System.out.println("==================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrGroup.get(i), arrIdea.get(i), arrLocation.get(i), arrFeedback.get(i));
		}
		System.out.println("==================================");
		
	}

	private void sortIDDes() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				String kiri = arrID.get(j);
				String kanan = arrID.get(j+1);
				if (kiri.compareTo(kanan) < 0) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempGroup = arrGroup.get(j);
					arrGroup.set(j, arrGroup.get(j+1));
					arrGroup.set(j+1, tempGroup);
					
					String tempIdea = arrIdea.get(j);
					arrIdea.set(j, arrIdea.get(j+1));
					arrIdea.set(j+1, tempIdea);
					
					String tempLocation = arrLocation.get(j);
					arrLocation.set(j, arrLocation.get(j+1));
					arrLocation.set(j+1, tempLocation);
					
					String tempFeedback = arrFeedback.get(j);
					arrFeedback.set(j, arrFeedback.get(j+1));
					arrFeedback.set(j+1, tempFeedback);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		int velg;
		String inputGroup;
		do {
			velg = 0;
			System.out.print("Input Group Name [ Must be alphabetic and Unique ] : ");
			inputGroup = scan.nextLine();
			for (char c : inputGroup.toCharArray()) {
				if (!Character.isAlphabetic(c) && c != ' ') {
					velg = 1;
				}
			}
		} while (velg == 1 || arrGroup.contains(inputGroup));
		
		String inputIdea;
		do {
			System.out.print("Input idea [ Must be atleast contain 3 words ] : ");
			inputIdea = scan.nextLine();
		} while (inputIdea.split(" ").length<3);
		
		String inputLocation;
		do {
			System.out.print("Input Location [ Must be ends with 'lt.1', 'lt.2', or lt.3 ] : ");
			inputLocation = scan.nextLine();
		} while (!inputLocation.endsWith("lt.1") && !inputLocation.endsWith("lt.2") && !inputLocation.endsWith("lt.3"));
		
		String inputFeedback;
		do {
			System.out.print("Input feedback link [ Must starts with 'forms.com/' ] : ");
			inputFeedback = scan.nextLine();
		} while (!inputFeedback.startsWith("forms.com/"));
		
		System.out.println("==================================================");
		System.out.println("|                Exhibition Information           ");
		System.out.println("==================================================");
		String id = String.format("TB%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		System.out.printf("| %-15s : %-20s |\n", "Table ID", id);
		System.out.printf("| %-15s : %-20s |\n", "Group Name", inputGroup);
		System.out.printf("| %-15s : %-20s |\n", "Idea", inputIdea);
		System.out.printf("| %-15s : %-20s |\n", "Location", inputLocation);
		System.out.printf("| %-15s : %-20s |\n", "Feedback Link", inputFeedback);
		System.out.println("==================================================");
		
		arrID.add(id);
		arrGroup.add(inputGroup);
		arrIdea.add(inputIdea);
		arrLocation.add(inputLocation);
		arrFeedback.add(inputFeedback);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SunibFestival();

	}

}
