import java.util.Random;

public class Coba {
	Random rand = new Random();

	public Coba() {
		// TODO Auto-generated constructor stub
		int x = rand.nextInt(58) + 65; // 10 - 15
		while (x >= 91 && x <= 96) {
			x = rand.nextInt(58) + 65;
		}
		char huruf = (char) x;
		System.out.println(huruf);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Coba();

	}

}
