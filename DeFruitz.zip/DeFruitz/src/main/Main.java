package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Fruit> arrFruit = new ArrayList<Fruit>();
	Random rand = new Random();
	
	private int balance = 1000;

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("+===+===+===+");
			System.out.println("+ De Fruitz +");
			System.out.println("+===+===+===+");			
			System.out.println(" BALANCE : " + balance);			
			System.out.println("1. Buy Fruit");
			System.out.println("2. Sell Fruit");
			System.out.println("3. View All Fruit");
			System.out.println("4. Exit Store");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				buy();
				break;
			case 2:
				sell();
				break;
			case 3:
				view();
				if (!arrFruit.isEmpty()) {
					System.out.println("");
					System.out.println("Press enter to continue...");
					sc.nextLine();
					System.out.println("=======================================================");
				}
				break;
			case 4:
				milih = exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void buy() {
		// TODO Auto-generated method stub
		int basePrice = rand.nextInt(50) + 50;
		
		String type;
		do {
			System.out.print("Input fruit type [Apple | Banana] (case insensitive) : ");
			type = sc.nextLine();
		} while (!type.equals("Apple") && !type.equals("Banana"));
		
		int weight = 0;
		do {
			System.out.print("Input weight (50-500)g (inclusive) : ");
			weight = sc.nextInt(); sc.nextLine();
		} while (!(weight >= 50) || !(weight <= 500));
		
		if (type.equals("Apple")) {
			String variety;
			do {
				System.out.print("Input apple variety [Fuji | Gala | Honeycrisp | Golden Delicious] (case sensitive) : ");
				variety = sc.nextLine();
			} while (!variety.equals("Fuji") && !variety.equals("Gala") && !variety.equals("Honeycrisp") && !variety.equals("Golden Delicious"));
			
			String id = String.format("AP%03d", (int) (Math.random()*1000));
			Apple apple = new Apple(basePrice, id, type, weight, variety);
			arrFruit.add(apple);
			
		} else if (type.equals("Banana")) {
			String ripness;
			do {
				System.out.print("Input banana ripness [Overripe | Semi-ripe | Ripe | Unripe] (case sensitive) : ");
				ripness = sc.nextLine();
			} while (!ripness.equals("Overripe") && !ripness.equals("Semi-ripe") && !ripness.equals("Ripe") && !ripness.equals("Unripe"));
			
			String id = String.format("BN%03d", (int) (Math.random()*1000));
			Banana banana = new Banana(basePrice, id, type, weight, ripness);
			arrFruit.add(banana);
			
		}
		
	}

	private void sell() {
		// TODO Auto-generated method stub
		if (arrFruit.isEmpty()) {
			return;
		}
		view();
		
		int index = 0;
		do {
			System.out.print("Select the index of fruit to be sold : ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1) || !(index <= arrFruit.size()));
		
		Fruit f = arrFruit.get(index - 1);
		
		System.out.println("Fruit sold for " + f.calculatePrice());
		
		balance += f.calculatePrice();
		
		arrFruit.remove(f);
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrFruit.isEmpty()) {
			System.out.println("There are no data!");
			return;
		}
		String rapi = "| %-5s | %-15s | %-15s | %-15s | %-15s | %-15s |\n";
		System.out.println("=========================================================");
		System.out.printf(rapi, "No.", "ID", "Type", "Weight", "Variety", "Ripeness");
		System.out.println("=========================================================");
		int index = 1;
		for (Fruit f : arrFruit) {
			System.out.printf(rapi, index, f.getId(), f.getType(), f.getWeight(),
					(f instanceof Apple) ? ((Apple)f).getVariety() : "-",
					(f instanceof Banana) ? ((Banana)f).getRipness() : "-"
					);
			System.out.println("=========================================================");
			index++;
		}
		
	}

	private int exit() {
		// TODO Auto-generated method stub
		String yesNo;
		do {
			System.out.print("Are you sure to exit? (y/n) : ");
			yesNo = sc.nextLine();
		} while (!yesNo.equals("y") && !yesNo.equals("n"));
		
		if (yesNo.equals("n")) {
			return 0;
		}
		return 4;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
