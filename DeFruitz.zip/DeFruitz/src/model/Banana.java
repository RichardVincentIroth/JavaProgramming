package model;

public class Banana extends Fruit {
	
	private String ripness;

	public Banana(int basePrice, String id, String type, int weight, String ripness) {
		super(id, type, weight);
		this.ripness = ripness;
	}

	public String getRipness() {
		return ripness;
	}

	public void setRipness(String ripness) {
		this.ripness = ripness;
	}
	
	public double calculatePrice() {
		double multiplier = 0;
		switch (getRipness()) {
		case "Overripe":
			multiplier = 1.3;
			break;
		case "Semi-ripe":
			multiplier = 1;
			break;
		case "Ripe":
			multiplier = 0.8;
			break;
		case "Unripe":
			multiplier = 0.6;
			break;
		
		}
		return (getBasePrice() * multiplier) + getWeight() * 1.2;
		
	}

}
