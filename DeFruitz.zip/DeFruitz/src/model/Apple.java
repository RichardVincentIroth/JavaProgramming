package model;

public class Apple extends Fruit {
	
	private String variety;

	public Apple(int basePrice, String id, String type, int weight, String variety) {
		super(id, type, weight);
		this.variety = variety;
	}

	public String getVariety() {
		return variety;
	}

	public void setVariety(String variety) {
		this.variety = variety;
	}
	
	public double calculatePrice() {
		double multiplier = 0;
		switch (variety) {
		case "Honecrisp":
			multiplier = 2;
			break;
		case "Fuji":
			multiplier = 1.6;
			break;
		case "Gala":
			multiplier = 1.3;
			break;
		case "Golden Delicious":
			multiplier = 1;
			break;		
		}
		
		return (getBasePrice() * multiplier) + getWeight() * 1.4;
	}
	
}
