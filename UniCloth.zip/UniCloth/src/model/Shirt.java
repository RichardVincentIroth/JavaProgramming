package model;

public class Shirt extends Clothes {

	public Shirt(String id, String name, String size, String type, double price) {
		super(id, name, size, type, price);
		
	}

	public double calculatePrice() {
		double addPrice = 0;
		switch (size) {
		case "S":
			addPrice = 0;
			break;
		case "M":
			addPrice = 0;
			break;
		case "L":
			addPrice = 0;
			break;
		case "XL":
			addPrice = price * 0.05;
			break;

		}
		return this.price + addPrice;
	}
	
}
