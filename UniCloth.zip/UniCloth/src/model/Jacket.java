package model;

public class Jacket extends Clothes {

	public Jacket(String id, String name, String size, String type, double price) {
		super(id, name, size, type, price);
	}

	public double calculatePrice() {
		double addPrice = 0;
		switch (type) {
		case "Bomber":
			addPrice = 0;
			break;
		case "Hoodie":
			addPrice = price * 0.1;
			break;

		}
		return this.price + addPrice;
	}

}
