import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Clothes> arrClothes = new ArrayList<Clothes>();
	Random rand = new Random();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("UniCloth");
			System.out.println("Bringing You the Element of Style.");
			System.out.println("1. Add new clothes");
			System.out.println("2. Update clothes");
			System.out.println("3. View all clothes");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				update();
				break;
			case 3:
				view();
				if (!arrClothes.isEmpty()) {
					System.out.println("");
					System.out.print("Press enter to continue..");
					sc.nextLine();
					System.out.println("");
				}
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		int choice = 0;
		do {
			System.out.println("What kind of clothes you want to add?");
			System.out.println("=====================================");
			System.out.println("1. Shirt");
			System.out.println("2. Jacket");
			System.out.println("0. Back"); 
			System.out.print(">> ");
			choice = sc.nextInt(); sc.nextLine();
			
			switch (choice) {
			case 1:
				addShirt();
				return;
			case 2:	
				addJacket();
				return;
				
			default:
				break;
			}
		} while (choice != 0);
		
	}

	private void addShirt() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Shirt name [5 - 20 characters & ends with 'shirt']: ");
			name = sc.nextLine();
		} while (!(name.length()>=5) || !(name.length()<=20) || !name.endsWith("shirt"));
		
		String size;
		do {
			System.out.print("Shirt size [S | M | L | XL](Case Sensitive): ");
			size = sc.nextLine();
		} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));
		
		String type;
		do {
			System.out.print("Shirt sleese type [Short | Long](Case Sensitive): ");
			type = sc.nextLine();
		} while (!type.equals("Short") && !type.equals("Long"));
		
		double price = 0;
		do {
			System.out.print("Shirt price [30000 - 250000]: ");
			price = sc.nextDouble(); sc.nextLine();
		} while (!(price >= 30000) || !(price <= 250000));
		
		String id;
		do {
			id = String.format("SRT%03d", (int) (Math.random()*1000));
		} while (isIdDuplicate(id));
		
		Shirt shirt = new Shirt(id, name, size, type, price);
		arrClothes.add(shirt);
		
		System.out.println("New shirt added!");
		System.out.println("");
		System.out.println("Press enter to continue..");
		sc.nextLine();
		
		
	}

	private void addJacket() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Jacket name [5 - 20 characters & ends with 'jacket']: ");
			name = sc.nextLine();
		} while (!(name.length()>=5) || !(name.length()<=20) || !name.endsWith("jacket"));
		
		String size;
		do {
			System.out.print("Jacket size [S | M | L | XL](Case Sensitive): ");
			size = sc.nextLine();
		} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));
		
		String type;
		do {
			System.out.print("Jacket type [Bomber | Hoodie](Case Sensitive): ");
			type = sc.nextLine();
		} while (!type.equals("Bomber") && !type.equals("Hoodie"));
		
		double price = 0;
		do {
			System.out.print("Shirt price [150000 - 500000]: ");
			price = sc.nextDouble(); sc.nextLine();
		} while (!(price >= 150000) || !(price <= 500000));
		
		String id;
		do {
			id = String.format("JCK%03d", (int) (Math.random()*1000));
		} while (isIdDuplicate(id));
		
		Shirt shirt = new Shirt(id, name, size, type, price);
		arrClothes.add(shirt);
		
		System.out.println("New shirt added!");
		System.out.println("");
		System.out.print("Press enter to continue..");
		sc.nextLine();
		
	}
	
	private boolean isIdDuplicate(String id) {
	    for (Clothes shirt : arrClothes) {
	        if (shirt.getId().equals(id)) {
	            return true;
	        }
	    }
	    return false;
	}
	
	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrClothes.isEmpty()) {
			return;
		}
		String index;
		do {
			System.out.print("ID to update [0 to go back]: ");
			index = sc.nextLine();
			
			for (Clothes c : arrClothes) {
				if (c.getId().equals(index)) {
					if (c instanceof Shirt) {
						String name;
						do {
							System.out.print("Shirt name [5 - 20 characters & ends with 'shirt']: ");
							name = sc.nextLine();
						} while (!(name.length()>=5) || !(name.length()<=20) || !name.endsWith("shirt"));
						
						String size;
						do {
							System.out.print("Shirt size [S | M | L | XL](Case Sensitive): ");
							size = sc.nextLine();
						} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));
						
						String type;
						do {
							System.out.print("Shirt sleese type [Short | Long](Case Sensitive): ");
							type = sc.nextLine();
						} while (!type.equals("Short") && !type.equals("Long"));
						
						double price = 0;
						do {
							System.out.print("Shirt price [30000 - 250000]: ");
							price = sc.nextDouble(); sc.nextLine();
						} while (!(price >= 30000) || !(price <= 250000));
						
						c.setName(name);
						c.setSize(size);
						c.setType(type);
						c.setPrice(price);
						
					} else if (c instanceof Jacket) {
						String name;
						do {
							System.out.print("Jacket name [5 - 20 characters & ends with 'jacket']: ");
							name = sc.nextLine();
						} while (!(name.length()>=5) || !(name.length()<=20) || !name.endsWith("jacket"));
						
						String size;
						do {
							System.out.print("Jacket size [S | M | L | XL](Case Sensitive): ");
							size = sc.nextLine();
						} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));
						
						String type;
						do {
							System.out.print("Jacket type [Bomber | Hoodie](Case Sensitive): ");
							type = sc.nextLine();
						} while (!type.equals("Bomber") && !type.equals("Hoodie"));
						
						double price = 0;
						do {
							System.out.print("Shirt price [150000 - 500000]: ");
							price = sc.nextDouble(); sc.nextLine();
						} while (!(price >= 150000) || !(price <= 500000));
						
						c.setName(name);
						c.setSize(size);
						c.setType(type);
						c.setPrice(price);
						
					}
					
					System.out.println("Shirt " + index + " updated!");
					System.out.println("");
					System.out.print("Press enter to continue..");
					sc.nextLine();
					
					return;
				}
			}
			
		} while (!index.equals("0"));
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrClothes.isEmpty()) {
			System.out.println("Clothes empty!");
			System.out.println("");
			System.out.print("Press enter to continue..");
			sc.nextLine();
			return;
		}
		String rapi = "| %-5s | %-10s | %-20s | %-10s | %-10s | %-10s |\n";
		System.out.println("+===============================================================+");
		System.out.printf(rapi, "No", "ID", "Name", "Type", "Size", "Price");
		System.out.println("+===============================================================+");
		int index = 1;
		String rapiIsi = "| %-5s | %-10s | %-20s | %-10s | %-10s | %-10.0f |\n";
		for (Clothes c : arrClothes) {
			System.out.printf(rapiIsi, index, c.getId(), c.getName(), c.getType(), c.getSize(), c.calculatePrice());
			index++;
		}
		System.out.println("+===============================================================+");
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank you!");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
