import java.util.Scanner;

public class Main2 {

	public Main2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int kembali = 0;
		while (kembali != 2) {
			System.out.println("Build Your Own Guitar!");
			System.out.println("======================");
			System.out.println("1. Build Guitar");
			System.out.println("2. Exit");
			System.out.println("Choose: ");
			
			int guitar = scan.nextInt(); scan.nextLine();
			String inputguitarname;
			String inputguitartype;
			int amountofstring = 0;
			String name;
			String inputguitarmanufacturer;
			String creatorname;
			String contactnumber;
			int harga = 0;
			int price = 0;
			int price6strings = 0;
			boolean error = true;
			String yesno;
			switch (guitar) {
			case 1:
				do {
					System.out.println("Input Guitar Name [5 - 30 Characters] : ");
					inputguitarname = scan.nextLine();
				} while (inputguitarname.length()<5 || inputguitarname.length()>30);
				
				do {
					System.out.println("Input Guitar Type [Acoustic | Electric | Bass] : ");
					inputguitartype = scan.nextLine();
				} while (!inputguitartype.equals("Acoustic") && !inputguitartype.equals("Electric") && !inputguitartype.equals("Bass"));
				if (inputguitartype.equals("Acoustic")) {
					harga = 500;
				} else if (inputguitartype.equals("Electric")) {
					harga = 900;
				} else if (inputguitartype.equals("Bass")) {
					harga = 400;
				}
				
				do {
					System.out.println("Input amount of string [at least 1] : ");
					amountofstring = scan.nextInt(); scan.nextLine();
				} while (amountofstring < 0);
				
				do {
					System.out.println("Input guitar manufacturer [must end with ',Inc.'] : ");
					inputguitarmanufacturer = scan.nextLine();
				} while (!inputguitarmanufacturer.endsWith(",Inc."));
				
				do {
					System.out.println("Input guitar creator name [must begin with 'Mr.' or 'Ms.'] : ");
					creatorname = scan.nextLine();
					if (creatorname.length()>7 && creatorname.length()<15) {
						if (creatorname.startsWith("Mr.") && creatorname.startsWith("Ms.")); {
							error = false;
						}
					}
				} while (error);
				
//				do {
//					System.out.println("input guitar creator contact number [must be 9 digits or numeric] : ");
//					panjang = scan.nextBoolean();
//				} while (String.valueOf(contactnumber).length()<9);
				
				do {
					System.out.println("Input guitar creator contact number [must be 9 digits or numeric] : ");
					contactnumber = scan.nextLine();
				} while (!(contactnumber.length()>8) || !(contactnumber.length()<10));
				
				System.out.println("Y | N");
				yesno = scan.nextLine();
				if (yesno.equals("N")) {
					kembali = 1;
				} else if (yesno.equals("Y")) {
					kembali = 2;
					price = harga + (amountofstring - 5)*5;
					price6strings = harga + 5;
					if (amountofstring <= 6) {
						System.out.println("Guitar Specifications");
						System.out.println("=====================");
						System.out.println("Guitar Name : " + inputguitarname);
						System.out.println("Guitar Type : " + inputguitartype);
						System.out.println("Guitar Strings : " + amountofstring);
						System.out.println("Guitar Manufacturer : " + inputguitarmanufacturer);
						System.out.println("---------------------");
						System.out.println("Total Price : " + price);
						System.out.println(" ");
						System.out.println("Creator Name : " + creatorname);
						System.out.println("Creator Contact Number : " + contactnumber);
						System.out.println("=====================");
						System.out.println(" ");
						System.out.println("Thank for your purchase!");
					} else if (amountofstring > 6) {
						System.out.println("Guitar Specifications");
						System.out.println("=====================");
						System.out.println("Guitar Name : " + inputguitarname);
						System.out.println("Guitar Type : " + inputguitartype);
						System.out.println("Guitar Strings : " + amountofstring);
						System.out.println("Guitar Manufacturer : " + inputguitarmanufacturer);
						System.out.println("---------------------");
						System.out.println("Total Price : " + price6strings);
						System.out.println(" ");
						System.out.println("Creator Name : " + creatorname);
						System.out.println("Creator Contact Number : " + contactnumber);
						System.out.println("=====================");
						System.out.println(" ");
						System.out.println("Thank for your purchase!");
					}
				}
				
				
//				System.out.println("Guitar Specifications");
//				System.out.println("=====================");
//				System.out.printf("Guitar Name : ", inputguitarname);
//				System.out.printf("Guitar Type : ", inputguitartype);
//				System.out.printf("Guitar Strings : ", amountofstring);
//				System.out.printf("Guitar Manufacturer : ", inputguitarmanufacturer);
//				System.out.println("---------------------");
//				System.out.printf("Total Price : ", inputguitarname);
//				System.out.println(" ");
//				System.out.printf("Creator Name : ", creatorname);
//				System.out.printf("Creator Contact Number : ", contactnumber);
//				System.out.println("=====================");
//				System.out.println(" ");
//				System.out.println("Thank for your purchase!");
				break;

			case 2:
				System.out.println("Thanks for using our application :)");
				break;
			}
		}
		

	}

}
