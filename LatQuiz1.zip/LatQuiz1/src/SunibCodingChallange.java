import java.util.Scanner;

public class SunibCodingChallange {

	public SunibCodingChallange() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int kembali = 0;
		while (kembali != 2) {
			System.out.println("Sunib Coding Challange");
			System.out.println("======================");
			System.out.println("1. Register Sunib Coding Challange");
			System.out.println("2. Exit");
			System.out.println(">> ");
			
			String studentid;
			String fullname;
			int age = 0;
			String gender;
			int genderpoint = 0;
			String email;
			String department;
			int dprpoint = 0;
			String paymentmethod;
			int paymentpoint = 0;
			String register;
			float totaldiscount = 0;
			float registrationprice = 0;
			int inputmoney = 0;
			float change = 0;
			
			int kuy = scan.nextInt(); scan.nextLine();
			switch (kuy) {
			case 1:
				do {
					System.out.println("Input Student ID [ Must starts with 26 or 27 ] : ");
					studentid = scan.nextLine();
				} while (!studentid.startsWith("26") && !studentid.startsWith("27"));
				
				do {
					System.out.println("Input Full Name [ Must be between 5 - 25 characters ] : ");
					fullname = scan.nextLine();
				} while (!(fullname.length()>5) || !(fullname.length()<25));
				
				do {
					System.out.println("Input Age [ Must be between 17 - 21 ] : ");
					age = scan.nextInt(); scan.nextLine();
				} while (!(age > 17) || !(age < 21));
				
				do {
					System.out.println("Input Gender [ Female | Male ] ( Case Sensitive ) : ");
					gender = scan.nextLine();
				} while (!gender.equals("Female") && !gender.equals("Male"));
				if (gender.equals("Female")) {
					genderpoint = 20;
				} else if (gender.equals("Male")) {
					genderpoint = 10;
				}
				
				do {
					System.out.println("Input Email [ Must ends with @gmail.com ] : ");
					email = scan.nextLine();
				} while (!email.endsWith("@gmail.com"));
				
				do {
					System.out.println("Input Department [ SOCS | SOIS | SOD ] ( Case Sensitive ) : ");
					department = scan.nextLine();
				} while (!department.equals("SOCS") && !department.equals("SOIS") && !department.equals("SOD"));
				if (department.equals("SOCS")) {
					dprpoint = 20;
				} else if (department.equals("SOIS")) {
					dprpoint = 30;
				} else if (department.equals("SOD")) {
					dprpoint = 25;
				}
				
				do {
					System.out.println("Input Payment Method [ Cash | Transfer | QRIS ] ( Case Sensitive ) : ");
					paymentmethod = scan.nextLine();
				} while (!paymentmethod.equals("Cash") && !paymentmethod.equals("Transfer") && !paymentmethod.equals("QRIS"));
				if (paymentmethod.equals("Cash")) {
					paymentpoint = 0;
				} else if (paymentmethod.equals("Transfer")) {
					paymentpoint = 5;
				} else if (paymentmethod.equals("QRIS")) {
					paymentpoint = 10;
				}
				
				System.out.println("Are u sure want to register [ Y | N ] ( Case Sensitive ) : ");
				register = scan.nextLine();
//				if (register.equals("Y")) {
//					kembali = 2;
//				} else if (register.equals("N")) {
//					kembali = 1;
//				}
				if (register.equals("N")) {
					kembali = 1;
					break;
				} else if (register.equals("Y")) {
					kembali = 2;
					totaldiscount = dprpoint + paymentpoint + genderpoint;
					registrationprice = 100000 - (100000*(totaldiscount/100));
					
					
					System.out.println("============================================");
					System.out.println("|         Registration Information         |");
					System.out.println("============================================");
					System.out.printf("|%-12s%-28s|\n", "Student ID = ", studentid);
					System.out.printf("|%-12s%-28s|\n", "Full Name = ", fullname);
					System.out.printf("|%-12s%-28s|\n", "Age = ", age);
					System.out.printf("|%-12s%-28s|\n", "Gender = ", gender);
					System.out.printf("|%-12s%-28s|\n", "Email = ", email);
					System.out.printf("|%-12s%-28s|\n", "Department = ", department);
					System.out.printf("|%-12s%-28s|\n", "Total Discount = ", totaldiscount + "%");
					System.out.printf("|%-12s%-28s|\n", "Registation Price = ", registrationprice);
					System.out.printf("|%-12s%-28s|\n", "Payment Method = ", paymentmethod);
					System.out.println("============================================");
					
					do {
						System.out.println("Input Money [ >= Regristration Price ] : ");
						inputmoney = scan.nextInt(); scan.nextLine();
					} while (inputmoney < registrationprice);
					
					change = inputmoney - registrationprice;
					System.out.println("Change : " + change);
					
					System.out.println("Good Luck For Your Competition :)");
				}
//				kembali = 2;
//				totaldiscount = dprpoint + paymentpoint + genderpoint;
//				registrationprice = 100000 - (100000*(totaldiscount/100));
//				
//				
//				System.out.println("============================================");
//				System.out.println("|         Registration Information         |");
//				System.out.println("============================================");
//				System.out.printf("|%-12s%-28s|\n", "Student ID = ", studentid);
//				System.out.printf("|%-12s%-28s|\n", "Full Name = ", fullname);
//				System.out.printf("|%-12s%-28s|\n", "Age = ", age);
//				System.out.printf("|%-12s%-28s|\n", "Gender = ", gender);
//				System.out.printf("|%-12s%-28s|\n", "Email = ", email);
//				System.out.printf("|%-12s%-28s|\n", "Department = ", department);
//				System.out.printf("|%-12s%-28s|\n", "Total Discount = ", totaldiscount, "%");
//				System.out.printf("|%-12s%-28s|\n", "Registation Price = ", registrationprice);
//				System.out.printf("|%-12s%-28s|\n", "Payment Method = ", paymentmethod);
//				System.out.println("============================================");
//				
//				do {
//					System.out.println("Input Money [ >= Regristration Price ] : ");
//					inputmoney = scan.nextInt(); scan.nextLine();
//				} while (inputmoney < registrationprice);
//				
//				change = inputmoney - registrationprice;
//				System.out.printf("Change : ", change);
//				
//				System.out.println("Good Luck For Your Competition :)");
				break;
			case 2:
				System.out.println("Embrace the code, compete with precision, and let algorithms define victory");
				break;

			default:
				kembali = 1;
				break;
			}
		}
		

	}

}
