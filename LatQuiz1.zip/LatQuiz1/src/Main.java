import java.util.Scanner;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("FixTue");
		System.out.println("======");
		System.out.println("1. Order FixTue");
		System.out.println("2. Exit");
		System.out.println(">> ");
		
		int menu = scan.nextInt(); scan.nextLine();
		switch (menu) {
		case 1:
			System.out.println("Input Customer Name [ e.g. Fred ] : ");
			String customername = scan.nextLine();
			System.out.println("Choose Product [ Fresh Ice Cream | Milk Tea ] : ");
			String product = scan.nextLine();
			String payment = null;
			int hargapayment = 0;
			int totaldiscount = 0;
			int hargatopping = 0;
			int hargaice = 0;
			int quantity = 0;
			int hargadrink = 0;
			int hargacup = 0;
			float totalprice = 0;
			float totalakhir = 0;
			float change = 0;
			if (product.equalsIgnoreCase("Fresh Ice Cream")) {
				System.out.println("Input Ice Cream Name [ Vanilla Ice Cream | Boba Sundae | Oreo Sundae ] : ");
				String icecreamname = scan.nextLine();
//				int hargaice = 0;
				if (icecreamname.equalsIgnoreCase("Vanilla Ice Cream")) {
					hargaice = 12000;
				} else if (icecreamname.equalsIgnoreCase("Boba Sundae")) {
						hargaice = 16000;
				} else if (icecreamname.equalsIgnoreCase("Oreo Sundae")) {
						hargaice = 14000;
					} System.out.println("Additional Topping [ Yes | No ] : ");
					String topping = scan.nextLine();
					if (topping.equalsIgnoreCase("Yes")) {
						System.out.println("Input Additional Topping [ Jelly | Cookies ] : ");
					} String addtopping = scan.nextLine();
//					int hargatopping = 0;
//					int quantity = 0;
					if (addtopping.equalsIgnoreCase("Jelly")) {
						hargatopping = 2000;
						System.out.println("Input Quantity [ e.g. 10 ] : ");
						quantity = scan.nextInt(); scan.nextLine();
						System.out.println("Input Payment Method [ QRIS | Transfer ] : ");
						payment = scan.nextLine();
						if (payment.equalsIgnoreCase("QRIS")) {
							hargapayment = 10;
						} else if (payment.equalsIgnoreCase("Transfer")) {
							hargapayment = 5;
						}
						
						}
					 if (addtopping.equalsIgnoreCase("Cookies")) {
						hargatopping = 5000;
						System.out.println("Input Quantity [ e.g. 10 ] : ");
						quantity = scan.nextInt(); scan.nextLine();
						System.out.println("Input Payment Method [ QRIS | Transfer ] : ");
						payment = scan.nextLine();
						if (payment.equalsIgnoreCase("QRIS")) {
							hargapayment = 10;
						} else if (payment.equalsIgnoreCase("Transfer")) {
							hargapayment = 5;
						}
					} else if (topping.equalsIgnoreCase("No")) {
						hargatopping = 0;
						System.out.println("Input Quantity [ e.g. 10 ] : ");
						quantity = scan.nextInt(); scan.nextLine();
						System.out.println("Input Payment Method [ QRIS | Transfer ] : ");
						payment = scan.nextLine();
//						int hargapayment = 0;
						if (payment.equalsIgnoreCase("QRIS")) {
							hargapayment = 10;
						} else if (payment.equalsIgnoreCase("Transfer")) {
							hargapayment = 5;
						}
//						int totalprice = (hargaice + hargatopping)*quantity;
//						System.out.println(totalprice);
						
//						int totaldiscount = customername.length() + hargapayment;
//						float totalakhir = totalprice - (totalprice*(totaldiscount/100));
						if (totalprice > 100000) {
							totaldiscount = customername.length() + hargapayment;
							 totalprice = (hargaice + hargatopping)*quantity;
							 totalakhir = totalprice - (totalprice*(totaldiscount/100));
							String billid = String.format("BL%d%d%d", (int) ((Math.random()*10)), (int) ((Math.random()*10)), (int) ((Math.random()*10))); 
							System.out.println("=====================================================");
							System.out.println("|                      Bill ID                      |");
							System.out.println("=====================================================");
							System.out.printf("|%-12s%-24s|\n", "Bill ID                  : ", billid);
							System.out.printf("|%-12s%-24s|\n", "Customer Name            : ", customername);
							System.out.printf("|%-12s%-24s|\n", "Product Name             : ", product);
							System.out.printf("|%-12s%-24s|\n", "Ice Cream Name           : ", icecreamname);
							System.out.printf("|%-12s%-24s|\n", "Ice Cream Price          : ", hargaice);
							System.out.printf("|%-12s%-24s|\n", "Additional Topping       : ", addtopping);
							System.out.printf("|%-12s%-24s|\n", "Additional Topping Price : ", hargatopping);
							System.out.printf("|%-12s%-24s|\n", "Quantity                 : ", quantity);
							System.out.printf("|%-12s%-24s|\n", "Payment Method           : ", payment);
							System.out.printf("|%-12s%-24s|\n", "Total Discount           : ", totaldiscount + "%");
							System.out.printf("|%-12s%-24s|\n", "Total Price              : ", totalakhir);
							System.out.println("=====================================================");
							System.out.println("Input Money [ >= Total Price ] : ");
							int money = scan.nextInt();
							change = money - totalakhir;
							if (money > totalprice) {
								System.out.printf("Change : ", change);
								System.out.println(" ");
								System.out.println("\nThank you for your purchase :)");
							} else if (money < totalprice) {
								System.out.println("Saldo anda tidak mencukupi");
							}
						} else if (totalprice < 100000) {
							totaldiscount = customername.length() + hargapayment;
							 totalprice = (hargaice + hargatopping)*quantity;
							 totalakhir = totalprice - (totalprice*(totaldiscount/100));
							String billid = String.format("BL%d%d%d", (int) ((Math.random()*10)), (int) ((Math.random()*10)), (int) ((Math.random()*10))); 
							System.out.println("=====================================================");
							System.out.println("|                      Bill ID                      |");
							System.out.println("=====================================================");
							System.out.printf("|%-12s%-24s|\n", "Bill ID                  : ", billid);
							System.out.printf("|%-12s%-24s|\n", "Customer Name            : ", customername);
							System.out.printf("|%-12s%-24s|\n", "Product Name             : ", product);
							System.out.printf("|%-12s%-24s|\n", "Ice Cream Name           : ", icecreamname);
							System.out.printf("|%-12s%-24s|\n", "Ice Cream Price          : ", hargaice);
							System.out.printf("|%-12s%-24s|\n", "Additional Topping       : ", addtopping);
							System.out.printf("|%-12s%-24s|\n", "Additional Topping Price : ", hargatopping);
							System.out.printf("|%-12s%-24s|\n", "Quantity                 : ", quantity);
							System.out.printf("|%-12s%-24s|\n", "Payment Method           : ", payment);
							System.out.printf("|%-12s%-24s|\n", "Total Discount           : ", "0%");
							System.out.printf("|%-12s%-24s|\n", "Total Price              : ", totalprice);
							System.out.println("=====================================================");
							System.out.println("Input Money [ >= Total Price ] : ");
							int money = scan.nextInt();
							change = money - totalprice;
							if (money > totalprice) {
								System.out.printf("Change : ", change);
								System.out.println(" ");
								System.out.println("\nThank you for your purchase :)");
							} else if (money < totalprice) {
								System.out.println("Saldo anda tidak mencukupi");
							}
							
						}
						
					} 
//					 totaldiscount = customername.length() + hargapayment;
//					 totalprice = (hargaice + hargatopping)*quantity;
//					 totalakhir = totalprice - (totalprice*(totaldiscount/100));
//					String billid = String.format("BL%d%d%d", (int) ((Math.random()*10)), (int) ((Math.random()*10)), (int) ((Math.random()*10))); 
//					System.out.println("=====================================================");
//					System.out.println("|                      Bill ID                      |");
//					System.out.println("=====================================================");
//					System.out.printf("|%-12s%-24s|\n", "Bill ID                  : ", billid);
//					System.out.printf("|%-12s%-24s|\n", "Customer Name            : ", customername);
//					System.out.printf("|%-12s%-24s|\n", "Product Name             : ", product);
//					System.out.printf("|%-12s%-24s|\n", "Ice Cream Name           : ", icecreamname);
//					System.out.printf("|%-12s%-24s|\n", "Ice Cream Price          : ", hargaice);
//					System.out.printf("|%-12s%-24s|\n", "Additional Topping       : ", addtopping);
//					System.out.printf("|%-12s%-24s|\n", "Additional Topping Price : ", hargatopping);
//					System.out.printf("|%-12s%-24s|\n", "Quantity                 : ", quantity);
//					System.out.printf("|%-12s%-24s|\n", "Payment Method           : ", payment);
//					System.out.printf("|%-12s%-24s|\n", "Total Discount           : ", totaldiscount + "%");
//					System.out.printf("|%-12s%-24s|\n", "Total Price              : ", totalakhir);
//					System.out.println("=====================================================");
					 
			} else if (product.equalsIgnoreCase("Milk Tea")) {
						System.out.println("Input Drink Name [ Brown Sugar | Red Bean | Oats ] : ");
						String drinkname = scan.nextLine();
						if (drinkname.equalsIgnoreCase("Brown Sugar")) {
							hargadrink = 20000;
						} else if (drinkname.equalsIgnoreCase("Red Bean")) {
							hargadrink = 17000;
						} else if (drinkname.equalsIgnoreCase("Oats")) {
							hargadrink = 15000;
						}
						String cuptype;
						System.out.println("Input Cup Type [ Small | Medium | Large ] : ");
						cuptype = scan.nextLine();
						if (cuptype.equalsIgnoreCase("Small")) {
							hargacup = 0;
						} else if (cuptype.equalsIgnoreCase("Medium")) {
							hargacup = 2000;
						} else if (cuptype.equalsIgnoreCase("Large")) {
							hargacup = 5000;
						}
						System.out.println("Input Quantity [ e.g. 10 ] : ");
						quantity = scan.nextInt(); scan.nextLine();
						System.out.println("Input Payment Method [ QRIS | Transfer ] : ");
						payment = scan.nextLine();
						if (payment.equalsIgnoreCase("QRIS")) {
							hargapayment = 10;
						} else if (payment.equalsIgnoreCase("Transfer")) {
							hargapayment = 5;
						}
						if (totalprice > 100000) {
							totaldiscount = customername.length() + hargapayment;
							 totalprice = (hargadrink + hargacup)*quantity;
							 totalakhir = totalprice - (totalprice*(totaldiscount/100));
							 		String billid = String.format("BL%d%d%d", (int) ((Math.random()*10)), (int) ((Math.random()*10)), (int) ((Math.random()*10))); 
									System.out.println("=====================================================");
									System.out.println("|                      Bill ID                      |");
									System.out.println("=====================================================");
									System.out.printf("|%-12s%-24s|\n", "Bill ID                  : ", billid);
									System.out.printf("|%-12s%-24s|\n", "Customer Name            : ", customername);
									System.out.printf("|%-12s%-24s|\n", "Product Name             : ", product);
									System.out.printf("|%-12s%-24s|\n", "Drink Name               : ", drinkname);
									System.out.printf("|%-12s%-24s|\n", "Drink Price              : ", hargadrink);
									System.out.printf("|%-12s%-24s|\n", "Cup Type                 : ", cuptype);
									System.out.printf("|%-12s%-24s|\n", "Cup Type Price           : ", hargacup);
									System.out.printf("|%-12s%-24s|\n", "Quantity                 : ", quantity);
									System.out.printf("|%-12s%-24s|\n", "Payment Method           : ", payment);
									System.out.printf("|%-12s%-24s|\n", "Total Discount           : ", totaldiscount + "%");
									System.out.printf("|%-12s%-24s|\n", "Total Price              : ", totalakhir);
									System.out.println("=====================================================");
									System.out.println("Input Money [ >= Total Price ] : ");
									int money = scan.nextInt();
									change = money - totalakhir;
									if (money > totalakhir) {
										System.out.printf("Change : ", change);
										System.out.println(" ");
										System.out.println("\nThank you for your purchase :)");
									} else if (money < totalakhir) {
										System.out.println("Saldo anda tidak mencukupi");
									}
						} else if (totalprice < 100000) {
							totaldiscount = customername.length() + hargapayment;
							 totalprice = (hargadrink + hargacup)*quantity;
							 totalakhir = totalprice - (totalprice*(totaldiscount/100));
							 		String billid = String.format("BL%d%d%d", (int) ((Math.random()*10)), (int) ((Math.random()*10)), (int) ((Math.random()*10))); 
									System.out.println("=====================================================");
									System.out.println("|                      Bill ID                      |");
									System.out.println("=====================================================");
									System.out.printf("|%-12s%-24s|\n", "Bill ID                  : ", billid);
									System.out.printf("|%-12s%-24s|\n", "Customer Name            : ", customername);
									System.out.printf("|%-12s%-24s|\n", "Product Name             : ", product);
									System.out.printf("|%-12s%-24s|\n", "Drink Name               : ", drinkname);
									System.out.printf("|%-12s%-24s|\n", "Drink Price              : ", hargadrink);
									System.out.printf("|%-12s%-24s|\n", "Cup Type                 : ", cuptype);
									System.out.printf("|%-12s%-24s|\n", "Cup Type Price           : ", hargacup);
									System.out.printf("|%-12s%-24s|\n", "Quantity                 : ", quantity);
									System.out.printf("|%-12s%-24s|\n", "Payment Method           : ", payment);
									System.out.printf("|%-12s%-24s|\n", "Total Discount           : ", "0%");
									System.out.printf("|%-12s%-24s|\n", "Total Price              : ", totalprice);
									System.out.println("=====================================================");
									System.out.println("Input Money [ >= Total Price ] : ");
									int money = scan.nextInt();
									change = money - totalprice;
									if (money > totalprice) {
										System.out.printf("Change : ", change);
										System.out.println(" ");
										System.out.println("\nThank you for your purchase :)");
									} else if (money < totalprice) {
										System.out.println("Saldo anda tidak mencukupi");
									}
						}
						
					} 
			 
			break; 
		case 2:
			System.out.println("Never Give Up :)");
			break;
		default:
			break;
		}

	}

}
