import java.util.Scanner;

public class goFot {

	public goFot() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int pilihan = 0;
		while (pilihan != 2) {
			System.out.println("goFot");
			System.out.println("=====");
			System.out.println("1. Order goFot");
			System.out.println("2. Exit");
			System.out.println(">> ");
			
			String customername;
			boolean name = true;
			String franchisename;
			String foodname;
			String drinkname;
			int quantity = 0;
			String ordernote;
			String paymentmethod;
			int hargamakan = 0;
			int hargaminum = 0;
			int paymentpoint = 0;
			float tax = 0;
			float totalprice = 0;
			String yesno;
			
			int goFot  = scan.nextInt(); scan.nextLine();
			switch (goFot) {
			case 1:
				do {
					System.out.print("Input Customer Name [ Must be between 7 - 15 characters and start with Mr. or Mrs. ] : ");
					customername = scan.nextLine();
					if (customername.startsWith("Mr.")) {
						if (customername.length()>=11 && customername.length()<=19) {
							name = false;
						}
					} else if (customername.startsWith("Mrs.")) {
						if (customername.length()>=12 && customername.length()<=20) {
							name = false;
						}
					}
				} while (name);
				
				do {
					System.out.print("Input Franchise Name [ Fkc | Cmd ] ( Case Insensitive ) : ");
					franchisename = scan.nextLine();
				} while (!franchisename.equals("Fkc") && !franchisename.equals("Cmd"));
				
				do {
					System.out.print("Input Food Name [ Burger | Fried Chicken | French Fries ] ( Case Sensitive ) : ");
					foodname = scan.nextLine();
					if (foodname.equals("Burger")) {
						hargamakan = 17000;
					} else if (foodname.equals("Fried Chicken")) {
						hargamakan = 22000;
					} else if (foodname.equals("French Fries")) {
						hargamakan = 12000;
					}
				} while (!foodname.equals("Burger") && !foodname.equals("Fried Chicken") && !foodname.equals("French Fries"));
				
				do {
					System.out.print("Input Drink Name [ Mineral Water | Ice Tea | Milkshake ] ( Case Sensitive ): ");
					drinkname = scan.nextLine();
					if (drinkname.equals("Mineral Water")) {
						hargaminum = 3000;
					} else if (drinkname.equals("Ice Tea")) {
						hargaminum = 5000;
					} else if (drinkname.equals("Milkshake")) {
						hargaminum = 10000;
					}
				} while (!drinkname.equals("Mineral Water") && !drinkname.equals("Ice Tea") && !drinkname.equals("Milkshake"));
				
				do {
					System.out.print("Input Quantity [ Must be more than 0 ] : ");
					quantity = scan.nextInt();
				} while (quantity < 1);
				
				do {
					System.out.print("Input Order Note [ Must contain atleast 2 words and contain Thank You ] : ");
					ordernote = scan.nextLine();
				} while (!ordernote.contains("Thank You"));
				
				do {
					System.out.print("Input Payment Method [ Fana | Fopay ] ( Case Sensitive ) : ");
					paymentmethod = scan.nextLine();
					if (paymentmethod.equals("Fana")) {
						paymentpoint = 10;
					} else if (paymentmethod.equals("Fopay")) {
						paymentpoint = 20;
					}
				} while (!paymentmethod.equals("Fana") && !paymentmethod.equals("Fopay"));
				
				tax = ((hargamakan + hargaminum)*quantity)*paymentpoint/100;
				totalprice = ((hargamakan + hargaminum)*quantity)+tax;
				System.out.println("=======================================");
				System.out.println("            Order Information          ");
				System.out.println("=======================================");
				System.out.printf("|%-12s%-24s|\n", "Customer Name  : ", customername.substring(2, 5));
				System.out.printf("|%-12s%-24s|\n", "Food Name      : ", foodname);
				System.out.printf("|%-12s%-24s|\n", "Food Price     : ", hargamakan);
				System.out.printf("|%-12s%-24s|\n", "Drink Name     : ", drinkname);
				System.out.printf("|%-12s%-24s|\n", "Drink Price    : ", hargaminum);
				System.out.printf("|%-12s%-24s|\n", "Quantity       : ", quantity);
				System.out.printf("|%-12s%-24s|\n", "Order Note     : ", ordernote);
				System.out.printf("|%-12s%-24s|\n", "Franchise Name : ", franchisename);
				System.out.printf("|%-12s%-24s|\n", "Payment Method : ", paymentmethod);
				System.out.printf("|%-12s%-24s|\n", "Tax            : ", tax);
				System.out.printf("|%-12s%-24s|\n", "Total Price    : ", totalprice);
				System.out.println("=======================================");

				

				System.out.println("Confirm Order [ y | n ] ( Case Sensitive ) : ");
				yesno = scan.nextLine();
				if (yesno.equals("y")) {
					System.out.println("Sucess Order!");
				} else if (yesno.equals("n")) {
					pilihan = 1;
					break;
//					do {
//						System.out.println("Confirm Order [ y | n ] ( Case Sensitive ) : ");
//						yesno = scan.nextLine();
//					} while (yesno.equals("n"));
//					if (yesno.equals("y")) {
//						System.out.println("Sucess Order!");
//					}
				}

				break;
			case 2:
				System.out.println("Good Luck Have Fun :)");
				break;

			default:
				break;
			}
		}
//		System.out.println("goFot");
//		System.out.println("=====");
//		System.out.println("1. Order goFot");
//		System.out.println("2. Exit");
//		System.out.println(">> ");
//		
//		String customername;
//		boolean name = true;
//		String franchisename;
//		String foodname;
//		String drinkname;
//		int quantity = 0;
//		String ordernote;
//		String paymentmethod;
//		int hargamakan = 0;
//		int hargaminum = 0;
//		int paymentpoint = 0;
//		float tax = 0;
//		float totalprice = 0;
//		String yesno;
//		
//		int goFot  = scan.nextInt(); scan.nextLine();
//		switch (goFot) {
//		case 1:
//			do {
//				System.out.print("Input Customer Name [ Must be between 7 - 15 characters and start with Mr. or Mrs. ] : ");
//				customername = scan.nextLine();
//				if (customername.length()>=7 && customername.length()<=15) {
//					if (customername.startsWith("Mr.") || customername.startsWith("Mrs."))
//					name = false;
//				}
//			} while (name);
//			
//			do {
//				System.out.print("Input Franchise Name [ Fkc | Cmd ] ( Case Insensitive ) : ");
//				franchisename = scan.nextLine();
//			} while (!franchisename.equals("Fkc") && !franchisename.equals("Cmd"));
//			
//			do {
//				System.out.print("Input Food Name [ Burger | Fried Chicken | French Fries ] ( Case Sensitive ) : ");
//				foodname = scan.nextLine();
//				if (foodname.equals("Burger")) {
//					hargamakan = 17000;
//				} else if (foodname.equals("Fried Chicken")) {
//					hargamakan = 22000;
//				} else if (foodname.equals("French Fries")) {
//					hargamakan = 12000;
//				}
//			} while (!foodname.equals("Burger") && !foodname.equals("Fried Chicken") && !foodname.equals("French Fries"));
//			
//			do {
//				System.out.print("Input Drink Name [ Mineral Water | Ice Tea | Milkshake ] ( Case Sensitive ): ");
//				drinkname = scan.nextLine();
//				if (drinkname.equals("Mineral Water")) {
//					hargaminum = 3000;
//				} else if (drinkname.equals("Ice Tea")) {
//					hargaminum = 5000;
//				} else if (drinkname.equals("Milkshake")) {
//					hargaminum = 10000;
//				}
//			} while (!drinkname.equals("Mineral Water") && !drinkname.equals("Ice Tea") && !drinkname.equals("Milkshake"));
//			
//			do {
//				System.out.print("Input Quantity [ Must be more than 0 ] : ");
//				quantity = scan.nextInt();
//			} while (quantity < 1);
//			
//			do {
//				System.out.print("Input Order Note [ Must contain atleast 2 words and contain Thank You ] : ");
//				ordernote = scan.nextLine();
//			} while (!ordernote.contains("Thank You"));
//			
//			do {
//				System.out.print("Input Payment Method [ Fana | Fopay ] ( Case Sensitive ) : ");
//				paymentmethod = scan.nextLine();
//				if (paymentmethod.equals("Fana")) {
//					paymentpoint = 10;
//				} else if (paymentmethod.equals("Fopay")) {
//					paymentpoint = 20;
//				}
//			} while (!paymentmethod.equals("Fana") && !paymentmethod.equals("Fopay"));
//			
//			tax = ((hargamakan + hargaminum)*quantity)*paymentpoint/100;
//			totalprice = ((hargamakan + hargaminum)*quantity)+tax;
//			System.out.println("=======================================");
//			System.out.println("            Order Information          ");
//			System.out.println("=======================================");
//			System.out.printf("|%-12s%-24s|\n", "Customer Name  : ", customername);
//			System.out.printf("|%-12s%-24s|\n", "Food Name      : ", foodname);
//			System.out.printf("|%-12s%-24s|\n", "Food Price     : ", hargamakan);
//			System.out.printf("|%-12s%-24s|\n", "Drink Name     : ", drinkname);
//			System.out.printf("|%-12s%-24s|\n", "Drink Price    : ", hargaminum);
//			System.out.printf("|%-12s%-24s|\n", "Quantity       : ", quantity);
//			System.out.printf("|%-12s%-24s|\n", "Order Note     : ", ordernote);
//			System.out.printf("|%-12s%-24s|\n", "Franchise Name : ", franchisename);
//			System.out.printf("|%-12s%-24s|\n", "Payment Method : ", paymentmethod);
//			System.out.printf("|%-12s%-24s|\n", "Tax            : ", tax);
//			System.out.printf("|%-12s%-24s|\n", "Total Price    : ", totalprice);
//			System.out.println("=======================================");
//
//			System.out.println("Confirm Order [ y | n ] ( Case Sensitive ) : ");
//			yesno = scan.nextLine();
//			if (yesno.equals("y")) {
//				System.out.println("Sucess Order!");
//			} else if (yesno.equals("n")) {
//				pilihan = 1;
////				do {
////					System.out.println("Confirm Order [ y | n ] ( Case Sensitive ) : ");
////					yesno = scan.nextLine();
////				} while (yesno.equals("n"));
////				if (yesno.equals("y")) {
////					System.out.println("Sucess Order!");
////				}
//			}
//
//			break;
//		case 2:
//			System.out.println("Good Luck Have Fun :)");
//			break;
//
//		default:
//			break;
//		}

	}

}
