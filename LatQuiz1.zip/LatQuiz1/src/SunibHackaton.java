import java.util.Scanner;

public class SunibHackaton {

	public SunibHackaton() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int kembali = 0;
		while (kembali != 2) {
			System.out.println("Sunib Hackaton");
	        System.out.println("==============");
	        System.out.println("1. Register Sunib Hackaton");
	        System.out.println("2. Exit");
	        System.out.println(">> ");
	        
	        String fullname;
	        String inputemail;
	        int age = 0;
	        String education;
	        int point = 0;
	        String teamname;
	        String github;
	        String inputidea;
	        int idea = 0;
	        boolean ideabool = true;
	        float totaldiscount = 0;
	        float registrationprice = 0;
	        String regist;
	        int money = 0;
	        float change = 0;
	        
	        int mulai;
			try {
				mulai = scan.nextInt();
			} catch (Exception e) {
				mulai = -1;
			} scan.nextLine();
	        switch (mulai) {
			case 1:
				do {
					System.out.println("Input Full Name [ Must be more than 5 characters and Start with capital letter ] : ");
					fullname = scan.nextLine();
				} while (!(fullname.length()>5) || !Character.isUpperCase(fullname.charAt(0)));
				
				do {
					System.out.println("Input Email [ Must ends with @gmail.com or @yahoo.com ] : ");
					inputemail = scan.nextLine();
				} while (!inputemail.endsWith("@gmail.com") && !inputemail.endsWith("@yahoo.com"));
				
				do {
					System.out.println("Input Age [ Must be more than 17 ] : ");
					try {
						age = scan.nextInt();
					} catch (Exception e) {
						age = -1;
					} scan.nextLine();
				} while (!(age > 17));
				
				do {
					System.out.println("Input Education [ D3 | D4 | S1 ] (Case Insensitive) : ");
					education = scan.nextLine();
					if (education.equals("D3")) {
						point = 30;
					} else if (education.equals("D4")) {
						point = 40;
					} else if (education.equals("S1")) {
						point = 50;
					}
				} while (!education.equals("D3") && !education.equals("D4") && !education.equals("S1"));
				
				do {
					System.out.println("Input Team Name [ Must be between 4 - 20 characters ] : ");
					teamname = scan.nextLine();
				} while (!(teamname.length()>=4) || !(teamname.length()<=20));
				
				do {
					System.out.print("Input Github Link [ Must starts with github.com/ ] : ");
					github = scan.nextLine();
				} while (!github.startsWith("github.com/"));
				
				do {
					System.out.print("Input Idea [ Must be between 3 - 7 words ] : ");
					inputidea = scan.nextLine();
					
					String [] words = inputidea.split(" ");
					idea = words.length;
					if (inputidea.startsWith(" ") && inputidea.endsWith(" ")) {
						if (idea >= 3 || idea <=7) {
							ideabool = false;
						}
					}
				} while (ideabool);
				
				totaldiscount = point + teamname.length();
				registrationprice = 150000 - (150000*(totaldiscount/100));
							
				System.out.println("Are u sure want to register [ Y | N ] ( Case Sensitive ) : ");
				regist = scan.nextLine();
				
				if (regist.equals("N")) {
					kembali = 1;
					break;
				} else if (regist.equals("Y")) {
					kembali = 2;
					System.out.println("===========================================");
					System.out.println("             Registration Price            ");
					System.out.println("===========================================");
					System.out.printf("|%-12s%-28s|\n", "Full Name : ", fullname);
					System.out.printf("|%-12s%-28s|\n", "Email : ", inputemail);
					System.out.printf("|%-12s%-28s|\n", "Age : ", age);
					System.out.printf("|%-12s%-28s|\n", "Education : ", education);
					System.out.printf("|%-12s%-28s|\n", "Team Name : ", teamname);
					System.out.printf("|%-12s%-28s|\n", "Github Link : ", github);
					System.out.printf("|%-12s%-28s|\n", "Idea : ", inputidea);
					System.out.printf("|%-12s%-28s|\n", "Total Discount : ", totaldiscount);
					System.out.printf("|%-12s%-28s|\n", "Registration Price : ", registrationprice);
					System.out.println("===========================================");
					
					do {
						System.out.println("Input Money [ >= Regristration Price ] : ");
						money = scan.nextInt(); scan.nextLine();
					} while (money < registrationprice);
					
					change = money - registrationprice;
					System.out.printf("Change : ", change);
					System.out.println(" ");
					System.out.println("Good Luck For Your Competition :)");
				}

				break;
			case 2:
				System.out.println("Embrace the code, conquer the challenge, let algorithms define excellence");
				break;

			default:
				kembali = 1;
				break;
//				try {
//					kembali = scan.nextInt();
//				} catch (Exception e) {
//					kembali = -1;
//				} scan.nextLine();
//				break;
			}
		}
		
        
	}

}
