import java.util.Scanner;

public class TaxCalculator {

	public TaxCalculator() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int monthlysalary = 0;
		int yearlyincome = 0;
		int taxableincome = 0;
		int tax = 0;
		double yearlytax = 0;
		double monthlytax = 0;
		
		System.out.println("Simple Tax Calculator");
		System.out.println("---------------------");
		System.out.print("Input your monthly salary : Rp. ");
		monthlysalary = scan.nextInt(); scan.nextLine();
		
		yearlyincome = monthlysalary * 12;
		taxableincome = yearlyincome - 54000000;
		
		if (yearlyincome <= 54000000) {
			System.out.println(" ");
			System.out.println("Yearly income : Rp. " + yearlyincome);
			System.out.println("You don't have to pay tax");
		} else if (yearlyincome > 54000000) {
			if (taxableincome >=0 && taxableincome < 50000000) {
				tax = 5;
			} else if (taxableincome >= 50000000 && taxableincome < 250000000) {
				tax = 15;
			} else if (taxableincome >= 250000000 && taxableincome < 500000000) {
				tax = 25;
			} else if (taxableincome >= 500000000) {
				tax = 30;
			}
			yearlytax = taxableincome * (tax/100.0);
			monthlytax = yearlytax / 12;
			
			System.out.println("Taxable Income : " + taxableincome);
			
			System.out.println("Simple Tax Calculator");
			System.out.println("---------------------");
			System.out.println("Yearly income : Rp. " + yearlyincome);
			System.out.println(" ");
			System.out.println("Yearly income : Rp. " + yearlyincome);
			System.out.println("Taxable income : Rp. " + taxableincome);
			System.out.printf("Yearly tax : Rp. %.0f\n", yearlytax);
			System.out.printf("Monthly tax : Rp. %.0f\n", monthlytax);
			
		}
		
		
		

	}

}
