import java.util.Scanner;

public class Starwars {

	public Starwars() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("sTarwars Dictionary");
		System.out.println("===================");
		System.out.println("1. Add Character");
		System.out.println("2. Exit");
		System.out.print(">> ");
		//System.out.println(" ");
		
		String entername;
		String entertype;
		String enterhome;
		boolean enterhomecheck = true;
		int enterforce = 0;
		int baseattacklight = 0;
		int baseattackdark = 0;
		int attackscorelight = 0;
		int attackscoredark = 0;
		
		int kiw = scan.nextInt(); scan.nextLine();
		switch (kiw) {
		case 1:
			System.out.println(" ");
			System.out.println("sTarwars Dictionary");
			System.out.println("===================");
			
			do {
				System.out.print("Enter name [5-20 characters] : ");
				entername = scan.nextLine();
			} while (!(entername.length()>=5) || !(entername.length()<=20));
			
			do {
				System.out.print("Enter type [Light Side | Dark Side] :");
				entertype = scan.nextLine();
			} while (!entertype.equals("Light Side") && !entertype.equals("Dark Side"));
			
			do {
				System.out.print("Enter home world [starts with \"Planet \" & 8-20 characters] : ");
				enterhome = scan.nextLine();
				if (enterhome.startsWith("Planet ")) {
					if (enterhome.length()>=15 && enterhome.length()<=27) {
						enterhomecheck = false;
					}
				}
			} while (enterhomecheck);
			
			do {
				System.out.print("Enter force [25-100] : ");
				enterforce = scan.nextInt(); scan.nextLine();
			} while (!(enterforce >= 25) || !(enterforce <= 100));
			
			if (entertype.equals("Light Side")) {
				baseattacklight = enterforce * 20;
				attackscorelight = (int) (baseattacklight * (Math.random()*6)+10);
			} else if (entertype.equals("Dark Side")) {
				baseattackdark = enterforce * 15;
				attackscoredark = (int) (baseattackdark * (Math.random()*6)+15);
			}
			
			System.out.println("Hasil : " + baseattacklight);
			System.out.println("Hasil Attack : " + attackscorelight);
			break;
			
		case 2:
			System.out.println("");
			break;

		default:
			break;
		}

	}

}
