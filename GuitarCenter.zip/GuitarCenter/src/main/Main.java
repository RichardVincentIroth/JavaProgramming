package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Guitar> arrGuitar = new ArrayList<Guitar>();

	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("1. Insert Guitar");
			System.out.println("2. View Guitar Catalouge");
			System.out.println("3. Delete Guitar");
			System.out.println("4. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				delete();
				break;
			case 4:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 4);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		int choice = 0;
		do {
			System.out.println("Input guitar type:");
			System.out.println("1. Electric");
			System.out.println("2. Accoustic");
			System.out.println("3. Cancel");
			System.out.print("Input: ");
			choice = sc.nextInt(); sc.nextLine();
			
			switch (choice) {
			case 1:
				addElectric();
				return;
			case 2:
				addAccoustic();
				return;
			case 3:
				return;

			default:
				break;
			}
		} while (choice != 3);
		
		
		
	}

	private void addElectric() {
		// TODO Auto-generated method stub
		System.out.println("+-----------------+");
		System.out.println("|  Insert Guitar  |");
		System.out.println("+-----------------+");
		
		String model;
		do {
			System.out.print("Input model [ 5 - 10 characters ]: ");
			model = sc.nextLine();
		} while (!(model.length()>=5) || !(model.length()<=10));
		
		String brand;
		do {
			System.out.print("Input brand [ Yamaha | Fender | Cort ] [Case Sensitive ]: ");
			brand = sc.nextLine();
		} while (!brand.equals("Yamaha") && !brand.equals("Fender") && !brand.equals("Cort"));
		
		int numberOfString = 0;
		do {
			System.out.print("Input numberOfString [ 6 - 8 ]: ");
			numberOfString = sc.nextInt(); sc.nextLine();
		} while (!(numberOfString >= 6) || !(numberOfString <= 8));
		
		String amp;
		do {
			System.out.print("Input amp? [ Yes | No ] [ Case Insensitive ]: ");
			amp = sc.nextLine();
		} while (!amp.equalsIgnoreCase("Yes") && !amp.equalsIgnoreCase("No")); 
		
		Electric electric = new Electric(model, brand, numberOfString, amp);
		arrGuitar.add(electric);
		
		System.out.println("");
		System.out.print("Press enter to continue");
		sc.nextLine();
		
	}

	private void addAccoustic() {
		// TODO Auto-generated method stub
		System.out.println("+-----------------+");
		System.out.println("|  Insert Guitar  |");
		System.out.println("+-----------------+");
		
		String model;
		do {
			System.out.print("Input model [ 5 - 10 characters ]: ");
			model = sc.nextLine();
		} while (!(model.length()>=5) || !(model.length()<=10));
		
		String brand;
		do {
			System.out.print("Input brand [ Yamaha | Fender | Cort ] [Case Sensitive ]: ");
			brand = sc.nextLine();
		} while (!brand.equals("Yamaha") && !brand.equals("Fender") && !brand.equals("Cort"));
		
		int numberOfString = 0;
		do {
			System.out.print("Input numberOfString [ 6 - 8 ]: ");
			numberOfString = sc.nextInt(); sc.nextLine();
		} while (!(numberOfString >= 6) || !(numberOfString <= 8));
		
		String hybrid;
		do {
			System.out.print("Is the guitar Hybrid? [ Yes | No ] [ Case Insensitive ]: ");
			hybrid = sc.nextLine();
		} while (!hybrid.equalsIgnoreCase("Yes") && !hybrid.equalsIgnoreCase("No")); 
		
		Accoustic accoustic = new Accoustic(model, brand, numberOfString, hybrid);
		arrGuitar.add(accoustic);
		
		System.out.println("");
		System.out.print("Press enter to continue");
		sc.nextLine();
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrGuitar.isEmpty()) {
			System.out.println("+-----------------+");
			System.out.println("|  Guitar Catalogue  |");
			System.out.println("+-----------------+");
			System.out.println("There are no guitars in the catalog yet!");
			System.out.print("Press enter to continue");
			sc.nextLine();
			return;
		}
		System.out.println("+-----------------+");
		System.out.println("|  Guitar Catalogue  |");
		System.out.println("+-----------------+");
		String rapi = "| %-5s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s |\n";
		System.out.println("--------------------------------------------------------------------");
		System.out.printf(rapi, "No", "Type", "Model", "Brand", "Strings", "Hybrid", "Amp", "Price");
		System.out.println("--------------------------------------------------------------------");
		String rapiIsi = "| %-5s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15s | %-15.0f |\n";
		int index = 1;
		for (Guitar g : arrGuitar) {
			System.out.printf(rapiIsi, index,
					(g instanceof Electric) ? "Electric" : "Accoustic",
					g.getModel(), g.getBrand(), g.getNumberOfStrings(),
					(g instanceof Accoustic) ? ((Accoustic)g).getHybrid() : "-",
					(g instanceof Electric) ? ((Electric)g).getAmp() : "-",
					g.calculatePrice()
					);
			index++;
		}
		System.out.println("+-----------------+");
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		if (arrGuitar.isEmpty()) {
			System.out.println("+-----------------+");
			System.out.println("|  Delete Guitar  |");
			System.out.println("+-----------------+");
			return;
		}
		view();
		System.out.println("+-----------------+");
		System.out.println("|  Delete Guitar  |");
		System.out.println("+-----------------+");
		int index = 0;
		do {
			System.out.print("Choose index to delete [ 1 - 3 ]: ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1) || !(index <= arrGuitar.size()));
		
		arrGuitar.remove(index - 1);
		
		System.out.println("");
		System.out.println("Guitar " + index + " deleted!");
		System.out.print("Press enter to continue");
		sc.nextLine();
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
