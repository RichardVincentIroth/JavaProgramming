package model;

public class Electric extends Guitar {
	
	private String amp;

	public Electric(String model, String brand, int numberOfStrings, String amp) {
		super(model, brand, numberOfStrings);
		this.amp = amp;
	}

	public String getAmp() {
		return amp;
	}

	public void setAmp(String amp) {
		this.amp = amp;
	}
	
	public double calculatePrice() {
		double addPrice = 0;
		switch (getBrand()) {
		case "Yamaha":
			addPrice = 1500000;
			break;
		case "Fender":
			addPrice = 2000000;
			break;
		case "Cort":
			addPrice = 2000000;
			break;

		}
		
		double addAmp = 0;
		switch (getAmp()) {
		case "Yes":
			addAmp = 1000000;
			break;
		case "No":
			addAmp = 0;
			break;
		}
		
		return addPrice + (150000 * getNumberOfStrings()) + addAmp;
	}

}
