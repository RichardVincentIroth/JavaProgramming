package model;

public abstract class Guitar {
	
	private String model, brand;
	private int numberOfStrings;
	private double price;
	
	public Guitar(String model, String brand, int numberOfStrings) {
		super();
		this.model = model;
		this.brand = brand;
		this.numberOfStrings = numberOfStrings;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getNumberOfStrings() {
		return numberOfStrings;
	}

	public void setNumberOfStrings(int numberOfStrings) {
		this.numberOfStrings = numberOfStrings;
	}
	
	public abstract double calculatePrice();

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
