package model;

public class Accoustic extends Guitar {
	
	private String hybrid;

	public Accoustic(String model, String brand, int numberOfStrings, String hybrid) {
		super(model, brand, numberOfStrings);
		this.hybrid = hybrid;
	}

	public String getHybrid() {
		return hybrid;
	}

	public void setHybrid(String hybrid) {
		this.hybrid = hybrid;
	}
	
	public double calculatePrice() {
		double addPrice = 0;
		switch (getBrand()) {
		case "Yamaha":
			addPrice = 1500000;
			break;
		case "Fender":
			addPrice = 2000000;
			break;
		case "Cort":
			addPrice = 2000000;
			break;

		}
		
		double addHybrid = 0;
		switch (getHybrid()) {
		case "Yes":
			addHybrid = 500000;
			break;
		case "No":
			addHybrid = 0;
			break;
		}
		
		return addPrice + (150000 * getNumberOfStrings()) + addHybrid;
	}

}
