package model;

public class Heels extends Footwear {
	
	private double height;

	public Heels(String name, double price, double height) {
		super(name, price);
		this.height = height;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
	
	

}
