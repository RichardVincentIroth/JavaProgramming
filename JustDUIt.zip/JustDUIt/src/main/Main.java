package main;
import java.util.ArrayList;
import java.util.Scanner;

import model.*;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Footwear> arrFootwear = new ArrayList<Footwear>();
	
	public Main() {
		// TODO Auto-generated constructor stub
		int milih = 0;
		do {
			System.out.println("Just DU It !!");
			System.out.println("=============");
			System.out.println("1. Add Footwear");
			System.out.println("2. View Footwear");
			System.out.println("3. Upadate Footwear");
			System.out.println("4. Delete Footwear");
			System.out.println("5. Exit");
			System.out.print(">> ");
			milih = sc.nextInt(); sc.nextLine();
			
			switch (milih) {
			case 1:
				add();
				break;
			case 2:
				view();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;

			default:
				break;
			}
		} while (milih != 5);
		
	}

	private void add() {
		// TODO Auto-generated method stub
		String name;
		do {
			System.out.print("Footwear name [3 - 25 characters]: ");
			name = sc.nextLine();
			
			if (!(name.length()>=3) || !(name.length()<=25)) {
				System.out.println("Hiya salah");
			}
		} while (!(name.length()>=3) || !(name.length()<=25));
		
		double price = 0;
		do {
			System.out.print("Footwear price [more than 10000]: ");
			price = sc.nextDouble(); sc.nextLine();
		} while (!(price > 10000));
		
		String type;
		do {
			System.out.print("Footwear type [Heels / RollerSkate]: ");
			type = sc.nextLine();
		} while (!type.equals("Heels") && !type.equals("RollerSkate"));
		
		if (type.equals("Heels")) {
			double height = 0;
			do {
				System.out.print("Footwear height [1.0 - 9.0]: ");
				height = sc.nextDouble(); sc.nextLine();
			} while (!(height >= 1.0) || !(height <= 9.0));
			
			Heels heels = new Heels(name, price, height);
			arrFootwear.add(heels);
			
		} else if (type.equals("RollerSkate")) {
			int wheels = 0;
			do {
				System.out.print("Footwear total wheel [1 - 4 inclusive]: ");
				wheels = sc.nextInt(); sc.nextLine();
			} while (!(wheels >= 1) || !(wheels <= 4));
			
			RollerSkate rolerSkate = new RollerSkate(name, price, wheels);
			arrFootwear.add(rolerSkate);
			
		}
		
		System.out.println("Foot wear added successfully !!");
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrFootwear.isEmpty()) {
			System.out.println("There are no footwears to display !");
			return;
		}
		String rapi = "| %-5s | %-15s | %-15s | %-15s | %-15s |\n";
		System.out.println("=======================================================================");
		System.out.printf(rapi, "No", "Name", "Price", "Height", "Total Wheel");
		System.out.println("=======================================================================");
		int index = 1;
		for (Footwear f : arrFootwear) {
			System.out.printf(rapi, index, f.getName(), f.getPrice(), 
					(f instanceof Heels) ? ((Heels)f).getHeight() + " cm" : "-",
					(f instanceof RollerSkate) ? ((RollerSkate)f).getWheel() + (((RollerSkate)f).getWheel() == 1 ? " Wheel" : " Wheels") 
						: "-"
					);
			System.out.println("=======================================================================");
			index++;
		}
		
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		if (arrFootwear.isEmpty()) {
			return;
		}
		int index = 1;
		do {
			System.out.print("Input footwear index to update: ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1 && index <= arrFootwear.size()));
		
		
		Footwear f = arrFootwear.get(index - 1);
		
		String name;
		do {
			System.out.print("Footwear name [3 - 25 characters]: ");
			name = sc.nextLine();
		} while (!(name.length()>=3) || !(name.length()<=25));
		
		double price = 0;
		do {
			System.out.print("Footwear price [more than 10000]: ");
			price = sc.nextDouble(); sc.nextLine();
		} while (!(price > 10000));
		
		String type;
		do {
			System.out.print("Footwear type [Heels / RollerSkate]: ");
			type = sc.nextLine();
		} while (!type.equals("Heels") && !type.equals("RollerSkate"));
		
		f.setName(name);
		f.setPrice(price);
		
		if (f instanceof Heels) {
			double height = 0;
			do {
				System.out.print("Footwear height [1.0 - 9.0]: ");
				height = sc.nextDouble(); sc.nextLine();
			} while (!(height >= 1.0) || !(height <= 9.0));
			
			((Heels)f).setHeight(height);
			
		} else if (f instanceof RollerSkate) {
			int wheels = 0;
			do {
				System.out.print("Footwear total wheel [1 - 4 inclusive]: ");
				wheels = sc.nextInt(); sc.nextLine();
			} while (!(wheels >= 1) || !(wheels <= 4));
			
			((RollerSkate)f).setWheel(wheels);
			
		}
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		if (arrFootwear.isEmpty()) {
			System.out.println("There are no footwear to delete !");
			return;
		}
		view();
		
		int index = 0;
		do {
			System.out.print("Input footwear index to delete : ");
			index = sc.nextInt(); sc.nextLine();
		} while (!(index >= 1 && index <= arrFootwear.size()));
		
		arrFootwear.remove(index - 1);
		System.out.println("Footwear deleted successfully !!");
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
