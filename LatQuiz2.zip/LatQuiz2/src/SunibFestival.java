import java.util.ArrayList;
import java.util.Scanner;

public class SunibFestival {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrGroupName = new ArrayList<String>();
	ArrayList<String> arrIdea = new ArrayList<String>();
	ArrayList<String> arrLocation = new ArrayList<String>();
	ArrayList<String> arrFeedback = new ArrayList<String>();

	public SunibFestival() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("sunib Festival");
			System.out.println("==============");
			System.out.println("1. Register for the exhibition");
			System.out.println("2. View all exhibits");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Harus Angka Tolol");
			}
			scan.nextLine();
			switch (menu) {
			case 1:
				register();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no exhibition yet !");
			return;
		}
		System.out.println("=====================================");
		String rapi = "| %-12s | %-20s | %-30s | %-20s | %-25s |\n";
		System.out.println("=====================================");
		System.out.printf(rapi, "Table ID", "Group Name", "Idea", "Location", "Feedback Link");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrGroupName.get(i), arrIdea.get(i), arrLocation.get(i), arrFeedback.get(i));
		}
		System.out.println("=====================================");
	}

	private void register() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int flag;
		String inputGroup;
		do {
			flag = 0;
			System.out.println("Input Group Name [ Must be alphabetic and Unique ] : ");
			inputGroup = scan.nextLine();
			for (char c : inputGroup.toCharArray()) {
				if (!Character.isAlphabetic(c)) {
					flag = 1;
				}
			}
			
		} while (flag == 1 || arrGroupName.contains(inputGroup));
		
		String inputIdea;
		do {
			System.out.println("Input idea [ Must be atleast contain 3 words ] : ");
			inputIdea = scan.nextLine();
		} while (inputIdea.split(" ").length < 3);
		
		String inputLocation;
		do {
			System.out.println("Input Location [ Must be ends with 'lt.1', 'lt.2', or lt.3 ] : ");
			inputLocation = scan.nextLine();
		} while (!inputLocation.endsWith("lt.1") && !inputLocation.endsWith("lt.2") && !inputLocation.endsWith("lt.3"));
		
		String inputFeedback;
		do {
			System.out.println("Input feedback link [ Must starts with 'forms.com/' ] : ");
			inputFeedback = scan.nextLine();
		} while (!inputFeedback.startsWith("forms.com/"));
		
		System.out.println("=========================================");
		System.out.println("|          Exhibition Information       |");
		System.out.println("=========================================");
		String id = String.format("TB%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		System.out.printf("| %-13s : %-28s |\n", "Table ID", id);
		System.out.printf("| %-13s : %-28s |\n", "Group Name", inputGroup);
		System.out.printf("| %-13s : %-28s |\n", "Idea", inputIdea);
		System.out.printf("| %-13s : %-28s |\n", "Location", inputLocation);
		System.out.printf("| %-13s : %-28s |\n", "Feedback Link", inputFeedback);
		System.out.println("=========================================");
		
		arrID.add(id);
		arrGroupName.add(inputGroup);
		arrIdea.add(inputIdea);
		arrLocation.add(inputLocation);
		arrFeedback.add(inputFeedback);

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SunibFestival();

	}

}
