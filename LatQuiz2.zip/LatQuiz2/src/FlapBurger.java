import java.util.ArrayList;
import java.util.Scanner;

public class FlapBurger {
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<String> arrBun = new ArrayList<String>();
	ArrayList<String> arrSize = new ArrayList<String>();
	ArrayList<String> arrMeat = new ArrayList<String>();
	ArrayList<String> arrSauce = new ArrayList<String>();
	ArrayList<String> arrCheese = new ArrayList<String>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();
	ArrayList<Double> arrWeightPrice = new ArrayList<Double>();

	public FlapBurger() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("1. Create Order");
			System.out.println("2. Finalize Order");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;
			
			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		if (arrName.size() == 0) {
			System.out.println("You haven't create any order yet!");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("=====================================================================");
		String rapi = "| %-8s | %-20s | %-20s | %-20s | %-20s | %-20s | %-20s |\n";
		System.out.printf(rapi, "No", "Name", "Bun", "Single / Double", "Meat", "Sauce", "Cheese");
		System.out.println("=====================================================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, i+1, arrName.get(i), arrBun.get(i), arrSize.get(i), arrMeat.get(i), arrSauce.get(i), arrCheese.get(i));
			System.out.println("=====================================================================");
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		int index = 0;
		System.out.print("Which burger you want to chek out ? ");
		index = scan.nextInt(); scan.nextLine();
		
		System.out.print(arrName.get(index - 1));
		System.out.println("(" + arrSize.get(index - 1) + " Burger)");
		System.out.printf("%-20s : %-20s\n", "Bun", arrBun.get(index - 1));
		System.out.printf("%-20s : %-20s\n", "Meat", arrMeat.get(index - 1));
		System.out.printf("%-20s : %-20s\n", "Sauce", arrSauce.get(index - 1));
		System.out.printf("%-20s : %-20s\n", "Cheese", arrCheese.get(index - 1));
		System.out.println(" ");
		System.out.printf("%-20s : %-20s\n", "Total Ounce", arrWeightPrice.get(index - 1));
		System.out.printf("%-20s : %-20s\n", "Total Price", arrTotalPrice.get(index - 1));
		String checkout;
		System.out.printf("Check out this burger [Y | N] ? ");
		checkout = scan.nextLine();
		if (checkout.equals("N")) {
			arrName.remove(index - 1);
			arrSize.remove(index - 1);
			arrBun.remove(index - 1);
			arrMeat.remove(index - 1);
			arrSauce.remove(index - 1);
			arrCheese.remove(index - 1);
			return;
		} else if (checkout.equals("Y")) {
			System.out.println("Transaction Success! Enjoy your burger :)");
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String inputBun;
		int weightBun = 0;
		int bunPrice = 0;
		do {
			System.out.println("Choose your Burger Bun [Original | Black Charcoal | Wheat] (Case Sensitive) : ");
			inputBun = scan.nextLine();
		} while (!inputBun.equals("Original") && !inputBun.equals("Black Charcoal") && !inputBun.equals("Wheat"));
		if (inputBun.equals("Original")) {
			weightBun = 2;
			bunPrice = 5000;
		} else if (inputBun.equals("Black Charcoal")) {
			weightBun = 1;
			bunPrice = 10000;
		} else if (inputBun.equals("Wheat")) {
			weightBun = 1;
			bunPrice = 8000;
		}
		
		String inputSize;
		do {
			System.out.println("Do you want your burger Single / Double ? [Single | Double] (Case Sensitive) : ");
			inputSize = scan.nextLine();
		} while (!inputSize.equals("Single") && !inputSize.equals("Double"));
		
		String inputMeat;
		int weightMeat = 0;
		int meatPrice = 0;
		do {
			System.out.println("Choose your favorite meat [Bacon | Hamburg Beef | Grilled Chicken] (Case Sensitive) : ");
			inputMeat = scan.nextLine();
		} while (!inputMeat.equals("Bacon") && !inputMeat.equals("Hamburg Beef") && !inputMeat.equals("Grilled Chicken"));
		if (inputSize.equals("Single")) {
			if (inputMeat.equals("Bacon")) {
				weightMeat = 4;
				meatPrice = 15000;
			} else if (inputMeat.equals("Hamburg Beef")) {
				weightMeat = 5;
				meatPrice = 20000;
			} else if (inputMeat.equals("Grilled Chicken")) {
				weightMeat = 5;
				meatPrice = 12000;
			}
		} else if (inputSize.equals("Medium")) {
			if (inputMeat.equals("Bacon")) {
				weightMeat = 8;
				meatPrice = 30000;
			} else if (inputMeat.equals("Hamburg Beef")) {
				weightMeat = 10;
				meatPrice = 40000;
			} else if (inputMeat.equals("Grilled Chicken")) {
				weightMeat = 10;
				meatPrice = 24000;
			}
		}
		
		String inputSauce;
		int saucePrice = 0;
		do {
			System.out.println("Choose your favorite sauce [Special Sauce | Mustard Sauce | Onion BBQ Chicken] (Case Sensitive) : ");
			inputSauce = scan.nextLine();
		} while (!inputSauce.equals("Special Sauce") && !inputSauce.equals("Mustard Sauce") && !inputSauce.equals("Onion BBQ Chicken"));
		if (inputSauce.equals("Special Sauce")) {
			saucePrice = 5000;
		} else if (inputSauce.equals("Mustard Sauce")) {
			saucePrice = 3000;
		} else if (inputSauce.equals("Onion BBQ Sauce")) {
			saucePrice = 3000;
		}
		
		String inputCheese;
		int cheesePrice = 0;
		do {
			System.out.println("Choose your favorite cheese [Cheddar | Mozarella | Monterey Jack] (Case Sensitive) : ");
			inputCheese = scan.nextLine();
		} while (!inputCheese.equals("Cheddar") && !inputCheese.equals("Mozarella") && !inputCheese.equals("Monterey Jack"));
		if (inputSauce.equals("Cheddar")) {
			cheesePrice = 5000;
		} else if (inputSauce.equals("Mozarella")) {
			cheesePrice = 8000;
		} else if (inputSauce.equals("Monterey Jack")) {
			cheesePrice = 10000;
		}
		
		String inputCreation;
		do {
			System.out.println("Give your creation a name [5 - 20] : ");
			inputCreation = scan.nextLine();
		} while (!(inputCreation.length()>=5) || !(inputCreation.length()<=20));
		
		double totalPrice = bunPrice + meatPrice + saucePrice + cheesePrice;
		double weightPrice = weightBun + weightMeat;
		
		String nama = "Favorite Burger";
		
		arrName.add(nama);
		arrBun.add(inputBun);
		arrSize.add(inputSize);
		arrMeat.add(inputMeat);
		arrSauce.add(inputSauce);
		arrCheese.add(inputCheese);
		arrTotalPrice.add(totalPrice);
		arrWeightPrice.add(weightPrice);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FlapBurger();

	}

}
