import java.util.Random;
import java.util.Scanner;

public class Coba {

	public Coba() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int flag, countNum, countHex;
		String alpa;
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.println("Input Name [ Must Alphanumeric ] : ");
			alpa = scan.nextLine();
			for (char c : alpa.toCharArray()) {
				if (!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if (Character.isLetter(c)) {
					countNum++;
				}
				if (Character.isDigit(c)) {
					countHex++;
				}
			}
		} while (flag == 1 || countNum == 0 || countHex == 0 || alpa.split(" ").length<2);
		
		int velg;
		String beric;
		do {
			velg = 0;
			System.out.println("Input Team [ Must Alphabetic ] : ");
			beric = scan.nextLine();
			for (char ch : beric.toCharArray()) {
				if (!Character.isAlphabetic(ch) && ch != ' ') {
					velg = 1;
				}
			}
		} while (velg == 1);
		
		String katakata;
		do {
			System.out.println("Input Kata [ Must be more than 3 word ] : ");
			katakata = scan.nextLine();
		} while (katakata.split(" ").length < 3);
		
		String email;
		String hasilmail = "";
		do {
			System.out.print("Input email [Must ends with @gmail.com or @yahoo.com ]: ");
			email = scan.nextLine();
		}while((!email.endsWith("@gmail.com") && !email.endsWith("@yahoo.com")) && (!email.startsWith("@gmail.com") && !email.startsWith("@yahoo.com")));
		if (email.endsWith("@gmail.com")) {
			int mail = email.length() - "@gmail.com".length();
			hasilmail = email.substring(0, mail);
		} else if (email.endsWith("@yahoo.com")) {
			int mail = email.length() - "@yahoo.com".length();
			hasilmail = email.substring(0, mail);
		}
		System.out.println("Hasil Email : " + hasilmail);
		
		double aidi = 0;
		aidi = (int) ((Math.random()*6)+10);
		System.out.printf("%.0f\n", aidi);
		
		Random rand = new Random();
		String kut = alpa;
		char c1 = kut.charAt(rand.nextInt(kut.length()));
		char c2;
		do {
			c2 = kut.charAt(rand.nextInt(kut.length()));
		} while (c2 == c1);
		
		String id = String.format("ID%c%c%s%s%d", c1, c2, (char) ((Math.random()*26)+65), (char) ((Math.random()*26)+97), (int) ((Math.random()*6)+10));
		System.out.println(id);
		
		int angka = (int) ((Math.random()*58)+65);
		while (angka >= 91 && angka <= 96) {
			angka = (int) ((Math.random()*58)+65);
		}
		char huruf = (char) angka;
		System.out.println(huruf);
		
		String name;
		do {
			System.out.println("Input name : ");
			name = scan.nextLine();
		} while (!name.startsWith("www.") || !name.endsWith(".com"));
		int www = "www.".length();
		int com = name.length() - ".com".length();
		String hasil = name.substring(www, com);
		System.out.println("Hasil Name : " + hasil);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Coba();

	}

}
