import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class SunibHackaton {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrName = new ArrayList<String>();
	ArrayList<String> arrEmail = new ArrayList<String>();
	ArrayList<String> arrGithub = new ArrayList<String>();
	ArrayList<String> arrWebsite = new ArrayList<String>();
	ArrayList<Double> arrTotalDiscount = new ArrayList<Double>();
	ArrayList<Double> arrRegist = new ArrayList<Double>();

	public SunibHackaton() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("Sunib Hackaton");
			System.out.println("==============");
			System.out.println("1. Register Sunib Hackaton");
			System.out.println("2. View All Registrant");
			System.out.println("3. Delete");
			System.out.println("4. Exit");
			System.out.print(">> ");
			
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				delete();
				break;
			case 4:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 4);
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		view();
		int index = 0;
		System.out.println("Mana yang mau di hapus : ");
		index = scan.nextInt(); scan.nextLine();
		
		arrName.remove(index);
		arrEmail.remove(index);
		arrGithub.remove(index);
		arrWebsite.remove(index);
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Embrace the code, conquer the challenge, let algorithms define excellence");
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		if (arrID.size() == 0) {
			System.out.println("No one has registered yet !");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}	
		System.out.println("==============================================================================");
		String rapi = "| %-5s | %-12s | %-25s | %-30s | %-30s | %-30s |/n";
		System.out.printf(rapi, "No", "Team ID", "Team Name", "Email", "Github Link", "Website Link");
		System.out.println("==============================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, i, arrID.get(i), arrName.get(i), arrEmail.get(i), arrGithub.get(i), arrWebsite.get(i));
		}
		System.out.println("==============================================================================");

	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int flag, countNum, countHex;
		String alpa;
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.println("Input Team Name [ Must be alphanumeric and Unique ] : ");
			alpa = scan.nextLine();
			for (char c : alpa.toCharArray()) {
				if (!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if (Character.isLetter(c)) {
					countNum++;
				}
				if (Character.isDigit(c)) {
					countHex++;
				}
			}
			if (arrName.contains(alpa)) {
				System.out.println("Sorry sudah kepake");
			}
		} while (flag == 1 || countNum == 0 || countHex == 0 || arrName.contains(alpa));
		
		String inputEmail;
		do {
			System.out.println("Input Email [ Must ends with @gmail.com or @sunib.ac.id ] : ");
			inputEmail = scan.nextLine();
		} while (!inputEmail.endsWith("@gmail.com") && !inputEmail.endsWith("sunib.ac.id"));
		
		String inputGithub;
		do {
			System.out.println("Input Github Link [ Must starts with github.com/ ] : ");
			inputGithub = scan.nextLine();
		} while (!inputGithub.startsWith("github.com/"));
		
		String inputWebsite;
		do {
			System.out.println("Input Website Link [ Must starts with www. and ends with.com ] : ");
			inputWebsite = scan.nextLine();
		} while (!inputWebsite.startsWith("www.") || !inputWebsite.endsWith(".com"));
		
		double totalDiscount = 0;
		double registPrice = 0;
		totalDiscount = (int) ((Math.random()*21)+10);
		registPrice = 150000 - (150000 * (totalDiscount/100));
		
		String yesno;
		do {
			System.out.println("Are u sure want to register [ Y | N ] ( Case Sensitive ) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			System.out.println("===================================================================");
			System.out.println("|                     Registration Information                    |");
			System.out.println("===================================================================");
			Random rand = new Random();
			char c1 = alpa.charAt(rand.nextInt(alpa.length()));
			char c2;
			do {
				c2 = alpa.charAt(rand.nextInt(alpa.length()));
			} while (c2 == c1);
			String id = String.format("T%c%c%d%d%d", c1, c2, (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
			
			System.out.printf("| %-12s : %-28s |\n", "Team ID", id);
			System.out.printf("| %-12s : %-28s |\n", "Team Name", alpa);
			System.out.printf("| %-12s : %-28s |\n", "Email", inputEmail);
			System.out.printf("| %-12s : %-28s |\n", "Github Link", inputGithub);
			System.out.printf("| %-12s : %-28s |\n", "Website Link", inputWebsite);
			System.out.printf("| %-12s : %-28s |\n",  "Total Discount", totalDiscount + "%");
			System.out.printf("| %-12s : %-28s |\n", "Registration Price", registPrice);
			System.out.println("===================================================================");
			
			int inputMoney = 0;
			do {
				System.out.println("Input Money [ >= Registration Price ] : ");
				inputMoney = scan.nextInt(); scan.nextLine();
			} while (!(inputMoney > registPrice));
			
			double change = 0;
			change = inputMoney - registPrice;
			System.out.printf("%s%.1f\n", "Change : ", change);
			System.out.println("good Luck For Your Competition :)");
			
			arrID.add(id);
			arrName.add(alpa);
			arrEmail.add(inputEmail);
			arrGithub.add(inputGithub);
			arrWebsite.add(inputWebsite);
			arrTotalDiscount.add(totalDiscount);
			arrRegist.add(registPrice);
			
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SunibHackaton();

	}

}
