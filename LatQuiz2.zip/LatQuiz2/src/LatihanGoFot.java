import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class LatihanGoFot {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCusName = new ArrayList<String>();
	ArrayList<String> arrFranchise = new ArrayList<String>();
	ArrayList<String> arrFoodName = new ArrayList<String>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<String> arrOrder = new ArrayList<String>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();

	public LatihanGoFot() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("goFoT");
			System.out.println("=====");
			System.out.println("1. Order goFoT");
			System.out.println("2. View All Order History");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;
			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no order history!");
			System.out.print("Press enter To Continue");
			return;
		}
		System.out.println("=========================================================================================");
		String rapi = "| %-12s | %-20s | %-20s | %-20s | %-12s | %-20s | %-20s |\n";
		System.out.printf(rapi, "Order ID", "Customer Name", "Franchise Name", "Food Name", "Quantity", "Order Note", "Total Price");
		System.out.println("=========================================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrCusName.get(i), arrFranchise.get(i), arrFoodName.get(i), arrQuantity.get(i), arrOrder.get(i), arrTotalPrice.get(i));
		}
		System.out.println("=========================================================================================");
		
	}

	private void order() {
		// TODO Auto-generated method stub
		String inputCusName;
		boolean cek = true;
		do {
			System.out.print("Input Customer Name : ");
			inputCusName = scan.nextLine();
			if (inputCusName.length()>=7 && inputCusName.length()<=15) {
				if (inputCusName.startsWith("Mr.") || inputCusName.startsWith("Mrs.")) {
					cek = false;
				}
			} else if (!(inputCusName.length()<=7) && !(inputCusName.length()>=15)) {
				if (!inputCusName.startsWith("Mr.") || !inputCusName.startsWith("Mrs.")) {
					cek = true;
					System.out.println("Inputan tidak sesuai");
				}
			}
		} while (cek);
		
		String inputFranchise;
		do {
		System.out.println("Input Franchise Name : ");
		inputFranchise = scan.nextLine();
		} while (!inputFranchise.equalsIgnoreCase("Fkc") && !inputFranchise.equalsIgnoreCase("Cmd"));
		
		String inputFoodName;
		int foodPrice = 0;
		do {
		System.out.println("Input Franchise Name : ");
		inputFoodName = scan.nextLine();
		} while (!inputFoodName.equals("Burger") && !inputFoodName.equals("Fried Chicken") && !inputFoodName.equals("French Fries"));
		if (inputFoodName.equals("Burger")) {
			foodPrice = 17000;
		} else if (inputFoodName.equals("Fried Chicken")) {
			foodPrice = 22000;
		} else if (inputFoodName.equals("French Fries")) {
			foodPrice = 12000;
		}
		
		String inputOrder;
		do {
		System.out.println("Input Franchise Name : ");
		inputOrder = scan.nextLine();
		} while (!inputOrder.contains("Thank You") || !(inputOrder.length()>=2));
		
		int inputQuantity;
		do {
		System.out.println("Input Franchise Name : ");
		inputQuantity = scan.nextInt(); scan.nextLine();
		} while (!(inputQuantity > 0));
		
		double tax = 0;
		tax = (foodPrice * inputQuantity) * 10/100;
		double totalPrice = 0;
		totalPrice = (foodPrice * inputQuantity) + tax;
		
		System.out.println("==================================");
		System.out.println("|        Order Information       |");
		System.out.println("==================================");
		Random rand = new Random();
		String id = "";
		if (inputFranchise.equalsIgnoreCase("Fkc")) {
			String fkc = inputFranchise;
			char c1 = fkc.charAt(rand.nextInt(fkc.length()));
			char c2 = fkc.charAt(rand.nextInt(fkc.length()));
			id = String.format("RI&c%c", c1, c2);
		} else if (inputFranchise.equalsIgnoreCase("Fkc")) {
			String cmd = inputFranchise;
			char c1 = cmd.charAt(rand.nextInt(cmd.length()));
			char c2;
			do {
				c2 = cmd.charAt(rand.nextInt(cmd.length()));
			} while (c2 == c1);
			id = String.format("RI&c%c", c1, c2);
		}
		
		System.out.printf("| %-12s : %-28s |\n", "Order ID", id);
		System.out.printf("| %-12s : %-28s |\n", "Customer Name", inputCusName);
		System.out.printf("| %-12s : %-28s |\n", "Food Name", inputFoodName);
		System.out.printf("| %-12s : %-28s |\n", "Food Price", foodPrice);
		System.out.printf("| %-12s : %-28s |\n", "Quantity", inputQuantity);
		System.out.printf("| %-12s : %-28s |\n", "Order Note", inputOrder);
		System.out.printf("| %-12s : %-28s |\n", "Franchise Name", inputFranchise);
		System.out.printf("| %-12s : %-28s |\n", "Tax", tax);
		System.out.printf("| %-12s : %-28s |\n", "Total Price", totalPrice);
		System.out.println("==================================");
		
		arrID.add(id);
		arrCusName.add(inputCusName);
		arrFoodName.add(inputFoodName);
		arrQuantity.add(inputQuantity);
		arrOrder.add(inputOrder);
		arrFranchise.add(inputFranchise);
		arrTotalPrice.add(totalPrice);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LatihanGoFot();

	}

}
