import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class GoFot3 {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCustomer = new ArrayList<String>();
	ArrayList<String> arrFoodName = new ArrayList<String>();
	ArrayList<Integer> arrFoodPrice = new ArrayList<Integer>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<String> arrOrder = new ArrayList<String>();
	ArrayList<String> arrFranchise = new ArrayList<String>();
	ArrayList<Double> arrTax = new ArrayList<Double>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();

	public GoFot3() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("goFoT");
			System.out.println("=====");
			System.out.println("1. Order goFoT");
			System.out.println("2. View All Order History");
			System.out.println("3. Exit");
			System.out.print(">> ");
			
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Harus Angka Tempek");
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Good Luck Have Fun :)");
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no order history !");
			return;
		}
		System.out.println("=======================================================");
		String rapi = "| %-10s | %-20s | %-20s | %-20s | %-10s | %-20s | %-15s |\n";
		System.out.printf(rapi, "Order ID", "Cutomer Name", "Franchise Name", "Food Name", "Quantity", "Order Note", "Total Price");
		System.out.println("=======================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrCustomer.get(i), arrFranchise.get(i), arrFoodName.get(i), arrQuantity.get(i), arrOrder.get(i), arrTotalPrice.get(i));
		}
		System.out.println("=======================================================");
		
	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String inputCustomer;
		boolean kiw = true;
		do {
			System.out.println("Input Customer Name [ Must be between 7 - 15 characters and Starts with Mr. or Mrs. ] : ");
			inputCustomer = scan.nextLine();
			if (inputCustomer.length() >= 7 && inputCustomer.length() <= 15) {
				if (inputCustomer.startsWith("Mr.") || inputCustomer.startsWith("Mrs.")) {
					kiw = false;
				}
			}
		} while (kiw);
		
		String inputFranchise;
		int foodPrice = 0;
		do {
			System.out.println("Input Franchise Name [ Fkc | Cmd ] ( Case Insensitive) : ");
			inputFranchise = scan.nextLine();
		} while (!inputFranchise.equalsIgnoreCase("Fkc") && !inputFranchise.equalsIgnoreCase("Cmd"));
		
		String inputFood;
		do {
			System.out.println("Input Food Name [ Burger | Fried Chicken | French Fries ] ( Case Sensitive ) : ");
			inputFood = scan.nextLine();
		} while (!inputFood.equals("Burger") && !inputFood.equals("Fried Chicken") && !inputFood.equals("French Fries"));
		if (inputFood.equals("Burger")) {
			foodPrice = 17000;
		} else if (inputFood.equals("Fried Chicken")) {
			foodPrice = 22000;
		} else if (inputFood.equals("French Fries")) {
			foodPrice = 12000;
		}
		
		String inputOrder;
		do {
			System.out.println("Input Order Note [ Must contain atleast 2 words and contain Thank You ] : ");
			inputOrder = scan.nextLine();
		} while (!inputOrder.contains("Thank You") || !(inputOrder.length()>=2));
		
		int inputQuantity = 0;
		do {
			System.out.println("Input Quantity [ Must be more than 0 ] : ");
			inputQuantity = scan.nextInt(); scan.nextLine();
		} while (!(inputQuantity > 0));
		
		double tax = 0;
		double totalPrice = 0;
		tax = (foodPrice * inputQuantity) * 10/100;
		totalPrice = (foodPrice * inputQuantity) + tax;
		
		System.out.println("==================================");
		System.out.println("|        Order Information       |");
		System.out.println("==================================");
		Random rand = new Random();
		String id = "";
		if (inputFranchise.equalsIgnoreCase("Fkc")) {
			String kfc = inputFranchise;
			char c1 = kfc.charAt(rand.nextInt(kfc.length()));
			char c2 = kfc.charAt(rand.nextInt(kfc.length()));
			id = String.format("RI%c%c%d%d%d", c1, c2, (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		} else if (inputFranchise.equalsIgnoreCase("Cmd")) {
			do {
				String mcd = inputFranchise;
				char c1 = mcd.charAt(rand.nextInt(mcd.length()));
				char c2;
				do {
					c2 = mcd.charAt(rand.nextInt(mcd.length()));
				} while (c2 == c1);
				id = String.format("RI%c%c%d%d%d", c1, c2, (int) (Math.random() * 10), (int) (Math.random() * 10), (int) (Math.random() * 10));
			} while (arrID.contains(id));
		}
		System.out.printf("| %-12s : %-28s |\n", "Order ID", id);
		System.out.printf("| %-12s : %-28s |\n", "Customer Name", inputCustomer);
		System.out.printf("| %-12s : %-28s |\n", "Food Name", inputFood);
		System.out.printf("| %-12s : %-28s |\n", "Food Price", foodPrice);
		System.out.printf("| %-12s : %-28s |\n", "Quantity", inputQuantity);
		System.out.printf("| %-12s : %-28s |\n", "Order Note", inputOrder);
		System.out.printf("| %-12s : %-28s |\n", "Franchise Name", inputFranchise);
		System.out.printf("| %-12s : %-28s |\n", "Tax", tax);
		System.out.printf("| %-12s : %-28s |\n", "Total Price", totalPrice);
		System.out.println("==================================");
		
		String confirm;
		do {
			System.out.println("Confirm Order [ y | n ] ( Case Sensitive ) : ");
			confirm = scan.nextLine();
		} while (!confirm.equals("y") && !confirm.equals("n"));
		if (confirm.equals("n")) {
			return;
		} else if (confirm.equals("y")) {
			System.out.println("Success Order !");
		}
		
		arrID.add(id);
		arrCustomer.add(inputCustomer);
		arrFoodName.add(inputFood);
		arrFoodPrice.add(foodPrice);
		arrQuantity.add(inputQuantity);
		arrOrder.add(inputOrder);
		arrFranchise.add(inputFranchise);
		arrTax.add(tax);
		arrTotalPrice.add(totalPrice);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GoFot3();

	}

}
