import java.util.ArrayList;
import java.util.Scanner;

public class BakmiEfete {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCustomerName = new ArrayList<String>();
	ArrayList<String> arrFoodName = new ArrayList<String>();
	ArrayList<Integer> arrFoodPrice = new ArrayList<Integer>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<Double> arrTotalDiscount = new ArrayList<Double>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();
	ArrayList<String> arrPaymentMethod = new ArrayList<String>();
	

	public BakmiEfete() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("Bakmi eFeTe");
			System.out.println("===========");
			System.out.println("1. Order Menu");
			System.out.println("2. View Order History");
			System.out.println("3. Exit");
			System.out.print(">> ");
			
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Harus Angka Goblog");
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		if (arrID.size() == 0) {
			System.out.println("There is no order history !");
			System.out.println("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("=================================================");
		String rapi = "| %-12s | %-25s | %-30s | %-15s | %-20s | %-18s |\n";
		System.out.printf(rapi, "Order ID", "Customer Name", "Food Name", "Quantity", "Payment Method", "Total Price");
		System.out.println("=================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrCustomerName.get(i), arrFoodName.get(i), arrQuantity.get(i), arrPaymentMethod.get(i), arrTotalPrice.get(i));
			System.out.println("=================================================");
		}
		System.out.print("Press Enter To Continue...");
		scan.nextLine();

	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String inputCustomer;
		do {
			System.out.println("Input Customer Name [ Must be more than 5 characters ] : ");
			inputCustomer = scan.nextLine();
		} while (!(inputCustomer.length() >= 5));
		
		String inputFoodName;
		do {
			System.out.println("Input Food Name [ \"Bakmi Keriting\" | \"Bakmi Lebar\" ] ( Case Insensitive ) : ");
			inputFoodName = scan.nextLine();
		} while (!inputFoodName.equals("Bakmi Keriting") && !inputFoodName.equals("Bakmi Lebar"));
		
		int inputFoodPrice = 0;
		do {
			System.out.println("Input Food Price [ Must be more than 10000 ] : ");
			inputFoodPrice = scan.nextInt(); scan.nextLine();
		} while (!(inputFoodPrice > 1000));
		
		int inputQuantity = 0;
		do {
			System.out.println("Input Quantity [ Must be more than 0 ] : ");
			inputQuantity = scan.nextInt(); scan.nextLine();
		} while (!(inputQuantity > 0));
		
		String inputPayment;
		int paymentPoint = 0;
		do {
			System.out.println("Input Payment Method [ Cash | Transfer | QRIS ] ( Case Sensitive ) : ");
			inputPayment = scan.nextLine();
		} while (!inputPayment.equals("Cash") && !inputPayment.equals("Transfer") && !inputPayment.equals("QRIS"));
		if (inputPayment.equals("Cash")) {
			paymentPoint = 0;
		} else if (inputPayment.equals("Transfer")) {
			paymentPoint = 5;
		} else if (inputPayment.equals("QRIS")) {
			paymentPoint = 10;
		}
		
		double totalDiscount = 0;
		double totalPrice = 0;
		totalDiscount = inputCustomer.length() + paymentPoint;
		totalPrice = (inputFoodPrice * inputQuantity) - ((inputFoodPrice * inputQuantity) * (totalDiscount/100));
		
		System.out.println("========================================");
		System.out.println("|                Bill                  |");
		System.out.println("========================================");
		String id = String.format("BI%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		System.out.printf("| %-12s : %-28s |\n", "Bill ID", id);
		System.out.printf("| %-12s : %-28s |\n", "Customer Name", inputCustomer);
		System.out.printf("| %-12s : %-28s |\n", "Food Name", inputFoodName);
		System.out.printf("| %-12s : %-28s |\n", "Food Price", inputFoodPrice);
		System.out.printf("| %-12s : %-28s |\n", "Quantity", inputQuantity);
		System.out.printf("| %-12s : %-28s |\n", "Total Discount", totalDiscount);
		System.out.printf("| %-12s : %-28s |\n", "Total Price", totalPrice);
		System.out.printf("| %-12s : %-28s |\n", "Payment Method", inputPayment);
		System.out.println("========================================");

		int inputMoney = 0;
		do {
			System.out.println("Input Money [ >= Total Price] : ");
			inputMoney = scan.nextInt(); scan.nextLine();
		} while (!(inputMoney > totalPrice));
		
		double change = 0;
		change = inputMoney - totalPrice;
//		System.out.printf("Change : ");
//		System.out.printf("%.0f\n", change);
		System.out.printf("%s%.0f", "Change : ", change);
		System.out.println(" ");
		System.out.println("Thank you for your purchase :)");
		
		arrID.add(id);
		arrCustomerName.add(inputCustomer);
		arrFoodName.add(inputFoodName);
		arrFoodPrice.add(inputFoodPrice);
		arrQuantity.add(inputQuantity);
		arrTotalDiscount.add(totalDiscount);
		arrTotalPrice.add(totalPrice);
		arrPaymentMethod.add(inputPayment);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BakmiEfete();

	}

}
