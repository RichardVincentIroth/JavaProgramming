import java.util.ArrayList;
import java.util.Scanner;

public class FixTue3 {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrCusName = new ArrayList<String>();
	ArrayList<String> arrDrinkName = new ArrayList<String>();
	ArrayList<Integer> arrDrinkPrice = new ArrayList<Integer>();
	ArrayList<String> arrCupType = new ArrayList<String>();
	ArrayList<Integer> arrCupPrice = new ArrayList<Integer>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<String> arrPayment = new ArrayList<String>();
	ArrayList<Double> arrTotalDiscount = new ArrayList<Double>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();

	public FixTue3() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("FixTue");
			System.out.println("======");
			System.out.println("1. Order Drink");
			System.out.println("2. View All Order History");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Harus Angka");
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
			
		} while (menu != 3);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Never Give Up :)");
		
	}

	private void view() {
		// TODO Auto-generated method stub
		sort();
		if (arrID.size() == 0) {
			System.out.println("There is no order history !");
			return;
		}
		System.out.println("===========================================================");
		String rapi = "| %-12s |  %-20s |  %-12s |  %-12s |  %-12s |  %-25s |  %-20s |\n";
		System.out.printf(rapi, "Order ID", "Customer Name", "Drink Name", "Cup Type", "Quantity", "Payment Method", "Total Price");
		System.out.println("===========================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrCusName.get(i), arrDrinkName.get(i), arrCupType.get(i), arrQuantity.get(i), arrPayment.get(i), arrTotalPrice.get(i));
		}
		System.out.println("===========================================================");

	}

	private void sort() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				String kiri = arrID.get(j);
				String kanan = arrID.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String cusName;
		do {
			System.out.print("Input Customer Name : ");
			cusName = scan.nextLine();
		} while (!(cusName.length()>5) || !(cusName.length()<15));
		
		String drinkName;
		int drinkPrice = 0;
		do {
			System.out.print("Input Drink Name : ");
			drinkName = scan.nextLine();
		} while (!drinkName.equals("Brown Sugar") && !drinkName.equals("Red Bean") && !drinkName.equals("Oats"));
		if (drinkName.equals("Brown Sugar")) {
			drinkPrice = 20000;
		} else if (drinkName.equals("Red Bean")) {
			drinkPrice = 17000;
		} else if (drinkName.equals("Oats")) {
			drinkPrice = 15000;
		}
		
		String cupType;
		int cupPrice = 0;
		do {
			System.out.print("Input Cup Type : ");
			cupType = scan.nextLine();
		} while (!cupType.equals("Small") && !cupType.equals("Medium") && !cupType.equals("Large"));
		if (cupType.equals("Small")) {
			cupPrice = 0;
		} else if (cupType.equals("Medium")) {
			cupPrice = 2000;
		} else if (cupType.equals("Large")) {
			cupPrice = 5000;
		}
		
		int quantity = 0;
		do {
			System.out.print("Input Quantity : ");
			quantity = scan.nextInt(); scan.nextLine();
		} while (!(quantity > 0));
		
		String payment;
		int paymentPrice = 0;
		do {
			System.out.print("Input Payment Method : ");
			payment = scan.nextLine();
		} while (!payment.equals("Transfer") && !payment.equals("QRIS"));
		if (payment.equals("Transfer")) {
			paymentPrice = 5;
		} else if (payment.equals("QRIS")) {
			paymentPrice = 10;
		}
		
		double total = 0;
		double totalDiscount = 0;
		double totalPrice = 0;
		total = (drinkPrice + cupPrice) * quantity;
		totalDiscount = cusName.length() + paymentPrice;
		totalPrice = total - (total*(totalDiscount/100));
		
		System.out.println("===================================");
		System.out.println("|        Bill Information         |");
		System.out.println("===================================");
		String id = String.format("BL%d%d%d", (int) (Math.random() * 10), (int) (Math.random() * 10), (int) (Math.random() * 10));
		System.out.printf("| %-12s : %-28s |", "Bill ID", id);
		System.out.printf("| %-12s : %-28s |", "Customer Name", cusName);
		System.out.printf("| %-12s : %-28s |", "Drink Name", drinkName);
		System.out.printf("| %-12s : %-28s |", "Drink Price", drinkPrice);
		System.out.printf("| %-12s : %-28s |", "Cup Type", cupType);
		System.out.printf("| %-12s : %-28s |", "Cup Price", cupPrice);
		System.out.printf("| %-12s : %-28s |", "Quantity", quantity);
		System.out.printf("| %-12s : %-28s |", "Payment Method", payment);
		System.out.printf("| %-12s : %-28s |", "Total Discount", totalDiscount);
		System.out.printf("| %-12s : %-28s |", "Total Price", totalPrice);
		System.out.println("===================================");
		
		int money = 0;
		do {
			System.out.println("Input Money : ");
			money = scan.nextInt(); scan.nextLine();
		} while (!(money > totalPrice));
		
		double change = 0;
		change = money - totalPrice;
		System.out.println("Change : " + change);
		System.out.println(" ");
		System.out.println("Thank You :)");
		
		arrID.add(id);
		arrCusName.add(cusName);
		arrDrinkName.add(drinkName);
		arrDrinkPrice.add(drinkPrice);
		arrCupType.add(cupType);
		arrCupPrice.add(cupPrice);
		arrQuantity.add(quantity);
		arrPayment.add(payment);
		arrTotalDiscount.add(totalDiscount);
		arrTotalPrice.add(totalPrice);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FixTue3();

	}

}
