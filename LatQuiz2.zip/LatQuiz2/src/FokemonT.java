import java.util.ArrayList;
import java.util.Scanner;

public class FokemonT {
	ArrayList<String> arrName = new ArrayList <String>();
	ArrayList<String> arrType = new ArrayList <String>();
	ArrayList<Integer> arrHp = new ArrayList <Integer>();
	ArrayList<Integer> arrAttack = new ArrayList <Integer>();
	ArrayList<String> arrAbilities = new ArrayList <String>();

	public FokemonT() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int milih = 0;
		do {
			System.out.println("FokemonT");
			System.out.println("==============");
			System.out.println("1. Insert a FokemonT");
			System.out.println("2. View Fokedex");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				milih = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Harus Angka Goblog");
			} scan.nextLine();
			
			switch (milih) {
			case 1:
				insert();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;
			default:
				break;
			}
		} while (milih != 3);
		
		
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank You :)");
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrName.size()== 0) {
			System.out.println("There is no FokemonT !");
			return;
		}
		String abc = String.format("PI%s%s%d%d%d", (char) ((Math.random()*26)+65), (char) ((Math.random()*26)+65), (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		System.out.println("===============================================================================");
		String rapi = ("| %-12s | %-20s | %-20s | %-8s | %-8s | %-20s |%n");
		System.out.printf(rapi, "FokemonT ID", "FokemonT Name", "FokemonT Type", "Hp", "Attack", "Abilities");
		System.out.println("===============================================================================");
		for (int i = 0; i < arrName.size(); i++) {
			System.out.printf(rapi, abc, arrName.get(i), arrType.get(i), arrHp.get(i), arrAttack.get(i), arrAbilities.get(i));
		}
		System.out.println("===============================================================================");

	}

	private void insert() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int flag, countNum, countHex;
		String fokemonName;
		String fokemonType;
		int fokemonHp = 0;
		int fokemonAttack = 0;
		String fokemonAbilities;
		int idea = 0;
		boolean ideabool = true;
		
		do {
			flag = 0;
			countNum = 0;
			countHex = 0;
			System.out.print("Input FokemonT Name [ Must be alphabetic and Unique ] : ");
			fokemonName = scan.nextLine();
			for (char c : fokemonName.toCharArray()) {
				if (!Character.isAlphabetic(c) && c!= ' ') {
					flag = 1;
				}
			}
		} while (flag == 1 || arrName.contains(fokemonName) || fokemonName.split(" ").length<2 || fokemonName.split(" ").length>2);
		
		do {
			System.out.println("Input Fokemon Type [ Fire | Grass | Water ] (Case Sensitive) : ");
			fokemonType = scan.nextLine();
		} while (!fokemonType.equals("Fire") && !fokemonType.equals("Grass") && fokemonType.equals("Water"));
		
		do {
			System.out.println("Input FokemonT Hp [ Must be between 100 - 1000 ] (Inclusive) : ");
			fokemonHp = scan.nextInt(); scan.nextLine();
		} while (!(fokemonHp >= 100) || !(fokemonHp <= 1000));
		
		do {
			System.out.println("Input FokemonT Attack [ Must be between 100 - 200 ] (Exclusive) : ");
			fokemonAttack = scan.nextInt(); scan.nextLine();
		} while (!(fokemonAttack > 100) || !(fokemonAttack < 200));
		
		do {
			System.out.println("Input FomekonT Abilities [ Must contain atleast 2 words ] : ");
			fokemonAbilities = scan.nextLine();
//			String [] words = fokemonAbilities.split(" ");
//			idea = words.length;
//			if (fokemonAbilities.startsWith(" ") && fokemonAbilities.endsWith(" ")) {
//				if (idea >= 2) {
//					ideabool = false;
//				}
//			}
		} while (fokemonAbilities.split(" ").length < 2);
		
		arrName.add(fokemonName);
		arrType.add(fokemonType);
		arrHp.add(fokemonHp);
		arrAttack.add(fokemonAttack);
		arrAbilities.add(fokemonAbilities);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FokemonT();

	}

}
