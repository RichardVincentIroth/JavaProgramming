import java.util.ArrayList;
import java.util.Scanner;

public class BorroRoom {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrTenant = new ArrayList<String>();
	ArrayList<String> arrRoomView = new ArrayList<String>();
	ArrayList<Integer> arrRentPrice = new ArrayList<Integer>();

	public BorroRoom() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("Welcome to Borro Room");
			System.out.println("====================");
			System.out.println("1. Reserve a Room");
			System.out.println("2. View Reserved Room");
			System.out.println("3. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			switch (menu) {
			case 1:
				reserve();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		if (arrID.size() == 0) {
			System.out.println("Reserved Room");
			System.out.println("================");
			System.out.println(" ");
			System.out.println("There is no reserved room yet!");
			System.out.println("Press enter to continue...");
			scan.nextLine();
			return;
		}
		System.out.println("Reserved Room");
		System.out.println("================");
		System.out.println(" ");
		System.out.println("=============================================================================");
		String rapi = "| %-8s | %-30s | %-15s | %-15s |\n";
		System.out.printf(rapi, "Room", "Tenant's Name", "Room View", "Rent Price");
		System.out.println("=============================================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrTenant.get(i), arrRoomView.get(i), arrRentPrice.get(i));
		}
		System.out.println("=============================================================================");
		
		int select = 0;
		do {
			System.out.print("Select [1..3]: ");
			select = scan.nextInt(); scan.nextLine();
		} while (!(select >= 1) || !(select <= 3));
		
		System.out.printf("%-12s : %-12s\n", "Room No.", arrID.get(select - 1));
		System.out.printf("%-12s : %-12s\n", "Tenant's Name", arrTenant.get(select - 1));
		System.out.printf("%-12s : %-12s\n", "Room View", arrRoomView.get(select - 1));
		System.out.printf("%-12s : %-12s\n", "Room Price", arrRentPrice.get(select - 1));
		System.out.println(" ");
		System.out.println(" ");
		int inputPayment = 0;
		do {
			System.out.print("Input payment: ");
			inputPayment = scan.nextInt();
			scan.nextLine();
		} while (inputPayment < arrRentPrice.get(select - 1));
		
		double change = 0;
		change = inputPayment - arrRentPrice.get(select - 1);
		int changes = (int) change;
		System.out.println("Change : " + changes);
		System.out.println(" ");
		System.out.println("Press enter to continue");
		scan.nextLine();
		
	}

	private void reserve() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int buildingRoom = 0;
		do {
			System.out.println("Specify the level of the building the room is in [1-20]: ");
			buildingRoom = scan.nextInt(); scan.nextLine();
		} while (!(buildingRoom > 0) || !(buildingRoom <= 20));
		
		int roomNumber = 0;
		do {
			System.out.println("Specify the room number [1-99]: ");
			roomNumber = scan.nextInt(); scan.nextLine();
		} while (!(roomNumber >= 1) || !(roomNumber <= 99));
		
		String inputTenant;
		do {
			System.out.println("Tenant's name [5-30 Characters]: ");
			inputTenant = scan.nextLine();
		} while (!(inputTenant.length()>=5) || !(inputTenant.length()<=30));
		
		String roomView = "Blocked";
		int roomViewPrice = 0;
		if (buildingRoom >= 10) {
			do {
				System.out.println("Choose the Room View [Mountain|Savana|Harbour]: ");
				roomView = scan.nextLine();
			} while (!roomView.equals("Mountain") && !roomView.equals("Savana") && !roomView.equals("Harbour"));
		}
		
		if (roomView.equals("Blocked")) {
			roomViewPrice = 0;
		} else if (roomView.equals("Mountain")) {
			roomViewPrice = 150000;
		} else if (roomView.equals("Savana")) {
			roomViewPrice = 125000;
		} else if (roomView.equals("Harbour")) {
			roomViewPrice = 100000;
		}
		
		String roomID = String.format("%02d%02d", buildingRoom, roomNumber);
		
		double rentPrice = 0;
		rentPrice = 50000 + roomViewPrice;
		int Price = (int) rentPrice;
		
		arrID.add(roomID);
		arrTenant.add(inputTenant);
		arrRoomView.add(roomView);
		arrRentPrice.add(Price);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BorroRoom();

	}

}
