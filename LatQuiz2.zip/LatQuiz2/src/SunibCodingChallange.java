import java.util.ArrayList;
import java.util.Scanner;

public class SunibCodingChallange {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrFullName = new ArrayList<String>();
	ArrayList<String> arrEmail = new ArrayList<String>();
	ArrayList<Integer> arrAge = new ArrayList<Integer>();
	ArrayList<String> arrGender = new ArrayList<String>();
	ArrayList<String> arrDepartment = new ArrayList<String>();

	public SunibCodingChallange() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int menu = 0;
		do {
			System.out.println("Sunib Coding Challange");
			System.out.println("======================");
			System.out.println("1. Register Sunib Coding Challange");
			System.out.println("2. View All Registrant");
			System.out.println("3. Exit");
			System.out.print(">> ");
			
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;

			default:
				break;
			}
		} while (menu != 3);
		
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void view() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		sort();
		
		if (arrID.size() == 0) {
			System.out.println("No one has registered yet !");
			System.out.print("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("===============================================================");
		String rapi = "| %-12s | %-20s | %-30s | %-10s | %-12s | %-20s |\n";
		System.out.printf(rapi, "Student ID", "Full Name", "Email", "Age", "Gender", "Department");
		System.out.println("===============================================================");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrFullName.get(i), arrEmail.get(i), arrAge.get(i), arrGender.get(i), arrDepartment.get(i));
		}
		System.out.println("===============================================================");
		System.out.print("Press Enter To Continue...");
		scan.nextLine();
		
	}

	private void sort() {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				String kiri = arrID.get(j);
				String kanan = arrID.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempFullName = arrFullName.get(j);
					arrFullName.set(j, arrFullName.get(j+1));
					arrFullName.set(j+1, tempFullName);
					
					String tempEmail = arrEmail.get(j);
					arrEmail.set(j, arrEmail.get(j+1));
					arrEmail.set(j+1, tempEmail);
					
					int tempAge = arrAge.get(j);
					arrAge.set(j, arrAge.get(j+1));
					arrAge.set(j+1, tempAge);
					
					String tempGender = arrGender.get(j);
					arrGender.set(j, arrGender.get(j+1));
					arrGender.set(j+1, tempGender);
					
					String tempDepartment = arrDepartment.get(j);
					arrDepartment.set(j, arrDepartment.get(j+1));
					arrDepartment.set(j+1, tempDepartment);
				}
			}
		}
		
	}

	private void order() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		String inputID;
		do {
			System.out.println("Input Student ID [ Must starts with 26 or 27 ] [ must be unique ] : ");
			inputID = scan.nextLine();
		} while (!inputID.startsWith("26") && !inputID.startsWith("27") || arrID.contains(inputID));
		
		String inputFull;
		do {
			System.out.println("Input Full Name [ Must be between 5 - 25 characters ] : ");
			inputFull = scan.next();
		} while (!(inputFull.length()>17) || !(inputFull.length()<21));
		
		int inputAge = 0;
		do {
			System.out.println("Input Age [ Must be between 17 - 21 ] : ");
			inputAge = scan.nextInt(); scan.nextLine();
		} while (!(inputAge > 17) || !(inputAge < 21));
		
		String inputGender;
		int genderPoint = 0;
		do {
			System.out.println("Input Gender [ Female | Male ] ( Case Sensitive ) : ");
			inputGender = scan.nextLine();
		} while (!inputGender.equals("Female") && !inputGender.equals("Male"));
		if (inputGender.equals("Female")) {
			genderPoint = 20;
		} else if (inputGender.equals("Male")) {
			genderPoint = 10;
		}
		
		String inputEmail;
		do {
			System.out.println("Input Email [ Must ends with @gmail.com ] : ");
			inputEmail = scan.nextLine();
		} while (!inputEmail.endsWith("@gmail.com"));
		
		String inputDepartment;
		int departmentPoint = 0;
		do {
			System.out.println("Input Department [ SOCS | SOIS | SOD ] (Case Insensitive) : ");
			inputDepartment = scan.nextLine();
		} while (!inputDepartment.equalsIgnoreCase("SOCS") && !inputDepartment.equalsIgnoreCase("SOIS") && !inputDepartment.equalsIgnoreCase("SOD"));
		if (inputDepartment.equalsIgnoreCase("SOCS")) {
			departmentPoint = 20;
		} else if (inputDepartment.equalsIgnoreCase("SOIS")) {
			departmentPoint = 30;
		} else if (inputDepartment.equalsIgnoreCase("SOD")) {
			departmentPoint = 25;
		}
		
		String inputPayment;
		int paymentPoint = 0;
		do {
			System.out.println("Input Payment Method [ Cash | Transfer | QRIS ] ( Case Sensitive ): ");
			inputPayment = scan.nextLine();
		} while (!inputPayment.equals("Cash") && !inputPayment.equals("Transfer") && !inputPayment.equals("QRIS"));
		if (inputPayment.equals("Cash")) {
			paymentPoint = 0;
		} else if (inputPayment.equals("Transfer")) {
			paymentPoint = 5;
		} else if (inputPayment.equals("QRIS")) {
			paymentPoint = 10;
		}
		
		double totalDiscount = departmentPoint + paymentPoint + genderPoint;
		double registPrice = 100000 - (100000 * (totalDiscount/100));
		String yesno;
		do {
			System.out.println("Are u sure want to register [ Y | N ] ( Case Sensitive ) : ");
			yesno = scan.nextLine();
		} while (!yesno.equals("Y") && !yesno.equals("N"));
		if (yesno.equals("N")) {
			return;
		} else if (yesno.equals("Y")) {
			System.out.println("=======================================================");
			System.out.println("|                Registration Information              ");
			System.out.println("=======================================================");
			System.out.printf("| %-12s : %-28s |\n", "Student ID", inputID);
			System.out.printf("| %-12s : %-28s |\n", "Full Name", inputFull);
			System.out.printf("| %-12s : %-28s |\n", "Age", inputAge);
			System.out.printf("| %-12s : %-28s |\n", "Gender", inputGender);
			System.out.printf("| %-12s : %-28s |\n", "Department", inputDepartment);
			System.out.printf("| %-12s : %-28s |\n", "Total Discount", totalDiscount);
			System.out.printf("| %-12s : %-28s |\n", "Registratioon Price", registPrice);
			System.out.printf("| %-12s : %-28s |\n", "Payment Method", inputPayment);
			System.out.println("=======================================================");
			
			int inputMoney = 0;
			do {
				System.out.println("Input Money [ >= Registration Price ] : ");
				inputMoney = scan.nextInt(); scan.nextLine();
			} while (!(inputMoney > registPrice));
			
			double change = inputMoney - registPrice;
			System.out.printf("%s%f", "Change : ", change);
			System.out.println(" ");
			System.out.println("Good Luck For Your Competition :)");
			
			arrID.add(inputID);
			arrFullName.add(inputFull);
			arrEmail.add(inputEmail);
			arrAge.add(inputAge);
			arrGender.add(inputGender);
			arrDepartment.add(inputDepartment);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SunibCodingChallange();

	}

}
