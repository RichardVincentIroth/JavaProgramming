import java.util.ArrayList;
import java.util.Scanner;

public class JanjiEfte {
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrAlphanumeric = new ArrayList<String>();
	ArrayList<String> arrCoffeName = new ArrayList<String>();
	ArrayList<String> arrCupSize = new ArrayList<String>();
	ArrayList<Integer> arrQuantity = new ArrayList<Integer>();
	ArrayList<Double> arrTotalPrice = new ArrayList<Double>();

	public JanjiEfte() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		
		int input = 0;
		do {
			System.out.println("Janji efte coffe");
			System.out.println("================");
			System.out.println("1. Order Coffe");
			System.out.println("2. View Order History");
			System.out.println("3. Exit");
			System.out.print(">> ");
			
			try {
				input = scan.nextInt();
			} catch (Exception e) {
				input = -1;
			} scan.nextLine();
			
			switch (input) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				exit();
				break;
			default:
				break;
			}
			
		} while (input != 3);
		

	}

	private void exit() {
		// TODO Auto-generated method stub
		System.out.println("Thank You :)");
		
	}
	
	private void sort() {
		
		for (int i = 0; i < arrID.size(); i++) {
			for (int j = 0; j < arrID.size() - 1; j++) {
				String kiri = arrID.get(j);
				String kanan = arrID.get(j+1);
				if (kiri.compareTo(kanan) > 0) {
					String tempID = arrID.get(j);
					arrID.set(j, arrID.get(j+1));
					arrID.set(j+1, tempID);
					
					String tempAlphanumeric = arrAlphanumeric.get(j);
					arrAlphanumeric.set(j, arrAlphanumeric.get(j+1));
					arrAlphanumeric.set(j+1, tempAlphanumeric);
					
					String tempCoffeName = arrCoffeName.get(j);
					arrCoffeName.set(j, arrCoffeName.get(j+1));
					arrCoffeName.set(j+1, tempCoffeName);
					
					String tempCupSize = arrCupSize.get(j);
					arrCupSize.set(j, arrCupSize.get(j+1));
					arrCupSize.set(j+1, tempCupSize);
					
					int tempQuantity = arrQuantity.get(j);
					arrQuantity.set(j, arrQuantity.get(j+1));
					arrQuantity.set(j+1, tempQuantity);
					
					double tempTotalPrice = arrTotalPrice.get(j);
					arrTotalPrice.set(j, arrTotalPrice.get(j+1));
					arrTotalPrice.set(j+1, tempTotalPrice);
				}
			}
		}
		
	}

	private void view() {
		sort();
		Scanner scan = new Scanner(System.in);
		
		if (arrID.size() == 0) {
			System.out.println("There is no order history");
			System.out.println("Press Enter To Continue . . .");
			scan.nextLine();
			return;
		}
		
		System.out.println("==========================================================================");
		String rapi = "| %-8s | %-20s | %-20s | %-8s | %-8s | %-12s |%n";
		System.out.printf(rapi, "Order ID", "Customer Name", "Coffe Name", "Cup Size", "Quantity", "Total Price");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrAlphanumeric.get(i), arrCoffeName.get(i), arrCupSize.get(i), arrQuantity.get(i), arrTotalPrice.get(i));
		}
		System.out.println("==========================================================================");
		
	}

	private void order() {
		Scanner scan = new Scanner(System.in);
		
		int flag, countNumber, countAlpha;
		String alphanumeric;
		boolean cek = true;
		do {
			flag = 0;
			countNumber = 0;
			countAlpha = 0;
			System.out.print("Input Customer Name [ Must be alphanumberic ] : ");
			alphanumeric = scan.nextLine();
			for(char c : alphanumeric.toCharArray()) {
				if(!Character.isLetterOrDigit(c) && c != ' ') {
					flag = 1;
				}
				if(Character.isDigit(c)) {
					countNumber++;
				}
				if(Character.isLetter(c)) {
					countAlpha++;
				}
			}
			if (flag == 1 || countNumber == 0 || countAlpha == 0) {
				cek = true;
				System.out.println("Must Alphanumeric");
			} else if (!(flag == 1) || !(countNumber == 0) || !(countAlpha == 0)) {
				cek = false;
			}
		}while(cek);
		
		String inputCoffe;
		int coffePrice = 0;
		do {
			System.out.print("Input Coffee Name [ Caffe Latte | Caramel Macchiato | Espresso ] (Case Sensitive) : ");
			inputCoffe = scan.nextLine();
		} while (!inputCoffe.equals("Caffe Latte") && !inputCoffe.equals("Caramel Macchiato") && !inputCoffe.equals("Espresso"));
		if(inputCoffe.equals("Caffe Latte")) {
			coffePrice = 30000;
		} else if (inputCoffe.equals("Caramel Macchiato")) {
			coffePrice = 35000;
		} else if (inputCoffe.equals("Espresso")) {
			coffePrice = 40000;
		}
		
		String inputCup;
		int cupPrice = 0;
		do {
			System.out.print("Input Cup Size [ Small | Medium ] (Case Insensitive) : ");
			inputCup = scan.nextLine();
		} while (!inputCup.equalsIgnoreCase("Small") && !inputCup.equalsIgnoreCase("Medium"));
		if (inputCup.equalsIgnoreCase("Small")) {
			cupPrice = 3000;
		} else if (inputCup.equalsIgnoreCase("Medium")) {
			cupPrice = 5000;
		}
		
		int inputQuantity = 0;
		do {
			System.out.print("Input Quantity [ Must be more than 0 ] : ");
			inputQuantity = scan.nextInt(); scan.nextLine();
		} while (!(inputQuantity > 0));
		
		String id = String.format("%s%s%d%d%d", (char) ((Math.random()*26)+65), (char) ((Math.random()*26)+65), (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		double total = 0;
		double tax = 0;
		double totalPrice = 0;
		total = (inputQuantity + coffePrice) + cupPrice;
		tax = total * (10/100);
		totalPrice = total + tax;
		
		System.out.println("===================================");
		System.out.println("          Order Information        ");
		System.out.println("===================================");
		System.out.printf("| %-12s %-28s |\n", "Order ID      : ", id);
		System.out.printf("| %-12s %-28s |\n", "Customer Name : ", alphanumeric);
		System.out.printf("| %-12s %-28s |\n", "Coffe Name    : ", inputCoffe);
		System.out.printf("| %-12s %-28s |\n", "Cup Size      : ", inputCup);
		System.out.printf("| %-12s %-28s |\n", "Quantity      : ", inputQuantity);
		System.out.printf("| %-12s %-28s |\n", "Total Price   : ", totalPrice);
		System.out.println("===================================");
		
		int inputMoney = 0;
		do {
			System.out.print("Input Money [ >= Total Price ] : ");
			inputMoney = scan.nextInt(); scan.nextLine();
		} while (!(inputMoney >= totalPrice));
		
		double change = 0;
		change = inputMoney - totalPrice;
		System.out.println("Change : " + change);
		System.out.println(" ");
		System.out.println("Thank you :)");
		
		arrID.add(id);
		arrAlphanumeric.add(alphanumeric);
		arrCoffeName.add(inputCoffe);
		arrCupSize.add(inputCup);
		arrQuantity.add(inputQuantity);
		arrTotalPrice.add(totalPrice);
	}

	public static void main(String[] args) {
		new JanjiEfte();
	}

}
