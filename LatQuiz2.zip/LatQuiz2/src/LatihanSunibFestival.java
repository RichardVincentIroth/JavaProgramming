import java.util.ArrayList;
import java.util.Scanner;

public class LatihanSunibFestival {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> arrID = new ArrayList<String>();
	ArrayList<String> arrGroupName = new ArrayList<String>();
	ArrayList<String> arrIdea = new ArrayList<String>();
	ArrayList<String> arrLocation = new ArrayList<String>();
	ArrayList<String> arrFeedback = new ArrayList<String>();

	public LatihanSunibFestival() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		do {
			System.out.println("Sunib Festival");
			System.out.println("==============");
			System.out.println("1. Register for the exhibition");
			System.out.println("2. View all exhibits");
			System.out.println("3. Update");
			System.out.println("4. Delete");
			System.out.println("5. Exit");
			System.out.print(">> ");
			try {
				menu = scan.nextInt();
			} catch (Exception e) {
				menu = -1;
			} scan.nextLine();
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				view();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				exit();
				break;
				
			default:
				break;
			}
		} while (menu != 5);
	}

	private void exit() {
		// TODO Auto-generated method stub
		
	}

	private void delete() {
		// TODO Auto-generated method stub
		view();
		int index = 0;
		System.out.print("Mana yang mau dihapus : ");
		index = scan.nextInt(); scan.nextLine();
		
		arrID.remove(index - 1);
		arrGroupName.remove(index - 1);
		arrIdea.remove(index - 1);
		arrLocation.remove(index - 1);
		arrFeedback.remove(index - 1);
		
	}

	private void update() {
		// TODO Auto-generated method stub
		view();
		int index = 0;
		System.out.print("Mana yang mau diganti : ");
		index = scan.nextInt(); scan.nextLine();
		String ini;
		System.out.print("Diganti jadi apa : ");
		ini = scan.nextLine();
		
//		arrID.set(index - 1, ini);
		arrGroupName.set(index - 1, ini);
//		arrIdea.set(index - 1, ini);
//		arrLocation.set(index - 1, ini);
//		arrFeedback.set(index - 1, ini);
		
	}

	private void view() {
		// TODO Auto-generated method stub
		if (arrID.size() == 0) {
			System.out.println("There is no exhibition yet!");
			System.out.print("Press Enter To Continue...");
			scan.nextLine();
			return;
		}
		System.out.println("===================================================================");
		String rapi = "| %-8s | %-12s | %-30s | %-20s | %-20s |\n";
		System.out.printf(rapi, "Table ID", " Group Name", "Idea", "Loaction", "Feedback Link");
		for (int i = 0; i < arrID.size(); i++) {
			System.out.printf(rapi, arrID.get(i), arrGroupName.get(i), arrIdea.get(i), "balkon "+ arrLocation.get(i), arrFeedback.get(i));
		}
		System.out.println("===================================================================");

	}

	private void order() {
		// TODO Auto-generated method stub
		int velg;
		String beric;
		do {
			velg = 0;
			System.out.print("Input Group Name [ Must alphabetic and unique ] : ");
			beric = scan.nextLine();
			for (char ch : beric.toCharArray()) {
				if (!Character.isAlphabetic(ch) && ch != ' ') {
					velg = 1;
				}
			}
		} while (velg == 1);
		
		String inputIdea;
		do {
			System.out.print("Input Idea [ Must be at leat contain 3 words ] : ");
			inputIdea = scan.nextLine();
		} while (inputIdea.split(" ").length<3);
		
		String inputLocation;
		do {
			System.out.print("Input Location [ Must be ends with \"lt.1\", \"lt.2\", or \"lt.3\" ] : ");
			inputLocation = scan.nextLine();
		} while (!inputLocation.endsWith("lt.1") && !inputLocation.endsWith("lt.2") && !inputLocation.endsWith("lt.3"));
		
		String inputFeedback;
		do {
			System.out.print("Input feedback link [ Must starts with 'forms.com/' ] : ");
			inputFeedback = scan.nextLine();
		} while (!inputFeedback.startsWith("forms.com/"));
		
		System.out.println("==================================================");
		System.out.println("|                  Exhibition Information        |");
		System.out.println("==================================================");
		String id = String.format("TB%d%d%d", (int) (Math.random()*10), (int) (Math.random()*10), (int) (Math.random()*10));
		System.out.printf("| %-12s : %-20s |\n", "Table ID", id);
		System.out.printf("| %-12s : %-20s |\n", "Froup Name", beric);
		System.out.printf("| %-12s : %-20s |\n", "Idea", inputIdea);
		System.out.printf("| %-12s : %-20s |\n", "Location", inputLocation);
		System.out.printf("| %-12s : %-20s |\n", "Feedback Link", inputFeedback);
		System.out.println("==================================================");
		
		arrID.add(id);
		arrGroupName.add(beric);
		arrIdea.add(inputIdea);
		arrLocation.add(inputLocation);
		arrFeedback.add(inputFeedback);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LatihanSunibFestival();

	}

}
